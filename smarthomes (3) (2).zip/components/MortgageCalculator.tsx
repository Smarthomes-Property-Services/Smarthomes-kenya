
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { 
    CalculatorIcon, 
    CpuChipIcon, 
    BuildingLibraryIcon,
    BanknotesIcon,
    ChartPieIcon,
    ArrowPathIcon
} from '@heroicons/react/24/solid';
import { askEmmanuel } from '../services/gemini.ts';

export const MortgageCalculator = () => {
    const [price, setPrice] = useState(15000000);
    const [downPayment, setDownPayment] = useState(3000000);
    const [interestRate, setInterestRate] = useState(15);
    const [loanTerm, setLoanTerm] = useState(20);
    
    const [monthlyPayment, setMonthlyPayment] = useState(0);
    const [totalInterest, setTotalInterest] = useState(0);
    const [totalPayable, setTotalPayable] = useState(0);
    
    const [emmanuelResponse, setEmmanuelResponse] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        // Calculate Mortgage: M = P [ i(1 + i)^n ] / [ (1 + i)^n – 1 ]
        const P = price - downPayment;
        const r = interestRate / 100;
        const i = r / 12;
        const n = loanTerm * 12;
        
        if (P > 0 && i > 0 && n > 0) {
             const M = P * ( (i * Math.pow(1 + i, n)) / (Math.pow(1 + i, n) - 1) );
             setMonthlyPayment(M);
             
             const total = M * n;
             setTotalPayable(total);
             setTotalInterest(total - P);
        } else {
            setMonthlyPayment(0);
            setTotalPayable(0);
            setTotalInterest(0);
        }
    }, [price, downPayment, interestRate, loanTerm]);

    const handleAskEmmanuel = async () => {
        setLoading(true);
        const prompt = `I calculated a mortgage for a property worth KES ${price.toLocaleString()}. 
        Downpayment: ${downPayment.toLocaleString()}. 
        Monthly repayment is approx KES ${Math.round(monthlyPayment).toLocaleString()}. 
        Total Interest over ${loanTerm} years is KES ${Math.round(totalInterest).toLocaleString()}.
        I want to get pre-approved or connect with a partner bank (KCB, NCBA, Coop) to verify if I qualify.`;
        
        try {
            const response = await askEmmanuel(null, [], prompt);
            setEmmanuelResponse(response.text);
        } catch (e) {
            setEmmanuelResponse("System busy connecting to banking partners. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-6xl mx-auto mt-12 mb-24 px-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="bg-[#020617] border border-white/10 rounded-[3rem] p-10 md:p-16 shadow-[0_0_150px_rgba(0,0,0,1)] relative overflow-hidden ring-1 ring-white/5">
                {/* Background Decoration */}
                <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/5 rounded-full blur-[100px] pointer-events-none -mr-20 -mt-20"></div>
                <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none"></div>

                <div className="flex items-center gap-6 mb-12 relative z-10 text-left">
                    <div className="bg-blue-600/10 p-5 rounded-[1.5rem] border border-blue-500/20 shadow-inner">
                        <CalculatorIcon className="w-10 h-10 text-blue-500" />
                    </div>
                    <div>
                        <h2 className="text-4xl font-black text-white uppercase tracking-tighter leading-none mb-2">Mortgage Simulator</h2>
                        <p className="text-slate-500 text-xs font-black uppercase tracking-[0.3em]">Live Financial Projection Node</p>
                    </div>
                </div>

                <div className="grid lg:grid-cols-2 gap-16 relative z-10 text-left">
                    {/* Inputs Column */}
                    <div className="space-y-10">
                        {/* Price Input */}
                        <div className="bg-slate-900/40 p-8 rounded-[2.5rem] border border-white/5 shadow-lg">
                            <div className="flex justify-between items-center mb-6">
                                <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Property Value</label>
                                <span className="text-blue-400 font-mono font-black text-lg">KES {price.toLocaleString()}</span>
                            </div>
                            <input 
                                type="range" 
                                min="1000000" 
                                max="100000000" 
                                step="100000" 
                                value={price} 
                                onChange={(e) => setPrice(Number(e.target.value))} 
                                className="w-full accent-blue-600 h-3 bg-slate-950 rounded-full appearance-none cursor-pointer border border-white/10" 
                            />
                        </div>

                        {/* Down Payment Input */}
                        <div className="bg-slate-900/40 p-8 rounded-[2.5rem] border border-white/5 shadow-lg">
                            <div className="flex justify-between items-center mb-6">
                                <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Initial Deposit</label>
                                <span className="text-emerald-400 font-mono font-black text-lg">KES {downPayment.toLocaleString()}</span>
                            </div>
                            <input 
                                type="range" 
                                min="0" 
                                max={price} 
                                step="100000" 
                                value={downPayment} 
                                onChange={(e) => setDownPayment(Number(e.target.value))} 
                                className="w-full accent-emerald-500 h-3 bg-slate-950 rounded-full appearance-none cursor-pointer border border-white/10" 
                            />
                            <div className="mt-4 text-right">
                                <span className="text-[9px] font-black text-slate-400 bg-slate-950 px-3 py-1.5 rounded-lg border border-white/5 uppercase tracking-widest">
                                    {Math.round((downPayment / price) * 100)}% Equity
                                </span>
                            </div>
                        </div>

                        {/* Rate & Term Grid */}
                        <div className="grid grid-cols-2 gap-6">
                            <div className="bg-slate-900/40 p-6 rounded-[2rem] border border-white/5 shadow-lg">
                                <label className="block text-[9px] font-black text-slate-500 uppercase tracking-[0.3em] mb-4">Interest Rate (%)</label>
                                <input 
                                    type="number" 
                                    value={interestRate} 
                                    onChange={(e) => setInterestRate(Number(e.target.value))}
                                    className="w-full bg-slate-950 border border-white/10 rounded-2xl p-4 text-white font-mono focus:border-blue-500 outline-none text-center font-bold" 
                                />
                            </div>
                            <div className="bg-slate-900/40 p-6 rounded-[2rem] border border-white/5 shadow-lg">
                                <label className="block text-[9px] font-black text-slate-500 uppercase tracking-[0.3em] mb-4">Loan Term (Yrs)</label>
                                <input 
                                    type="number" 
                                    value={loanTerm} 
                                    onChange={(e) => setLoanTerm(Number(e.target.value))}
                                    className="w-full bg-slate-950 border border-white/10 rounded-2xl p-4 text-white font-mono focus:border-blue-500 outline-none text-center font-bold" 
                                />
                            </div>
                        </div>
                    </div>

                    {/* Results Column */}
                    <div className="flex flex-col h-full">
                         <div className="bg-gradient-to-br from-slate-900 to-black rounded-[3rem] p-10 border border-white/10 shadow-2xl flex-1 flex flex-col justify-between relative overflow-hidden group">
                             <div className="absolute inset-0 bg-blue-600/5 opacity-0 group-hover:opacity-10 transition-opacity"></div>
                             
                             <div>
                                 <h3 className="text-slate-400 text-[10px] font-black uppercase tracking-[0.4em] mb-8 flex items-center gap-3">
                                    <ChartPieIcon className="w-5 h-5 text-blue-500" />
                                    Repayment Matrix
                                 </h3>
                                 
                                 <div className="mb-10 p-8 bg-black/40 rounded-[2rem] border border-white/5 text-center">
                                     <span className="block text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Est. Monthly Repayment</span>
                                     <div className="text-5xl md:text-6xl font-mono font-black text-white tracking-tighter">
                                         <span className="text-2xl text-slate-600 mr-2 font-sans">KES</span>
                                         {monthlyPayment.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                                     </div>
                                 </div>

                                 <div className="space-y-4">
                                     <div className="flex justify-between text-sm py-3 border-b border-white/5">
                                         <span className="text-slate-500 font-bold text-xs uppercase tracking-wide">Principal</span>
                                         <span className="text-white font-mono font-bold">KES {(price - downPayment).toLocaleString()}</span>
                                     </div>
                                     <div className="flex justify-between text-sm py-3 border-b border-white/5">
                                         <span className="text-slate-500 font-bold text-xs uppercase tracking-wide">Total Interest</span>
                                         <span className="text-rose-400 font-mono font-bold">KES {Math.round(totalInterest).toLocaleString()}</span>
                                     </div>
                                     <div className="flex justify-between text-sm py-3 border-b border-white/5">
                                         <span className="text-slate-500 font-bold text-xs uppercase tracking-wide">Total Cost</span>
                                         <span className="text-blue-400 font-mono font-bold">KES {Math.round(totalPayable).toLocaleString()}</span>
                                     </div>
                                 </div>
                             </div>

                             <div className="mt-10 pt-8 border-t border-white/5">
                                {emmanuelResponse ? (
                                    <div className="bg-blue-900/10 border border-blue-500/20 rounded-[2rem] p-6 animate-in fade-in zoom-in-95">
                                        <div className="flex items-center gap-3 mb-4">
                                            <div className="bg-blue-600/20 p-2 rounded-xl">
                                                <CpuChipIcon className="w-5 h-5 text-blue-400" />
                                            </div>
                                            <span className="font-black text-blue-300 text-[9px] uppercase tracking-[0.3em]">Emmanuel AI Analysis</span>
                                        </div>
                                        <p className="text-slate-300 text-xs font-medium leading-relaxed whitespace-pre-line">{emmanuelResponse}</p>
                                    </div>
                                ) : (
                                    <div className="group">
                                        <div className="flex items-center justify-between mb-6">
                                            <div className="flex items-center gap-3">
                                                <BuildingLibraryIcon className="w-5 h-5 text-indigo-500" />
                                                <span className="text-white font-bold text-xs uppercase tracking-widest">Banking Partners</span>
                                            </div>
                                            <div className="flex -space-x-3">
                                                <div className="w-8 h-8 rounded-full bg-red-600 border-2 border-slate-900 shadow-lg" title="NCBA"></div>
                                                <div className="w-8 h-8 rounded-full bg-green-600 border-2 border-slate-900 shadow-lg" title="KCB"></div>
                                                <div className="w-8 h-8 rounded-full bg-blue-600 border-2 border-slate-900 shadow-lg" title="Stanbic"></div>
                                            </div>
                                        </div>
                                        <button 
                                            onClick={handleAskEmmanuel}
                                            disabled={loading}
                                            className="w-full bg-white hover:bg-slate-200 text-slate-950 font-black uppercase tracking-[0.2em] text-[10px] py-5 rounded-2xl transition-all shadow-xl flex items-center justify-center gap-3 active:scale-95"
                                        >
                                            {loading ? (
                                                <>
                                                    <ArrowPathIcon className="w-4 h-4 animate-spin" />
                                                    <span>Connecting...</span>
                                                </>
                                            ) : (
                                                <>
                                                    <BanknotesIcon className="w-5 h-5" />
                                                    <span>Get Pre-Approved via Emmanuel</span>
                                                </>
                                            )}
                                        </button>
                                        <p className="text-[9px] text-slate-600 text-center mt-4 font-bold uppercase tracking-widest">
                                            Instant API handshake with KCB, NCBA & Stanbic.
                                        </p>
                                    </div>
                                )}
                             </div>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
