/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { 
    PaperAirplaneIcon, 
    UserIcon, 
    CpuChipIcon, 
    DocumentArrowUpIcon, 
    BriefcaseIcon, 
    BuildingOffice2Icon, 
    ShieldCheckIcon, 
    SparklesIcon, 
    LockClosedIcon,
    CheckBadgeIcon,
    RocketLaunchIcon,
    CheckIcon
} from '@heroicons/react/24/solid';
import { askCharity, askEmmanuel } from '../services/gemini.ts';
import { AgentDashboard } from './AgentDashboard.tsx'; 

interface ChatMessage {
    role: 'user' | 'agent';
    text: string;
}

const steps = [
    { id: 1, name: 'Role Selection' },
    { id: 2, name: 'Program Details' },
    { id: 3, name: 'Identity Verification' },
    { id: 4, name: 'Workspace Access' },
];

export const CharityAgent = () => {
    // State to toggle between Chat (Onboarding) and Dashboard
    const [view, setView] = useState<'onboarding' | 'dashboard'>('onboarding');
    
    // Chat State
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isThinking, setIsThinking] = useState(false);
    const [uploadedFile, setUploadedFile] = useState<File | null>(null);
    const [currentStep, setCurrentStep] = useState(1);
    
    // Track selected user role to initialize dashboard correctly
    const [selectedRole, setSelectedRole] = useState<'agent' | 'landlord'>('agent');

    // --- Added local states to satisfy AgentDashboard requirements ---
    const [allMessages, setAllMessages] = useState<Record<string, any>>({
        'ai-emmanuel': [{ id: '0', sender: 'ai', text: "Ready to optimize your portfolio. Sawa?", time: 'Now', status: 'read' }]
    });
    const [chatThreads, setChatThreads] = useState<any[]>([
        { id: 'ai-emmanuel', name: 'Emmanuel AI', lastMsg: 'Market analysis ready.', time: 'Now', unread: 0, online: true, type: 'ai', avatar: 'ai' }
    ]);

    const handleDashboardSendMessage = async (threadId: string, text: string) => {
        const userMsg = { 
            id: Date.now().toString(), 
            sender: 'me', 
            text, 
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), 
            status: 'sent' 
        };

        setAllMessages(prev => ({
            ...prev,
            [threadId]: [...(prev[threadId] || []), userMsg]
        }));

        if (threadId === 'ai-emmanuel') {
            const history = (allMessages[threadId] || []).map((m: any) => ({ role: m.sender === 'me' ? 'user' : (m.sender === 'ai' ? 'agent' : 'user'), text: m.text }));
            const res = await askEmmanuel(null, history, text);
            setAllMessages(prev => ({
                ...prev,
                [threadId]: [...(prev[threadId] || []), { 
                    id: 'ai-' + Date.now(), 
                    sender: 'ai', 
                    text: res.text, 
                    time: 'Now', 
                    status: 'read', 
                    suggestions: res.suggestions 
                }]
            }));
        }
    };
    // ---------------------------------------------------------------------

    const chatEndRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Initial greeting on mount
    useEffect(() => {
        if (view === 'dashboard') return; 

        const initChat = async () => {
            setIsThinking(true);
            try {
                const response = await askCharity([], "Jambo Charity. I am here.");
                setMessages([{ role: 'agent', text: response }]);
            } catch (e) {
                setMessages([{ role: 'agent', text: "System offline. Please refresh." }]);
            } finally {
                setIsThinking(false);
            }
        };
        initChat();
    }, [view]);

    // Auto-scroll
    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, isThinking]);

    const handleSendMessage = async (text: string) => {
        if (!text.trim() || isThinking) return;

        const newMsg: ChatMessage = { role: 'user', text };
        setMessages(prev => [...prev, newMsg]);
        setInput('');
        setIsThinking(true);

        try {
            const response = await askCharity([...messages, newMsg], text);
            setMessages(prev => [...prev, { role: 'agent', text: response }]);
        } catch (e) {
            setMessages(prev => [...prev, { role: 'agent', text: "Connection error." }]);
        } finally {
            setIsThinking(false);
        }
    };

    const handleQuickAction = (type: 'Agent' | 'Landlord') => {
        setSelectedRole(type.toLowerCase() as 'agent' | 'landlord');
        setCurrentStep(2);
        const text = type === 'Agent' 
            ? "I am an Agent looking to monetize my dead leads." 
            : "I am a Landlord looking for automated management.";
        handleSendMessage(text);
    };

    const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files?.[0]) {
            const file = e.target.files[0];
            setUploadedFile(file);
            setCurrentStep(3);
            
            const systemMsgText = `[SYSTEM: User uploaded document: ${file.name}]`;
            const uiMsg: ChatMessage = { role: 'user', text: `📎 Uploaded Secure Document: ${file.name}` };
            setMessages(prev => [...prev, uiMsg]);
            setIsThinking(true);

            try {
                const response = await askCharity([...messages, { role: 'user', text: systemMsgText }], systemMsgText);
                setMessages(prev => [...prev, { role: 'agent', text: response }]);
                setTimeout(() => {
                   setCurrentStep(4);
                }, 3000);
            } catch (err) {
                 setMessages(prev => [...prev, { role: 'agent', text: "Upload verification failed." }]);
            } finally {
                setIsThinking(false);
            }
        }
    };

    if (view === 'dashboard') {
        return (
            <div className="w-full max-w-7xl mx-auto mt-8 h-[85vh] p-4 animate-in fade-in zoom-in-95 duration-500">
                <AgentDashboard 
                    initialMode={selectedRole} 
                    allMessages={allMessages}
                    chatThreads={chatThreads}
                    onSendMessage={handleDashboardSendMessage}
                />
            </div>
        );
    }

    return (
        <div className="w-full max-w-6xl mx-auto mt-8 h-[80vh] animate-in fade-in slide-in-from-bottom-4 flex flex-col md:flex-row gap-6 p-4">
            <div className="w-full md:w-1/3 flex flex-col gap-4">
                <div className="bg-gradient-to-b from-blue-900/20 to-[#020617] border border-blue-500/20 p-6 rounded-3xl relative overflow-hidden shadow-2xl">
                    <div className="absolute top-0 right-0 p-4 opacity-10">
                        <BriefcaseIcon className="w-32 h-32 text-blue-500 transform rotate-12" />
                    </div>
                    <div className="relative z-10">
                        <div className="mb-6">
                            <h2 className="text-xl font-bold text-white mb-2">Partner Onboarding</h2>
                             <div className="flex gap-1.5 mt-2">
                                {steps.map((s) => (
                                    <div 
                                        key={s.id} 
                                        className={`h-1.5 rounded-full flex-1 transition-colors ${
                                            currentStep >= s.id ? 'bg-blue-500' : 'bg-zinc-800'
                                        }`} 
                                        title={s.name}
                                    ></div>
                                ))}
                            </div>
                            <p className="text-xs text-blue-300 font-medium mt-2">{steps[currentStep - 1].name}</p>
                        </div>
                        <div className="space-y-3">
                            <button 
                                onClick={() => handleQuickAction('Agent')}
                                className={`w-full text-left group p-4 rounded-2xl border transition-all duration-300 shadow-lg ${
                                    selectedRole === 'agent' 
                                    ? 'bg-blue-900/20 border-blue-500/50 shadow-blue-900/20' 
                                    : 'bg-zinc-900/40 border-white/5 hover:border-blue-500/30 hover:bg-blue-900/10'
                                }`}
                            >
                                <div className="flex items-center gap-3 mb-2">
                                    <div className={`p-2 rounded-lg transition-colors ${
                                        selectedRole === 'agent' ? 'bg-blue-500/20 text-blue-400' : 'bg-blue-500/10 group-hover:bg-blue-500/20 text-blue-400'
                                    }`}>
                                        <UserIcon className="w-5 h-5" />
                                    </div>
                                    <h3 className="font-bold text-white text-sm">I am an Agent</h3>
                                </div>
                                <p className="text-xs text-zinc-500 group-hover:text-zinc-300 transition-colors leading-relaxed">
                                    Monetize dead leads. Earn <span className="text-blue-400 font-bold">10% commission</span> on every referral we convert.
                                </p>
                            </button>
                            <button 
                                onClick={() => handleQuickAction('Landlord')}
                                className={`w-full text-left group p-4 rounded-2xl border transition-all duration-300 shadow-lg ${
                                    selectedRole === 'landlord' 
                                    ? 'bg-emerald-900/20 border-emerald-500/50 shadow-emerald-900/20' 
                                    : 'bg-zinc-900/40 border-white/5 hover:border-blue-500/30 hover:bg-emerald-900/10'
                                }`}
                            >
                                <div className="flex items-center gap-3 mb-2">
                                    <div className={`p-2 rounded-lg transition-colors ${
                                        selectedRole === 'landlord' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-500/10 group-hover:bg-emerald-500/20 text-emerald-400'
                                    }`}>
                                        <BuildingOffice2Icon className="w-5 h-5" />
                                    </div>
                                    <h3 className="font-bold text-white text-sm">I am a Landlord</h3>
                                </div>
                                <p className="text-xs text-zinc-500 group-hover:text-zinc-300 transition-colors leading-relaxed">
                                    Automated property management. Rent collection & maintenance dispatch on autopilot.
                                </p>
                            </button>
                        </div>
                        {(messages.length > 0 || currentStep === 4) && (
                            <div className="mt-6 pt-6 border-t border-white/10 animate-in fade-in slide-in-from-left-2">
                                 <div className="bg-green-900/20 border border-green-500/30 p-4 rounded-xl">
                                    <h3 className="text-green-400 font-bold text-sm mb-1 flex items-center gap-2">
                                        <CheckBadgeIcon className="w-4 h-4" />
                                        {currentStep === 4 ? 'Access Granted' : 'Demo Mode Active'}
                                    </h3>
                                    <p className="text-zinc-400 text-xs mb-3">
                                        {currentStep === 4 ? 'Verification Successful.' : 'Verification bypassed for demonstration.'}
                                    </p>
                                    <button
                                        onClick={() => setView('dashboard')}
                                        className="w-full bg-white text-black hover:bg-zinc-200 font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg"
                                    >
                                        <RocketLaunchIcon className="w-4 h-4 text-blue-600" />
                                        Launch Workspace
                                    </button>
                                 </div>
                            </div>
                        )}
                    </div>
                </div>
                <div className="bg-zinc-900/30 border border-zinc-800 p-6 rounded-3xl flex-1 flex flex-col items-center justify-center text-center backdrop-blur-sm relative overflow-hidden">
                    <div className="relative mb-3 group">
                         <div className={`absolute inset-0 bg-green-500/20 blur-xl rounded-full animate-pulse transition-all ${currentStep >= 3 ? 'opacity-100' : 'opacity-0'}`}></div>
                         <ShieldCheckIcon className={`w-12 h-12 relative z-10 transition-colors ${currentStep >= 3 ? 'text-green-400' : 'text-zinc-500'}`} />
                    </div>
                    <h3 className="text-zinc-400 font-bold text-sm uppercase tracking-wider">Verification Status</h3>
                    <p className="text-zinc-500 text-xs mt-2 max-w-[200px]">
                        {currentStep === 1 ? 'Select a role to begin.' : 
                         currentStep === 2 ? 'Pending document upload.' : 
                         currentStep === 3 ? 'Verifying documents...' : 'Verification Complete.'}
                    </p>
                </div>
            </div>
            <div className="flex-1 bg-[#09090b] border border-zinc-800 rounded-3xl flex flex-col overflow-hidden shadow-2xl relative">
                <div className="p-4 border-b border-zinc-800 bg-zinc-900/80 backdrop-blur-md flex items-center justify-between z-10">
                    <div className="flex items-center gap-4">
                        <div className="relative">
                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-indigo-600 p-[2px]">
                                <div className="w-full h-full rounded-full bg-black flex items-center justify-center">
                                    <UserIcon className="w-6 h-6 text-purple-400" />
                                </div>
                            </div>
                            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-zinc-900 rounded-full"></div>
                        </div>
                        <div>
                            <h3 className="font-bold text-white text-base">Charity Wanjiku</h3>
                            <p className="text-xs text-purple-400 font-medium bg-purple-900/20 px-2 py-0.5 rounded-full inline-block border border-purple-500/20">
                                Head of Onboarding & Compliance
                            </p>
                        </div>
                    </div>
                    <div className="hidden md:flex items-center gap-1.5 text-[10px] font-bold text-zinc-500 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-full">
                        <LockClosedIcon className="w-3 h-3" />
                        End-to-End Encrypted
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar bg-grid-pattern relative">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/20 pointer-events-none"></div>
                    {messages.map((msg, idx) => (
                        <div key={idx} className={`flex gap-4 relative z-10 ${msg.role === 'user' ? 'flex-row-reverse' : ''} animate-in fade-in slide-in-from-bottom-2`}>
                            <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 mt-1 shadow-lg ${
                                msg.role === 'agent' 
                                ? 'bg-zinc-800 border border-zinc-700 text-purple-400' 
                                : 'bg-blue-600 border border-blue-500 text-white'
                            }`}>
                                {msg.role === 'agent' ? <CpuChipIcon className="w-5 h-5" /> : <UserIcon className="w-5 h-5" />}
                            </div>
                            <div className={`p-4 rounded-2xl max-w-[85%] text-sm leading-relaxed shadow-xl ${
                                msg.role === 'agent' 
                                ? 'bg-zinc-900/90 text-zinc-200 border border-zinc-700 rounded-tl-none backdrop-blur-sm' 
                                : 'bg-gradient-to-br from-blue-600 to-indigo-600 text-white rounded-tr-none'
                            }`}>
                                {msg.text}
                            </div>
                        </div>
                    ))}
                    {isThinking && (
                        <div className="flex gap-4 animate-in fade-in">
                            <div className="w-9 h-9 rounded-full bg-zinc-800 border border-zinc-700 text-purple-400 flex items-center justify-center shrink-0 mt-1">
                                <CpuChipIcon className="w-5 h-5 animate-pulse" />
                            </div>
                            <div className="p-4 rounded-2xl rounded-tl-none bg-zinc-900/90 border border-zinc-700 flex items-center gap-2 w-16">
                                <span className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce"></span>
                                <span className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce delay-100"></span>
                                <span className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce delay-200"></span>
                            </div>
                        </div>
                    )}
                    <div ref={chatEndRef} />
                </div>
                <div className="p-5 bg-zinc-900/90 border-t border-zinc-800 backdrop-blur-md">
                    <div className="flex gap-3 bg-black/50 p-1.5 rounded-2xl border border-zinc-800 focus-within:border-purple-500/50 focus-within:shadow-[0_0_20px_rgba(168,85,247,0.1)] transition-all">
                        <button 
                            onClick={() => fileInputRef.current?.click()}
                            className="p-3 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white rounded-xl transition-colors border border-zinc-700/50 group flex items-center gap-2"
                            title="Upload Identity Documents"
                        >
                            <DocumentArrowUpIcon className="w-5 h-5 group-hover:text-green-400 transition-colors" />
                        </button>
                        <input 
                            type="file"
                            ref={fileInputRef}
                            className="hidden"
                            accept="image/*,.pdf"
                            onChange={handleFileUpload}
                        />
                        <input 
                            type="text" 
                            value={input} 
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage(input)}
                            placeholder="Type your response..."
                            className="flex-1 bg-transparent border-none text-sm text-white focus:ring-0 placeholder-zinc-600 px-2"
                        />
                        <button 
                            onClick={() => handleSendMessage(input)}
                            disabled={isThinking || !input.trim()}
                            className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white p-3 rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-purple-900/20 hover:shadow-purple-900/40 transform hover:scale-105 active:scale-95"
                        >
                            <PaperAirplaneIcon className="w-5 h-5" />
                        </button>
                    </div>
                    <div className="text-center mt-2">
                         <span className="text-[10px] text-zinc-600 flex items-center justify-center gap-1">
                            <LockClosedIcon className="w-3 h-3" />
                            Identity data is encrypted and processed via secure channels.
                        </span>
                    </div>
                </div>
            </div>
        </div>
    );
};