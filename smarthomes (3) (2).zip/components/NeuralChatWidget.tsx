/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { 
    CpuChipIcon, 
    XMarkIcon, 
    PaperAirplaneIcon, 
    ChevronDownIcon,
    ChatBubbleLeftRightIcon,
    SparklesIcon,
    ShieldCheckIcon,
    CommandLineIcon,
    UserIcon,
    CheckIcon,
    HomeModernIcon
} from '@heroicons/react/24/solid';

interface Message {
    id: string;
    sender: 'me' | 'ai';
    text: string;
    time: string;
    status?: 'sent' | 'delivered' | 'read';
    suggestions?: string[];
}

interface NeuralChatWidgetProps {
    allMessages: Record<string, Message[]>;
    onSendMessage: (threadId: string, text: string) => void;
    activeListing?: any | null;
}

const MessageStatus = ({ status }: { status: 'sent' | 'delivered' | 'read' }) => {
    if (status === 'read') return (
        <div className="flex -space-x-1 ml-1">
            <CheckIcon className="w-3 h-3 text-blue-500" />
            <CheckIcon className="w-3 h-3 text-blue-500" />
        </div>
    );
    return <CheckIcon className="w-3 h-3 text-zinc-600 ml-1" />;
};

export const NeuralChatWidget: React.FC<NeuralChatWidgetProps> = ({ allMessages, onSendMessage, activeListing }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [input, setInput] = useState('');
    const [isThinking, setIsThinking] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);
    const threadId = 'ai-emmanuel';
    const messages = allMessages[threadId] || [];

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages, isThinking, isOpen]);

    const handleSend = async (override?: string) => {
        const text = override || input;
        if (!text.trim() || isThinking) return;
        
        setIsThinking(true);
        setInput('');
        await onSendMessage(threadId, text);
        setIsThinking(false);
    };

    return (
        <div className="fixed bottom-8 right-8 z-[1000] flex flex-col items-end gap-4 pointer-events-none">
            {/* Chat Panel */}
            {isOpen && (
                <div className="w-[380px] h-[600px] max-h-[80vh] bg-[#09090b]/90 backdrop-blur-2xl border border-zinc-800 rounded-[2.5rem] shadow-[0_40px_100px_rgba(0,0,0,0.8)] flex flex-col overflow-hidden animate-in slide-in-from-bottom-10 fade-in duration-500 pointer-events-auto border-white/5">
                    {/* Header */}
                    <div className="p-6 border-b border-zinc-800 bg-zinc-900/40 flex items-center justify-between">
                        <div className="flex items-center gap-4 text-left">
                            <div className="relative">
                                <div className="w-12 h-12 rounded-2xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center text-blue-500 shadow-2xl">
                                    <CpuChipIcon className="w-7 h-7" />
                                </div>
                                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-4 border-[#09090b] rounded-full animate-pulse shadow-lg"></div>
                            </div>
                            <div>
                                <h3 className="text-white font-black text-sm uppercase tracking-tight leading-none mb-1">Emmanuel AI</h3>
                                <p className="text-[9px] font-black text-blue-500 uppercase tracking-[0.2em]">Forensic Head Node</p>
                            </div>
                        </div>
                        <button 
                            onClick={() => setIsOpen(false)}
                            className="p-2 bg-zinc-800 text-zinc-500 hover:text-white rounded-xl border border-zinc-700 transition-all active:scale-90"
                        >
                            <ChevronDownIcon className="w-5 h-5" />
                        </button>
                    </div>

                    {/* Context Bar */}
                    {activeListing && (
                        <div className="px-6 py-3 bg-blue-600/10 border-b border-blue-500/20 flex items-center gap-3 animate-in slide-in-from-top-2">
                            <div className="w-8 h-8 rounded-lg overflow-hidden shrink-0 border border-zinc-800">
                                <img src={activeListing.image} alt="" className="w-full h-full object-cover" />
                            </div>
                            <div className="text-left min-w-0">
                                <p className="text-[8px] font-black text-blue-500 uppercase tracking-widest mb-0.5">Discussing Asset</p>
                                <p className="text-[10px] text-white font-bold truncate">{activeListing.title}</p>
                            </div>
                        </div>
                    )}

                    {/* Messages */}
                    <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar bg-grid-pattern">
                        {messages.length === 0 && (
                            <div className="h-full flex flex-col items-center justify-center text-center opacity-30 grayscale px-8">
                                <CommandLineIcon className="w-12 h-12 text-zinc-500 mb-4" />
                                <p className="text-[10px] font-black uppercase tracking-[0.4em] leading-relaxed">Initialized Neural Link. Awaiting forensic inquiries about Kenyan assets...</p>
                            </div>
                        )}
                        {messages.map((msg) => (
                            <div key={msg.id} className={`flex flex-col gap-2 ${msg.sender === 'me' ? 'items-end' : 'items-start'} animate-in fade-in slide-in-from-bottom-2`}>
                                <div className={`flex gap-3 max-w-[90%] ${msg.sender === 'me' ? 'flex-row-reverse' : ''}`}>
                                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border shadow-md ${msg.sender === 'ai' ? 'bg-blue-600 border-blue-500 text-white' : 'bg-zinc-800 border-zinc-700 text-zinc-400'}`}>
                                        {msg.sender === 'ai' ? <CpuChipIcon className="w-5 h-5" /> : <UserIcon className="w-5 h-5" />}
                                    </div>
                                    <div className={`p-4 rounded-2xl text-xs leading-relaxed border shadow-xl relative text-left ${msg.sender === 'ai' ? 'bg-zinc-900 text-zinc-100 border-zinc-800 rounded-tl-none' : 'bg-blue-600 text-white border-blue-500 rounded-tr-none'}`}>
                                        {msg.text}
                                    </div>
                                </div>
                                <div className="flex items-center gap-2 px-1">
                                    <span className="text-[8px] font-mono text-zinc-700 font-black uppercase tracking-widest">{msg.time}</span>
                                    {msg.sender === 'me' && <MessageStatus status={msg.status || 'read'} />}
                                </div>
                                {msg.sender === 'ai' && msg.suggestions && (
                                    <div className="flex flex-wrap gap-2 pl-11">
                                        {msg.suggestions.map((s, i) => (
                                            <button key={i} onClick={() => handleSend(s)} className="px-3 py-1.5 bg-blue-600/10 hover:bg-blue-600 hover:text-white border border-blue-500/20 text-blue-400 text-[9px] font-black uppercase tracking-widest rounded-full transition-all active:scale-95 shadow-lg">{s}</button>
                                        ))}
                                    </div>
                                )}
                            </div>
                        ))}
                        {isThinking && (
                            <div className="flex items-start gap-3 animate-in fade-in">
                                <div className="w-8 h-8 rounded-lg bg-blue-600/10 border border-blue-500/20 flex items-center justify-center text-blue-500">
                                    <CpuChipIcon className="w-5 h-5 animate-spin" />
                                </div>
                                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 flex gap-1.5 shadow-2xl">
                                    <span className="w-1 h-1 bg-blue-500 rounded-full animate-bounce"></span>
                                    <span className="w-1 h-1 bg-blue-500 rounded-full animate-bounce delay-100"></span>
                                    <span className="w-1 h-1 bg-blue-500 rounded-full animate-bounce delay-200"></span>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Input */}
                    <div className="p-6 border-t border-zinc-800 bg-zinc-950/80">
                        <div className="flex gap-3 bg-black/60 border border-zinc-800 p-2 rounded-[1.8rem] focus-within:border-blue-500/50 transition-all shadow-[inset_0_2px_15px_rgba(0,0,0,0.8)]">
                            <input 
                                value={input} 
                                onChange={e => setInput(e.target.value)} 
                                onKeyDown={e => e.key === 'Enter' && handleSend()} 
                                placeholder="Inquire forensic intelligence..." 
                                className="flex-1 bg-transparent border-none px-4 text-xs text-white focus:ring-0 outline-none placeholder-zinc-800 font-medium" 
                            />
                            <button onClick={() => handleSend()} className="bg-blue-600 hover:bg-blue-500 text-white p-3 rounded-2xl shadow-xl shadow-blue-900/30 active:scale-95 transition-all">
                                <PaperAirplaneIcon className="w-4 h-4 -rotate-45" />
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Toggle Button */}
            <button 
                onClick={() => setIsOpen(!isOpen)}
                className={`w-16 h-16 rounded-[1.8rem] flex items-center justify-center shadow-[0_20px_50px_rgba(37,99,235,0.4)] transition-all duration-500 pointer-events-auto border-2 active:scale-90 group relative ${
                    isOpen 
                    ? 'bg-zinc-900 border-zinc-800 text-zinc-500 rotate-180 hover:text-white' 
                    : 'bg-blue-600 border-blue-400 text-white hover:bg-blue-500 hover:-translate-y-1'
                }`}
            >
                <div className="absolute inset-0 bg-blue-400 rounded-full animate-ping opacity-10 group-hover:opacity-20 transition-opacity"></div>
                {isOpen ? <XMarkIcon className="w-8 h-8" /> : <ChatBubbleLeftRightIcon className="w-8 h-8" />}
                
                {/* Unread indicator mockup */}
                {!isOpen && (
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-red-600 text-white text-[10px] font-black flex items-center justify-center rounded-full border-4 border-[#050505] shadow-xl animate-bounce">
                        1
                    </div>
                )}
            </button>
        </div>
    );
};
