
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { 
    XMarkIcon, 
    ChartBarIcon, 
    MapPinIcon, 
    BoltIcon, 
    ArrowPathIcon,
    SparklesIcon,
    ShieldCheckIcon,
    CommandLineIcon,
    SignalIcon,
    RocketLaunchIcon,
    CpuChipIcon,
    PresentationChartLineIcon
} from '@heroicons/react/24/solid';

interface InvestmentAuditModalProps {
    isOpen: boolean;
    onClose: () => void;
    onPerformAudit: (location: string, goal: string) => Promise<void>;
    isAuditing: boolean;
    initialLocation?: string;
}

export const InvestmentAuditModal: React.FC<InvestmentAuditModalProps> = ({ 
    isOpen, 
    onClose, 
    onPerformAudit, 
    isAuditing,
    initialLocation = ''
}) => {
    const [location, setLocation] = useState(initialLocation);
    const [goal, setGoal] = useState('');
    const [step, setStep] = useState(1);

    useEffect(() => {
        if (isOpen) {
            setLocation(initialLocation);
            setStep(1);
        }
    }, [isOpen, initialLocation]);

    if (!isOpen) return null;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!location || !goal || isAuditing) return;
        setStep(2);
        await onPerformAudit(location, goal);
    };

    return (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/95 backdrop-blur-md animate-in fade-in duration-300">
            <div className="w-full max-w-2xl bg-[#09090b] border border-zinc-800 rounded-[4rem] shadow-[0_0_120px_rgba(0,0,0,1)] relative overflow-hidden border-white/5 animate-in zoom-in-95 duration-300">
                <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none"></div>
                
                <button 
                    onClick={onClose} 
                    className="absolute top-10 right-10 p-3 bg-zinc-900 text-zinc-500 hover:text-white rounded-2xl border border-zinc-800 transition-all hover:bg-zinc-800 active:scale-95 z-50"
                >
                    <XMarkIcon className="w-6 h-6" />
                </button>

                <div className="p-12 lg:p-20 relative z-10">
                    {step === 1 ? (
                        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                            <div className="flex items-center gap-6 mb-12 text-left">
                                <div className="p-5 bg-blue-600/10 rounded-3xl border border-blue-500/20 text-blue-500 shadow-inner">
                                    <RocketLaunchIcon className="w-10 h-10" />
                                </div>
                                <div>
                                    <h2 className="text-3xl font-black text-white uppercase tracking-tighter leading-none mb-2">Initialize ROI Audit</h2>
                                    <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.4em]">Forensic Yield Synthesis Node v4.5</p>
                                </div>
                            </div>

                            <form onSubmit={handleSubmit} className="space-y-10">
                                <div className="space-y-4">
                                    <label className="block text-[10px] font-black text-zinc-600 uppercase tracking-[0.4em] pl-4 text-left">Geo-Cluster Hub</label>
                                    <div className="relative group">
                                        <MapPinIcon className="absolute left-6 top-1/2 -translate-y-1/2 w-6 h-6 text-blue-500 transition-transform group-focus-within:scale-110" />
                                        <input 
                                            required
                                            value={location} 
                                            onChange={e => setLocation(e.target.value)} 
                                            placeholder="e.g. Westlands Metropolitan Cluster" 
                                            className="w-full bg-zinc-950 border border-zinc-800 rounded-[1.8rem] py-6 pl-16 pr-8 text-sm text-white focus:border-blue-500 outline-none transition-all placeholder:text-zinc-800 font-medium shadow-inner" 
                                        />
                                    </div>
                                </div>

                                <div className="space-y-4">
                                    <label className="block text-[10px] font-black text-zinc-600 uppercase tracking-[0.4em] pl-4 text-left">Investment Thesis & Goal</label>
                                    <div className="relative group">
                                        <BoltIcon className="absolute left-6 top-8 w-6 h-6 text-amber-500" />
                                        <textarea 
                                            required
                                            rows={4}
                                            value={goal} 
                                            onChange={e => setGoal(e.target.value)} 
                                            placeholder="e.g. Analyze long-term appreciation drifts for 3-bedroom assets vs short-term Airbnb occupancy nodes in this cluster." 
                                            className="w-full bg-zinc-950 border border-zinc-800 rounded-[1.8rem] pt-7 pb-6 pl-16 pr-8 text-sm text-white focus:border-blue-500 outline-none transition-all placeholder:text-zinc-800 font-medium shadow-inner resize-none" 
                                        />
                                    </div>
                                </div>

                                <div className="bg-blue-600/5 border border-blue-500/10 p-8 rounded-[2.5rem] flex items-start gap-6 text-left">
                                    <ShieldCheckIcon className="w-8 h-8 text-blue-500/50 shrink-0" />
                                    <p className="text-xs text-zinc-500 leading-relaxed italic">
                                        This procedure triggers a multi-node forensic scan of regional land registries, localized rental drifts, and real-time liquidity signals via Truth-Lens™ archive grounding.
                                    </p>
                                </div>

                                <button 
                                    type="submit" 
                                    disabled={!location || !goal}
                                    className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black uppercase tracking-[0.3em] text-[11px] py-7 rounded-[1.8rem] transition-all shadow-[0_20px_50px_rgba(37,99,235,0.4)] flex items-center justify-center gap-4 active:scale-95 border border-blue-400/30"
                                >
                                    <PresentationChartLineIcon className="w-6 h-6" />
                                    Launch Forensic Protocol
                                </button>
                            </form>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center py-20 text-center animate-in zoom-in-95 duration-1000">
                            <div className="relative mb-16">
                                <div className="absolute inset-0 bg-blue-600/30 blur-[80px] animate-pulse rounded-full"></div>
                                <div className="relative w-32 h-32 rounded-[2.5rem] bg-zinc-950 border border-zinc-800 flex items-center justify-center text-blue-500 shadow-3xl">
                                    <CpuChipIcon className="w-16 h-16 animate-spin-slow" />
                                </div>
                            </div>
                            <h3 className="text-3xl font-black text-white uppercase tracking-tighter mb-4">Neural Drift Analysis Active</h3>
                            <div className="flex flex-col items-center gap-2">
                                <span className="text-[10px] font-black text-blue-400 uppercase tracking-[0.5em] animate-pulse">Establishing Truth-Lens Uplink...</span>
                                <div className="w-48 h-1 bg-zinc-900 rounded-full overflow-hidden mt-6 border border-zinc-800 shadow-inner">
                                    <div className="h-full bg-blue-600 w-full animate-progress-indeterminate shadow-[0_0_15px_rgba(59,130,246,0.8)]"></div>
                                </div>
                            </div>
                            <p className="mt-12 text-zinc-600 font-mono text-[9px] uppercase tracking-widest animate-pulse max-w-sm">"Aggregating regional land value clusters and calculating liquidity delta nodes..."</p>
                        </div>
                    )}
                </div>

                <div className="bg-zinc-950 border-t border-zinc-900 p-6 flex justify-center items-center gap-8">
                    <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
                        <span className="text-[9px] font-black text-zinc-600 uppercase tracking-widest">Grounding Active</span>
                    </div>
                    <div className="w-px h-4 bg-zinc-800"></div>
                    <div className="flex items-center gap-3">
                        <SignalIcon className="w-4 h-4 text-zinc-700" />
                        <span className="text-[9px] font-black text-zinc-600 uppercase tracking-widest">Latency: 0.4MS</span>
                    </div>
                </div>
            </div>
        </div>
    );
};
