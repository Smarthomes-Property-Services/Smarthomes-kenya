
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef } from 'react';
import { 
    PaperAirplaneIcon, PhotoIcon, XMarkIcon, SparklesIcon, VideoCameraIcon, MapIcon, ChartBarIcon, 
    AdjustmentsHorizontalIcon, MagnifyingGlassIcon, ArrowPathIcon, ShieldCheckIcon, BoltIcon,
    SignalIcon, MapPinIcon, PencilSquareIcon, TagIcon, HomeModernIcon, BanknotesIcon,
    ChevronDownIcon, FunnelIcon, RocketLaunchIcon, BookmarkIcon, ClockIcon, TrashIcon,
    ShieldExclamationIcon, EyeIcon, CpuChipIcon
} from '@heroicons/react/24/solid';
import { SavedSearch } from '../services/gemini.ts';

export type SearchMode = 'search' | 'visualize' | 'video' | 'invest' | 'scout' | 'blueprint' | 'forensic';

interface AgentCommandProps {
  onSearch: (query: string, mode: SearchMode, file?: File | null) => void;
  isProcessing: boolean;
  filterPropertyType?: string;
  onPropertyTypeChange?: (val: string) => void;
  filterStatus?: string;
  onStatusChange?: (val: string) => void;
  filterPriceRange?: [number, number];
  onPriceRangeChange?: (val: [number, number]) => void;
  savedSearches?: SavedSearch[];
  onApplySaved?: (search: SavedSearch) => void;
  onSaveSearch?: () => void;
  onClearSaved?: () => void;
}

const placeholders: Record<SearchMode, string> = {
  search: "Try: 'Luxury villas in Karen with ROI > 8%'",
  visualize: "Describe redesign style (e.g. Modern Swahili)",
  video: "Describe the tour (e.g. Drone flyover of the pool)",
  invest: "Analyze ROI in (e.g. Tatu City Land Drifts)",
  scout: "Find amenities near (e.g. Yaya Centre)",
  blueprint: "Generate luxury property concept (e.g. Glass villa in Runda)",
  forensic: "Upload image to scan for scam risks & stock usage..."
};

const TRENDING_CLUSTERS = [
    { name: "Westlands, Nairobi", icon: SignalIcon },
    { name: "Karen, Nairobi", icon: MapPinIcon },
    { name: "Kilimani, Nairobi", icon: BoltIcon }
];

const PROPERTY_TYPES = ["All", "Apartment", "House", "Mansion", "Office", "Villa", "Land", "Penthouse"];
const STATUS_OPTIONS = ["All", "Available", "Rented", "Under Offer", "Sold"];

const TabButton = ({ active, onClick, label, icon: Icon }: { active: boolean, onClick: () => void, label: string, icon: any }) => (
    <button
        type="button"
        onClick={onClick}
        className={`flex items-center gap-2 px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap border ${
            active 
            ? 'bg-blue-600 border-blue-500 text-white shadow-[0_0_20px_rgba(37,99,235,0.4)]' 
            : 'bg-slate-900/50 border-white/5 text-slate-500 hover:text-white hover:bg-slate-800'
        }`}
    >
        <Icon className="w-3.5 h-3.5" />
        {label}
    </button>
);

export const AgentCommand: React.FC<AgentCommandProps> = ({ 
    onSearch, 
    isProcessing,
    filterPropertyType = 'All',
    onPropertyTypeChange,
    filterStatus = 'All',
    onStatusChange,
    filterPriceRange = [0, 250000000],
    onPriceRangeChange,
    savedSearches = [],
    onApplySaved,
    onSaveSearch,
    onClearSaved
}) => {
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<SearchMode>('search');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isFocused, setIsFocused] = useState(false);

  const isComplexQuery = /ROI|yield|profit|investment|>|<|%|percent/i.test(input);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isProcessing) return;
    onSearch(input || (mode === 'forensic' ? "Visual Audit Pulse" : "Automatic Audit"), mode, selectedFile);
    setInput('');
  };

  const handleQuickPulse = (location: string) => {
      if (isProcessing) return;
      onSearch(location, 'search');
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = (ev) => setPreview(ev.target?.result as string);
      reader.readAsDataURL(file);
      if (mode === 'search') setMode('forensic');
    }
  };

  const getStatusColor = (status: string) => {
      switch(status) {
          case 'Available': return 'text-emerald-500';
          case 'Rented': return 'text-amber-500';
          case 'Sold': return 'text-red-500';
          case 'Under Offer': return 'text-blue-500';
          default: return 'text-zinc-500';
      }
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 -mt-8 relative z-30">
      <div className="bg-[#020617] border border-white/10 rounded-[3rem] shadow-[0_40px_100px_rgba(0,0,0,0.8)] p-8 backdrop-blur-2xl transition-all duration-300 relative overflow-hidden group/command ring-1 ring-white/5">
        <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
        {isProcessing && <div className="absolute top-0 bottom-0 w-1 bg-blue-500/50 shadow-[0_0_20px_rgba(59,130,246,0.8)] animate-scan-x z-0 pointer-events-none"></div>}

        <div className="flex items-center justify-between mb-8 px-1 relative z-10">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2">
                <TabButton active={mode === 'search'} onClick={() => setMode('search')} label="Buy / Rent" icon={MagnifyingGlassIcon} />
                <TabButton active={mode === 'forensic'} onClick={() => setMode('forensic')} label="Truth-Lens™ Audit" icon={EyeIcon} />
                <TabButton active={mode === 'invest'} onClick={() => setMode('invest')} label="Invest" icon={ChartBarIcon} />
                <TabButton active={mode === 'blueprint'} onClick={() => setMode('blueprint')} label="Blueprint" icon={PencilSquareIcon} />
                <TabButton active={mode === 'visualize'} onClick={() => setMode('visualize')} label="Design" icon={SparklesIcon} />
                <TabButton active={mode === 'video'} onClick={() => setMode('video')} label="Tour" icon={VideoCameraIcon} />
            </div>
            <div className="flex items-center gap-4">
                {isComplexQuery && (
                    <div className="hidden md:flex items-center gap-2 px-4 py-2 bg-emerald-600/10 border border-emerald-500/20 text-emerald-500 rounded-xl animate-pulse">
                        <CpuChipIcon className="w-4 h-4" />
                        <span className="text-[8px] font-black uppercase tracking-widest">Neural Thinking Active</span>
                    </div>
                )}
                {mode === 'search' && (
                    <button 
                        type="button"
                        onClick={onSaveSearch}
                        className="p-3 bg-blue-600/10 text-blue-500 hover:bg-blue-600 hover:text-white rounded-xl border border-blue-500/20 transition-all active:scale-90 flex items-center gap-2 shadow-sm group/save shrink-0"
                        title="Cache current search protocols"
                    >
                        <BookmarkIcon className="w-4 h-4 group-hover/save:scale-110 transition-transform" />
                        <span className="text-[10px] font-black uppercase tracking-widest hidden sm:inline">Cache Protocol</span>
                    </button>
                )}
            </div>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4 mb-8 relative z-10">
            <div className={`flex-1 relative rounded-[1.5rem] border transition-all duration-300 flex items-center group shadow-inner overflow-hidden ${
                isFocused 
                ? 'bg-slate-900 border-blue-500/50 shadow-[0_0_30px_rgba(59,130,246,0.15)]' 
                : mode === 'forensic' ? 'bg-emerald-950/20 border-emerald-500/20' : 'bg-slate-950 border-white/10'
            }`}>
                {preview && (
                    <div className="pl-4">
                        <div className={`relative w-12 h-12 rounded-xl overflow-hidden border shadow-md ${mode === 'forensic' ? 'border-emerald-500/40' : 'border-zinc-700'}`}>
                            <img src={preview} className="w-full h-full object-cover" alt="Preview" />
                            {mode === 'forensic' && <div className="absolute inset-0 bg-gradient-to-b from-transparent via-emerald-500/40 to-transparent h-[2px] w-full animate-scan-y"></div>}
                            <button type="button" onClick={() => { setPreview(null); setSelectedFile(null); }} className="absolute inset-0 bg-black/60 flex items-center justify-center text-white opacity-0 hover:opacity-100 transition-opacity"><XMarkIcon className="w-5 h-5" /></button>
                        </div>
                    </div>
                )}
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onFocus={() => setIsFocused(true)}
                    onBlur={() => setIsFocused(false)}
                    disabled={isProcessing}
                    className="w-full bg-transparent border-none text-white px-8 py-5 text-sm focus:ring-0 placeholder-zinc-500 font-medium z-10 relative"
                    placeholder={placeholders[mode]}
                />
                <button type="button" onClick={() => fileInputRef.current?.click()} className={`p-4 mr-2 transition-colors relative z-20 ${mode === 'forensic' ? 'text-emerald-500 hover:text-emerald-400' : 'text-zinc-500 hover:text-blue-400'}`} title="Attach Property Asset"><PhotoIcon className="w-6 h-6" /></button>
                <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileSelect} accept="image/*" />
            </div>
            <button 
                type="submit" 
                disabled={isProcessing || ((mode === 'blueprint' || mode === 'forensic') && !input.trim() && !selectedFile)} 
                className={`${
                    mode === 'forensic' 
                    ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-900/20 border-emerald-400/30' 
                    : 'bg-blue-600 hover:bg-blue-500 shadow-blue-900/20 border-blue-400/30'
                } text-white font-black uppercase tracking-[0.2em] px-12 py-5 rounded-[1.5rem] transition-all shadow-xl flex items-center justify-center gap-3 shrink-0 disabled:opacity-50 active:scale-95 text-[11px] border`}
            >
                {isProcessing ? <ArrowPathIcon className="w-5 h-5 animate-spin" /> : mode === 'forensic' ? <ShieldCheckIcon className="w-5 h-5" /> : <RocketLaunchIcon className="w-5 h-5" />}
                <span>{mode === 'forensic' ? 'Execute Audit' : 'Execute Node'}</span>
            </button>
        </form>

        {mode !== 'forensic' && (
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 py-6 border-t border-white/5 mb-6 relative z-10">
                <div className="relative group/select">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none">
                        <HomeModernIcon className="w-4 h-4 text-blue-500" />
                    </div>
                    <select 
                        value={filterPropertyType}
                        onChange={(e) => onPropertyTypeChange?.(e.target.value)}
                        className="w-full bg-slate-900 border border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-300 rounded-2xl pl-12 pr-10 py-4 outline-none focus:border-blue-500/50 transition-all appearance-none cursor-pointer hover:bg-slate-800"
                    >
                        {PROPERTY_TYPES.map(t => <option key={t} value={t} className="bg-slate-950">{t === 'All' ? 'Type: Any' : t}</option>)}
                    </select>
                    <ChevronDownIcon className="absolute right-4 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-500 pointer-events-none group-hover/select:text-blue-500 transition-colors" />
                </div>

                <div className="relative group/select">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none">
                        <div className={`w-1.5 h-1.5 rounded-full animate-pulse shadow-[0_0_8px_currentColor] ${getStatusColor(filterStatus)} bg-current`}></div>
                    </div>
                    <select 
                        value={filterStatus}
                        onChange={(e) => onStatusChange?.(e.target.value)}
                        className="w-full bg-slate-900 border border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-300 rounded-2xl pl-12 pr-10 py-4 outline-none focus:border-blue-500/50 transition-all appearance-none cursor-pointer hover:bg-slate-800"
                    >
                        {STATUS_OPTIONS.map(s => <option key={s} value={s} className="bg-slate-950">{s === 'All' ? 'Status: Any' : s}</option>)}
                    </select>
                    <ChevronDownIcon className="absolute right-4 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-500 pointer-events-none group-hover/select:text-blue-500 transition-colors" />
                </div>

                <div className="col-span-1 lg:col-span-2 relative group/select">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none">
                        <BanknotesIcon className="w-4 h-4 text-emerald-500" />
                    </div>
                    <div className="w-full bg-slate-900 border border-white/10 rounded-2xl pl-12 pr-10 py-2.5 outline-none hover:bg-slate-800 transition-colors">
                        <div className="flex justify-between items-center mb-1">
                            <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Ceiling Budget (KES)</span>
                            <span className="text-[10px] font-black text-blue-400">{(filterPriceRange[1]).toLocaleString()}</span>
                        </div>
                        <input 
                            type="range" min="0" max="250000000" step="1000000"
                            value={filterPriceRange[1]}
                            onChange={(e) => onPriceRangeChange?.([0, Number(e.target.value)])}
                            className="w-full h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                        />
                    </div>
                </div>
            </div>
        )}

        <div className="flex flex-wrap items-center gap-3 relative z-10">
            <span className="text-[9px] font-black text-slate-500 uppercase tracking-[0.3em] mr-2 flex items-center gap-2">
                <ClockIcon className="w-3.5 h-3.5" />
                Registry Cache:
            </span>
            {savedSearches.length > 0 ? (
                <div className="flex flex-wrap gap-2 animate-in fade-in slide-in-from-left-2 duration-500">
                    {savedSearches.map(search => (
                        <button 
                            key={search.id}
                            type="button"
                            onClick={() => onApplySaved?.(search)}
                            className="flex items-center gap-2 px-4 py-2 bg-blue-600/10 border border-blue-500/20 rounded-xl text-[9px] font-bold text-blue-400 hover:bg-blue-600 hover:text-white transition-all active:scale-95 shadow-sm"
                        >
                            <BookmarkIcon className="w-3 h-3" />
                            {search.query}
                        </button>
                    ))}
                    <button 
                        onClick={onClearSaved}
                        className="p-2 bg-rose-500/10 hover:bg-rose-500 text-rose-500 hover:text-white rounded-lg border border-rose-500/20 transition-all active:scale-90"
                        title="Purge Protocol Registry"
                    >
                        <TrashIcon className="w-3.5 h-3.5" />
                    </button>
                </div>
            ) : (
                <div className="flex flex-wrap gap-2">
                    {TRENDING_CLUSTERS.map(cluster => (
                        <button 
                            key={cluster.name}
                            type="button"
                            onClick={() => handleQuickPulse(cluster.name)}
                            className="flex items-center gap-2 px-4 py-2 bg-slate-900 border border-white/10 rounded-xl text-[9px] font-bold text-slate-400 hover:border-blue-500/50 hover:text-blue-400 transition-all active:scale-95 shadow-sm"
                        >
                            <cluster.icon className="w-3.5 h-3.5" />
                            {cluster.name}
                        </button>
                    ))}
                </div>
            )}
        </div>
      </div>
    </div>
  );
};
