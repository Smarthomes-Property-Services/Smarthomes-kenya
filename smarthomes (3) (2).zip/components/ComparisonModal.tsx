
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useMemo, useEffect, useState } from 'react';
import { 
    XMarkIcon, 
    CheckBadgeIcon, 
    MapPinIcon, 
    BanknotesIcon, 
    HomeModernIcon, 
    Squares2X2Icon,
    BoltIcon,
    BeakerIcon, 
    ScaleIcon,
    StarIcon,
    SparklesIcon,
    ExclamationCircleIcon,
    ArrowTrendingUpIcon,
    ArrowsRightLeftIcon,
    CheckIcon,
    ArrowPathIcon,
    InformationCircleIcon,
    TrophyIcon,
    ChartBarIcon,
    ScaleIcon as WeightIcon,
    ExclamationTriangleIcon,
    CubeIcon,
    CalendarIcon,
    ChevronUpIcon,
    ChevronDownIcon,
    EllipsisHorizontalIcon,
    PresentationChartBarIcon,
    ShieldCheckIcon
} from '@heroicons/react/24/solid';
import { PropertyListing } from '../services/gemini.ts';

interface ComparisonModalProps {
    isOpen: boolean;
    onClose: () => void;
    properties: PropertyListing[];
    onViewDetails: (item: PropertyListing) => void;
}

// Forensic Tooltip Component
const Tooltip: React.FC<{ text: string, children: React.ReactNode, width?: string, title?: string }> = ({ text, children, width = "w-64", title = "Forensic Protocol Info" }) => (
    <div className="group relative inline-block">
        {children}
        <div className={`absolute bottom-full left-1/2 -translate-x-1/2 mb-4 px-5 py-4 bg-slate-950 border border-blue-500/30 rounded-[1.5rem] text-[10px] font-medium text-slate-300 tracking-normal leading-relaxed whitespace-normal ${width} opacity-0 group-hover:opacity-100 transition-all duration-500 pointer-events-none z-[100] shadow-[0_30px_70px_rgba(0,0,0,0.9)] scale-90 group-hover:scale-100 origin-bottom border-b-4 border-b-blue-600 backdrop-blur-xl`}>
            <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2 border-b border-white/5 pb-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></div>
                    <span className="text-blue-400 font-black uppercase tracking-[0.2em] text-[8px]">{title}</span>
                </div>
                <p className="leading-relaxed">{text}</p>
            </div>
            <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-blue-600" />
        </div>
    </div>
);

// Forensic Ranking Engine for non-numeric attributes
const getAttributeRank = (type: string, value: string): number => {
    const val = (value || "").toLowerCase();
    if (type === 'tenure') {
        if (val.includes('freehold')) return 3;
        if (val.includes('sectional')) return 2;
        return 1; // Leasehold
    }
    if (type === 'power') {
        if (val.includes('full') || val.includes('solar') || val.includes('hybrid')) return 3;
        if (val.includes('common')) return 2;
        return 1; // None or Basic
    }
    if (type === 'water') {
        if (val.includes('&') || val.includes('both')) return 3;
        if (val.includes('borehole')) return 2;
        return 1; // Council only
    }
    return 0;
};

export const ComparisonModal: React.FC<ComparisonModalProps> = ({ isOpen, onClose, properties, onViewDetails }) => {
    const propertyCount = properties.length;
    const [isCalculated, setIsCalculated] = useState(false);

    useEffect(() => {
        if (isOpen) {
            const timer = setTimeout(() => setIsCalculated(true), 100);
            return () => clearTimeout(timer);
        } else {
            setIsCalculated(false);
        }
    }, [isOpen]);
    
    const metrics = useMemo(() => {
        if (propertyCount < 1) return null;
        
        const priceList = properties.map(p => p.price);
        const vibeList = properties.map(p => p.vibe_score);
        const areaList = properties.map(p => parseFloat(p.floor_area) || 0);
        const bedList = properties.map(p => p.bedrooms);
        const bathList = properties.map(p => p.bathrooms);
        const yearList = properties.map(p => p.year_built);
        
        return {
            minPrice: Math.min(...priceList),
            maxPrice: Math.max(...priceList),
            maxVibe: Math.max(...vibeList),
            minVibe: Math.min(...vibeList),
            maxArea: Math.max(...areaList),
            minArea: Math.min(...areaList),
            maxBeds: Math.max(...bedList),
            minBeds: Math.min(...bedList),
            maxBaths: Math.max(...bathList),
            minBaths: Math.min(...bathList),
            maxYear: Math.max(...yearList),
            minYear: Math.min(...yearList),
            maxTenureRank: Math.max(...properties.map(p => getAttributeRank('tenure', p.tenure))),
            minTenureRank: Math.min(...properties.map(p => getAttributeRank('tenure', p.tenure))),
            maxPowerRank: Math.max(...properties.map(p => getAttributeRank('power', p.power_backup))),
            minPowerRank: Math.min(...properties.map(p => getAttributeRank('power', p.power_backup))),
            maxWaterRank: Math.max(...properties.map(p => getAttributeRank('water', p.water_source))),
            minWaterRank: Math.min(...properties.map(p => getAttributeRank('water', p.water_source))),
            
            isPriceVaried: new Set(priceList).size > 1,
            isVibeVaried: new Set(vibeList).size > 1,
            isAreaVaried: new Set(areaList).size > 1,
            isBedsVaried: new Set(bedList).size > 1,
            isBathsVaried: new Set(bathList).size > 1,
            isYearVaried: new Set(yearList).size > 1,
            isTenureVaried: new Set(properties.map(p => p.tenure)).size > 1,
            isPowerVaried: new Set(properties.map(p => p.power_backup)).size > 1,
            isWaterVaried: new Set(properties.map(p => p.water_source)).size > 1,
        };
    }, [properties, propertyCount]);

    // Weighted triage to identify "Best Value" vs "Premium Peak"
    const triage = useMemo(() => {
        if (!metrics || properties.length === 0) return null;
        
        const scoredProperties = properties.map(p => {
            const priceScore = 1 - (p.price / metrics.maxPrice); // Lower price is better
            const vibeScore = p.vibe_score / metrics.maxVibe; // Higher vibe is better
            const areaScore = (parseFloat(p.floor_area) || 0) / metrics.maxArea; // More area is better
            
            // Weighted score: 40% price, 40% vibe, 20% spatial utility
            const weightedScore = (priceScore * 0.4) + (vibeScore * 0.4) + (areaScore * 0.2);
            return { ...p, weightedScore };
        });

        const sortedByScore = [...scoredProperties].sort((a, b) => b.weightedScore - a.weightedScore);
        const bestValue = sortedByScore[0];
        const premiumPeak = [...properties].sort((a, b) => b.price - a.price)[0];
        
        return { bestValueId: bestValue.id, premiumPeakId: premiumPeak.id };
    }, [properties, metrics]);

    if (!isOpen) return null;

    const ComparisonRow = ({ 
        label, 
        icon: Icon, 
        getValue, 
        isSuperior,
        isInferior,
        compareType,
        isVaried,
        tooltip,
        optimalText,
        subOptimalText,
        optimalLabel = "Optimal Node",
        index = 0
    }: { 
        label: string, 
        icon: any, 
        getValue: (p: PropertyListing) => any,
        isSuperior?: (p: PropertyListing) => boolean,
        isInferior?: (p: PropertyListing) => boolean,
        compareType?: 'price' | 'vibe' | 'area' | 'rank' | 'beds' | 'baths' | 'year',
        isVaried?: boolean,
        tooltip: string,
        optimalText: string,
        subOptimalText?: string,
        optimalLabel?: string,
        index?: number
    }) => (
        <div 
            className={`grid grid-cols-[320px_repeat(auto-fit,minmax(300px,1fr))] border-b border-white/5 py-0 transition-all duration-700 animate-in slide-in-from-bottom-2 ${isVaried ? 'bg-blue-600/[0.01]' : 'opacity-60 grayscale-[0.5]'}`}
            style={{ animationDelay: `${index * 80}ms`, animationFillMode: 'both' }}
        >
            <div className="flex flex-col gap-1 pl-12 justify-center border-r border-white/5 bg-slate-950/40 py-12 sticky left-0 z-20 backdrop-blur-xl shrink-0">
                <Tooltip text={tooltip} width="w-80">
                    <div className="flex items-center gap-4 cursor-help group/label-trigger">
                        <div className={`p-4 rounded-2xl border transition-all group-hover/label-trigger:scale-110 shadow-inner ${isVaried ? 'bg-blue-600/10 border-blue-500/20 text-blue-500' : 'bg-slate-900 border-white/5 text-slate-700'}`}>
                            <Icon className="w-6 h-6" />
                        </div>
                        <span className={`text-[13px] font-black uppercase tracking-[0.25em] ${isVaried ? 'text-slate-300' : 'text-slate-700'}`}>{label}</span>
                    </div>
                </Tooltip>
                {!isVaried && (
                    <span className="text-[8px] font-black text-slate-800 uppercase tracking-[0.3em] ml-20 mt-2 whitespace-nowrap">Registry Parity Detected</span>
                )}
            </div>
            {properties.map(p => {
                const superior = isSuperior?.(p);
                const inferior = isInferior?.(p);
                let driftDisplay = null;
                let relativeWidth = "100%";
                let forensicNote = "";

                if (isVaried && metrics) {
                    if (compareType === 'price') {
                        relativeWidth = superior ? "100%" : `${(metrics.minPrice / p.price) * 100}%`;
                        if (!superior) {
                            const diff = (((p.price - metrics.minPrice) / metrics.minPrice) * 100).toFixed(0);
                            driftDisplay = <span className={`text-[10px] font-mono font-bold mt-1 animate-in fade-in duration-1000 ${inferior ? 'text-rose-500' : 'text-slate-600'}`}>+{diff}% price delta</span>;
                            forensicNote = `Asset premium relative to cluster floor.`;
                        } else {
                            driftDisplay = <span className="text-[10px] text-emerald-500 font-black uppercase tracking-widest mt-1 animate-in fade-in duration-1000">Floor Node</span>;
                            forensicNote = `Most competitive valuation established.`;
                        }
                    } else if (compareType === 'vibe') {
                        relativeWidth = `${(p.vibe_score / metrics.maxVibe) * 100}%`;
                        if (!superior) {
                            const diff = (metrics.maxVibe - p.vibe_score).toFixed(1);
                            driftDisplay = <span className={`text-[10px] font-mono font-bold mt-1 animate-in fade-in duration-1000 ${inferior ? 'text-rose-500' : 'text-slate-600'}`}>-{diff} sentiment gap</span>;
                        } else {
                            driftDisplay = <span className="text-[10px] text-emerald-500 font-black uppercase tracking-widest mt-1 animate-in fade-in duration-1000">Peak Sentiment</span>;
                        }
                    } else if (compareType === 'area') {
                        const curArea = parseFloat(p.floor_area) || 0;
                        relativeWidth = `${(curArea / metrics.maxArea) * 100}%`;
                        if (!superior) {
                            const diff = (((metrics.maxArea - curArea) / metrics.maxArea) * 100).toFixed(0);
                            driftDisplay = <span className={`text-[10px] font-mono font-bold mt-1 animate-in fade-in duration-1000 ${inferior ? 'text-rose-500' : 'text-slate-600'}`}>-{diff}% spatial deficit</span>;
                        } else {
                            driftDisplay = <span className="text-[10px] text-emerald-500 font-black uppercase tracking-widest mt-1 animate-in fade-in duration-1000">Max Footprint</span>;
                        }
                    }
                }

                return (
                    <div 
                        key={p.id} 
                        className={`px-12 py-12 transition-all duration-500 border-r border-white/5 last:border-0 relative group/cell flex flex-col justify-center min-w-[300px] ${superior && isVaried ? 'bg-emerald-500/[0.04]' : inferior && isVaried ? 'bg-rose-500/[0.02]' : ''}`}
                    >
                        {superior && isVaried && <div className="absolute inset-y-0 left-0 w-1.5 bg-emerald-500/60 shadow-[0_0_20px_rgba(16,185,129,0.5)] z-10"></div>}
                        {inferior && isVaried && <div className="absolute inset-y-0 left-0 w-1.5 bg-rose-500/60 shadow-[0_0_20px_rgba(244,63,94,0.5)] z-10"></div>}
                        
                        <div className="flex items-center justify-between gap-6">
                            <div className="flex flex-col text-left">
                                <div className="flex items-center gap-3">
                                    <div className={`text-2xl font-black tracking-tight transition-colors duration-500 flex items-center gap-2 ${superior && isVaried ? 'text-emerald-400' : inferior && isVaried ? 'text-rose-400' : isVaried ? 'text-slate-300' : 'text-slate-800'}`}>
                                        {getValue(p)}
                                        {isVaried && (
                                            superior ? <ChevronUpIcon className="w-5 h-5 text-emerald-500" /> : 
                                            inferior ? <ChevronDownIcon className="w-5 h-5 text-rose-500" /> : 
                                            <EllipsisHorizontalIcon className="w-5 h-5 text-slate-800" />
                                        )}
                                    </div>
                                </div>
                                {driftDisplay}
                                {isVaried && forensicNote && (
                                    <p className="text-[9px] font-black text-slate-800 uppercase tracking-widest mt-2">{forensicNote}</p>
                                )}
                            </div>
                            
                            {isVaried && superior && (
                                <Tooltip text={optimalText} width="w-80" title={`Peak Performance: ${optimalLabel}`}>
                                    <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl animate-in zoom-in duration-500 shadow-[0_0_20px_rgba(16,185,129,0.15)] cursor-help group/optimal">
                                        <TrophyIcon className="w-4 h-4 text-emerald-500 group-hover/optimal:scale-125 transition-transform" />
                                        <span className="text-[9px] font-black uppercase tracking-widest text-emerald-500">Peak</span>
                                    </div>
                                </Tooltip>
                            )}

                            {isVaried && inferior && subOptimalText && (
                                <Tooltip text={subOptimalText} width="w-80" title="Sub-Optimal Node Detected">
                                    <div className="flex items-center gap-2 px-3 py-1.5 bg-rose-500/10 border border-rose-500/30 rounded-xl animate-in zoom-in duration-500 shadow-[0_0_20px_rgba(244,63,94,0.15)] cursor-help group/suboptimal">
                                        <ExclamationTriangleIcon className="w-4 h-4 text-rose-500 group-hover/suboptimal:scale-125 transition-transform" />
                                        <span className="text-[9px] font-black uppercase tracking-widest text-rose-500">Caution</span>
                                    </div>
                                </Tooltip>
                            )}
                        </div>

                        {/* Attribute Density Visualizer */}
                        {isVaried && compareType && (
                            <div className="mt-6 w-full h-2 bg-white/5 rounded-full overflow-hidden shrink-0">
                                <div 
                                    className={`h-full transition-all duration-[1500ms] cubic-bezier(0.16, 1, 0.3, 1) ${superior ? 'bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.6)]' : inferior ? 'bg-rose-600' : 'bg-blue-600 opacity-40'}`}
                                    style={{ width: isCalculated ? relativeWidth : '0%' }}
                                ></div>
                            </div>
                        )}
                    </div>
                );
            })}
        </div>
    );

    return (
        <div className="fixed inset-0 z-[600] flex items-center justify-center p-0 md:p-10 bg-slate-950/98 backdrop-blur-2xl animate-in fade-in duration-300 overflow-hidden">
            <div className="w-full h-full md:h-[95vh] max-w-[1800px] bg-[#020617] border border-white/10 md:rounded-[4rem] shadow-[0_0_150px_rgba(0,0,0,1)] flex flex-col overflow-hidden relative ring-1 ring-white/5">
                <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none"></div>

                {/* Forensic Header Control Hub */}
                <div className="flex items-center justify-between p-10 md:p-16 border-b border-white/5 bg-slate-950/50 relative z-[60] shrink-0">
                    <div className="flex items-center gap-10">
                        <Tooltip text="A side-by-side forensic audit of multiple property nodes to identify high-yield divergence patterns and registry parity.">
                            <div className="p-8 bg-blue-600/10 rounded-[2.5rem] border border-blue-500/20 text-blue-500 shadow-inner cursor-help group/title-node">
                                <ArrowsRightLeftIcon className="w-16 h-16 group-hover/title-node:rotate-12 transition-transform" />
                            </div>
                        </Tooltip>
                        <div className="text-left">
                            <h2 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter leading-none mb-3">Parity Audit</h2>
                            <p className="text-[12px] md:text-sm text-blue-400 font-black uppercase tracking-[0.5em] flex items-center gap-4">
                                <ArrowPathIcon className="w-5 h-5 animate-spin-slow" /> Forensic Node Diffing Active: {propertyCount} Targets
                            </p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-8 bg-slate-900 text-slate-500 hover:text-white rounded-[2.5rem] border border-white/5 transition-all hover:bg-rose-500/20 active:scale-95 shadow-xl">
                        <XMarkIcon className="w-12 h-12" />
                    </button>
                </div>

                <div className="flex-1 overflow-auto custom-scrollbar relative z-10 scroll-smooth">
                    <div className="min-w-fit">
                        {/* Header Sticky Property Node Row */}
                        <div className="grid grid-cols-[320px_repeat(auto-fit,minmax(300px,1fr))] border-b border-white/5 bg-slate-900/60 sticky top-0 z-[50] backdrop-blur-3xl shrink-0">
                            <div className="bg-slate-950/90 border-r border-white/5 flex items-center justify-center py-16 shrink-0 sticky left-0 z-[60]">
                                <div className="flex flex-col items-center gap-6">
                                    <PresentationChartBarIcon className="w-16 h-16 text-blue-500/30 animate-pulse" />
                                    <span className="text-[10px] font-black text-slate-700 uppercase tracking-[0.5em]">Forensic Matrix</span>
                                </div>
                            </div>
                            {properties.map(p => (
                                <div key={p.id} className="p-16 space-y-12 min-w-[300px] border-r border-white/5 last:border-0 relative transition-colors text-left group shrink-0">
                                    <div className="h-72 rounded-[3.5rem] overflow-hidden shadow-3xl relative border border-white/5 bg-slate-950 group-hover:border-blue-500/30 transition-all duration-700">
                                        <img src={p.image_url} className="w-full h-full object-cover transition-transform duration-[8000ms] group-hover:scale-110 ease-out" />
                                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-70" />
                                        <div className="absolute top-10 left-10 right-10 flex flex-col items-start gap-4">
                                            {triage?.bestValueId === p.id && (
                                                <div className="bg-emerald-600 text-white px-6 py-2 rounded-2xl border border-emerald-400/30 text-[11px] font-black uppercase tracking-widest shadow-[0_15px_40px_rgba(16,185,129,0.4)] animate-in slide-in-from-top-4 duration-1000 fill-mode-both">
                                                    Best Value Node
                                                </div>
                                            )}
                                            {triage?.premiumPeakId === p.id && (
                                                <div className="bg-blue-600 text-white px-6 py-2 rounded-2xl border border-blue-400/30 text-[11px] font-black uppercase tracking-widest shadow-[0_15px_40px_rgba(59,130,246,0.4)] animate-in slide-in-from-top-4 duration-1000 fill-mode-both">
                                                    Premium Peak Node
                                                </div>
                                            )}
                                        </div>
                                        <div className="absolute bottom-10 left-10 right-10 flex items-center justify-between">
                                            <Tooltip text="Neural Node ID: Unique identifier within the global asset registry." title="Registry Data">
                                                <div className="bg-black/60 backdrop-blur-md px-5 py-2.5 rounded-2xl border border-white/10 text-[11px] font-black text-white uppercase tracking-widest cursor-help">
                                                    ID: {p.id.split('-')[1] || '0'}
                                                </div>
                                            </Tooltip>
                                            {p.is_verified && (
                                                <Tooltip text="Verified Asset Node: Authenticated via SmartHomes Truth-Lens™ protocol." title="Security Pulse">
                                                    <CheckBadgeIcon className="w-14 h-14 text-emerald-500 drop-shadow-[0_0_20px_rgba(16,185,129,0.6)] cursor-help" />
                                                </Tooltip>
                                            )}
                                        </div>
                                    </div>
                                    <div className="min-h-[100px]">
                                        <h3 className="text-white font-black text-3xl uppercase tracking-tighter truncate leading-none mb-4 group-hover:text-blue-500 transition-colors duration-500">{p.title}</h3>
                                        <p className="text-slate-500 text-[13px] font-black uppercase tracking-widest flex items-center gap-3">
                                            <MapPinIcon className="w-5 h-5 text-blue-500" /> {p.location}
                                        </p>
                                    </div>
                                    <button 
                                        onClick={() => onViewDetails(p)}
                                        className="w-full py-8 bg-white/5 hover:bg-blue-600 text-white rounded-[2rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-2xl transition-all active:scale-95 border border-white/10 group-hover:border-blue-400/30"
                                    >
                                        Access Full Dossier
                                    </button>
                                </div>
                            ))}
                        </div>

                        {/* Attribute Forensic Matrix Rows */}
                        <ComparisonRow 
                            index={1}
                            label="Valuation Node" 
                            icon={BanknotesIcon} 
                            getValue={p => `${p.currency} ${(p.price/1000000).toFixed(1)}M`}
                            isSuperior={p => p.price === metrics?.minPrice}
                            isInferior={p => p.price === metrics?.maxPrice && metrics?.isPriceVaried}
                            compareType="price"
                            isVaried={metrics?.isPriceVaried}
                            tooltip="Analysis of entry price relative to cluster average. Identifying the 'Floor Node' is critical for ROI optimization."
                            optimalText="The Price Floor Node: This asset represents the most competitive entry point in the current cluster."
                            optimalLabel="Price Floor"
                        />
                        <ComparisonRow 
                            index={2}
                            label="Vibe Index" 
                            icon={StarIcon} 
                            getValue={p => (
                                <div className="flex items-center gap-4">
                                    <ArrowTrendingUpIcon className={`w-6 h-6 ${p.vibe_score >= 8 ? 'text-emerald-500' : 'text-slate-800'}`} />
                                    <span className="font-mono text-3xl font-black">{p.vibe_score.toFixed(1)}</span>
                                </div>
                            )}
                            isSuperior={p => p.vibe_score === metrics?.maxVibe} 
                            isInferior={p => p.vibe_score === metrics?.minVibe && metrics?.isVibeVaried}
                            compareType="vibe"
                            isVaried={metrics?.isVibeVaried}
                            tooltip="Neural desirability score based on regional infrastructure drifts and community metadata."
                            optimalText="Peak Desirability Node: Highest relative sentiment match."
                            optimalLabel="Peak Vibe"
                        />
                        <ComparisonRow 
                            index={3}
                            label="Spatial Footprint" 
                            icon={Squares2X2Icon} 
                            getValue={p => p.floor_area} 
                            isSuperior={p => parseFloat(p.floor_area) === metrics?.maxArea}
                            isInferior={p => parseFloat(p.floor_area) === metrics?.minArea && metrics?.isAreaVaried}
                            compareType="area"
                            isVaried={metrics?.isAreaVaried}
                            tooltip="Normalized physical utility area verified via satellite architectural scan."
                            optimalText="Maximum Utility Node: Offers the largest internal footprint."
                            optimalLabel="Spatial Peak"
                        />
                        <ComparisonRow 
                            index={4}
                            label="Verified Bedrooms" 
                            icon={CubeIcon} 
                            getValue={p => `${p.bedrooms} Units`} 
                            isSuperior={p => p.bedrooms === metrics?.maxBeds}
                            isInferior={p => p.bedrooms === metrics?.minBeds && metrics?.isBedsVaried}
                            compareType="beds"
                            isVaried={metrics?.isBedsVaried}
                            tooltip="Total sleeping configurations established via land registry audit."
                            optimalText="Max Bedroom Node: Highest sleeping capacity identified."
                        />
                        <ComparisonRow 
                            index={5}
                            label="Sanitation Nodes" 
                            icon={SparklesIcon} 
                            getValue={p => `${p.bathrooms} Units`} 
                            isSuperior={p => p.bathrooms === metrics?.maxBaths}
                            isInferior={p => p.bathrooms === metrics?.minBaths && metrics?.isBathsVaried}
                            compareType="baths"
                            isVaried={metrics?.isBathsVaried}
                            tooltip="Verified bathroom facilities within the architectural matrix."
                            optimalText="Superior Sanitation: Most bathroom nodes available."
                        />
                        <ComparisonRow 
                            index={6}
                            label="Registry Tenure" 
                            icon={ScaleIcon} 
                            getValue={p => p.tenure} 
                            isSuperior={p => getAttributeRank('tenure', p.tenure) === metrics?.maxTenureRank}
                            isInferior={p => getAttributeRank('tenure', p.tenure) === metrics?.minTenureRank && metrics?.isTenureVaried}
                            compareType="rank"
                            isVaried={metrics?.isTenureVaried}
                            tooltip="The legal bedrock classification of the asset node."
                            optimalText="Superior Security Node: This tenure offers the highest legal permanence."
                            optimalLabel="Tenure Peak"
                        />
                        <ComparisonRow 
                            index={7}
                            label="Power Resilience" 
                            icon={BoltIcon} 
                            getValue={p => p.power_backup}
                            isSuperior={p => getAttributeRank('power', p.power_backup) === metrics?.maxPowerRank}
                            isInferior={p => getAttributeRank('power', p.power_backup) === metrics?.minPowerRank && metrics?.isPowerVaried}
                            compareType="rank"
                            isVaried={metrics?.isPowerVaried}
                            tooltip="Analysis of electrical redundancy (Generators, Solar) for uninterrupted pulse."
                            optimalText="Uninterrupted Pulse Node: Highest electrical redundancy identified."
                            optimalLabel="Power Resilience"
                        />
                        <ComparisonRow 
                            index={8}
                            label="Water Security" 
                            icon={BeakerIcon} 
                            getValue={p => p.water_source}
                            isSuperior={p => getAttributeRank('water', p.water_source) === metrics?.maxWaterRank}
                            isInferior={p => getAttributeRank('water', p.water_source) === metrics?.minWaterRank && metrics?.isWaterVaried}
                            compareType="rank"
                            isVaried={metrics?.isWaterVaried}
                            tooltip="Analyzes resource continuity via municipal/private node verification."
                            optimalText="Redundant Supply Node: Highest degree of water security established."
                            optimalLabel="Water Node"
                        />
                        <ComparisonRow 
                            index={9}
                            label="Synthesis Year" 
                            icon={CalendarIcon} 
                            getValue={p => p.year_built} 
                            isSuperior={p => p.year_built === metrics?.maxYear}
                            isInferior={p => p.year_built === metrics?.minYear && metrics?.isYearVaried}
                            compareType="year"
                            isVaried={metrics?.isYearVaried}
                            tooltip="The year the asset node was established in the Kenyan land registry."
                            optimalText="Newest Node: Most recent architectural establishment."
                        />
                    </div>
                </div>

                <div className="p-12 border-t border-white/5 bg-slate-950 text-center relative z-[60] flex items-center justify-center gap-12 shrink-0">
                    <div className="flex items-center gap-6">
                        <div className="w-3 h-3 rounded-full bg-blue-500 animate-pulse"></div>
                        <span className="text-[12px] font-black text-slate-700 uppercase tracking-[0.5em]">Neural Parity Active</span>
                    </div>
                    <div className="h-6 w-px bg-white/10 mx-6"></div>
                    <div className="flex items-center gap-6">
                        <ShieldCheckIcon className="w-7 h-7 text-emerald-500/40" />
                        <span className="text-[11px] text-slate-500 font-medium italic">"Differential analysis established via real-time search-grounded market drifts."</span>
                    </div>
                </div>
            </div>
        </div>
    );
};
