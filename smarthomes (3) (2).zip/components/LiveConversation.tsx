
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { MicrophoneIcon, StopIcon, SpeakerWaveIcon, SignalIcon } from '@heroicons/react/24/solid';

export const LiveConversation: React.FC = () => {
    const [isActive, setIsActive] = useState(false);
    const [transcription, setTranscription] = useState('');
    const [modelText, setModelText] = useState('');
    const sessionRef = useRef<any>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const nextStartTimeRef = useRef(0);
    const sourcesRef = useRef(new Set<AudioBufferSourceNode>());

    const decode = (base64: string) => {
        const binaryString = atob(base64);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
        return bytes;
    };

    const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> => {
        const dataInt16 = new Int16Array(data.buffer);
        const frameCount = dataInt16.length / numChannels;
        const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
        for (let channel = 0; channel < numChannels; channel++) {
            const channelData = buffer.getChannelData(channel);
            for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
        }
        return buffer;
    };

    const toggleSession = async () => {
        if (isActive) {
            sessionRef.current?.close();
            setIsActive(false);
            return;
        }

        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const inputCtx = new AudioContext({ sampleRate: 16000 });
        const outputCtx = new AudioContext({ sampleRate: 24000 });
        outputAudioContextRef.current = outputCtx;

        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const sessionPromise = ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-12-2025',
            callbacks: {
                onopen: () => {
                    const source = inputCtx.createMediaStreamSource(stream);
                    const processor = inputCtx.createScriptProcessor(4096, 1, 1);
                    processor.onaudioprocess = (e) => {
                        const inputData = e.inputBuffer.getChannelData(0);
                        const int16 = new Int16Array(inputData.length);
                        for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
                        const base64 = btoa(String.fromCharCode(...new Uint8Array(int16.buffer)));
                        sessionPromise.then(s => s.sendRealtimeInput({ media: { data: base64, mimeType: 'audio/pcm;rate=16000' } }));
                    };
                    source.connect(processor);
                    processor.connect(inputCtx.destination);
                },
                onmessage: async (message: LiveServerMessage) => {
                    const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                    if (audioData) {
                        const buffer = await decodeAudioData(decode(audioData), outputCtx, 24000, 1);
                        const source = outputCtx.createBufferSource();
                        source.buffer = buffer;
                        source.connect(outputCtx.destination);
                        nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
                        source.start(nextStartTimeRef.current);
                        nextStartTimeRef.current += buffer.duration;
                        sourcesRef.current.add(source);
                    }
                    if (message.serverContent?.outputTranscription) setModelText(t => t + message.serverContent?.outputTranscription?.text);
                    if (message.serverContent?.inputTranscription) setTranscription(t => t + message.serverContent?.inputTranscription?.text);
                    if (message.serverContent?.turnComplete) { setTranscription(''); setModelText(''); }
                },
                onerror: console.error,
                onclose: () => setIsActive(false)
            },
            config: {
                responseModalities: [Modality.AUDIO],
                systemInstruction: "You are SmartHomes AI, a real estate voice assistant for Kenya. Be helpful, concise, and professional.",
                inputAudioTranscription: {},
                outputAudioTranscription: {}
            }
        });

        sessionRef.current = await sessionPromise;
        setIsActive(true);
    };

    return (
        <div className="fixed bottom-24 right-8 z-[1001] flex flex-col items-end gap-3 pointer-events-none">
            {isActive && (
                <div className="bg-slate-900/90 backdrop-blur-xl border border-blue-500/30 p-6 rounded-[2rem] shadow-3xl w-72 animate-in slide-in-from-right duration-500 pointer-events-auto">
                    <div className="flex items-center gap-3 mb-4">
                        <SignalIcon className="w-5 h-5 text-blue-500 animate-pulse" />
                        <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Live Voice Node</span>
                    </div>
                    <div className="space-y-4">
                        <p className="text-xs text-white/60 italic leading-relaxed truncate">{transcription || "Listening..."}</p>
                        <p className="text-xs text-blue-400 font-medium leading-relaxed">{modelText}</p>
                    </div>
                </div>
            )}
            <button 
                onClick={toggleSession}
                className={`w-16 h-16 rounded-[1.8rem] flex items-center justify-center shadow-3xl transition-all duration-500 pointer-events-auto border-2 active:scale-90 relative ${
                    isActive ? 'bg-red-600 border-red-400 text-white' : 'bg-slate-900 border-white/10 text-blue-500 hover:border-blue-500/50'
                }`}
            >
                {isActive ? <StopIcon className="w-7 h-7" /> : <MicrophoneIcon className="w-7 h-7" />}
                {isActive && <div className="absolute inset-0 bg-red-400 rounded-full animate-ping opacity-20"></div>}
            </button>
        </div>
    );
};
