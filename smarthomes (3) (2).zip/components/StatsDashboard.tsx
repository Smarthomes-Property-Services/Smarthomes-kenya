
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { 
    SignalIcon, 
    ArrowTrendingUpIcon, 
    ShieldCheckIcon, 
    CpuChipIcon, 
    BanknotesIcon, 
    GlobeAltIcon, 
    PresentationChartLineIcon, 
    ChartPieIcon 
} from '@heroicons/react/24/solid';

const StatsCard = ({ label, value, subtext, icon: Icon, color }: any) => (
    <div className="bg-[#020617] border border-white/10 p-8 rounded-[2.5rem] shadow-xl relative overflow-hidden group hover:border-blue-500/30 transition-all">
        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <Icon className="w-24 h-24" />
        </div>
        <div className="flex items-center gap-4 mb-6">
            <div className={`p-3 rounded-2xl bg-slate-950 border border-white/10 shadow-inner ${color}`}>
                <Icon className="w-6 h-6" />
            </div>
            <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">{label}</p>
        </div>
        <h3 className="text-4xl font-black text-white uppercase tracking-tighter mb-2">{value}</h3>
        <p className="text-[10px] text-slate-600 font-bold uppercase tracking-widest">{subtext}</p>
    </div>
);

const AreaChart = () => (
    <div className="relative h-64 w-full mt-8">
        <svg viewBox="0 0 400 100" className="w-full h-full preserve-3d">
            <defs>
                <linearGradient id="gradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
                </linearGradient>
            </defs>
            <path 
                d="M0,80 Q50,40 100,70 T200,30 T300,50 T400,10 L400,100 L0,100 Z" 
                fill="url(#gradient)" 
            />
            <path 
                d="M0,80 Q50,40 100,70 T200,30 T300,50 T400,10" 
                fill="none" 
                stroke="#3b82f6" 
                strokeWidth="2" 
                className="drop-shadow-[0_0_10px_rgba(59,130,246,0.5)]"
            />
        </svg>
        <div className="absolute inset-x-0 bottom-0 flex justify-between px-2 text-[8px] font-black text-slate-700 uppercase tracking-widest pt-4 border-t border-white/5">
            <span>Jan</span><span>Mar</span><span>May</span><span>Jul</span><span>Sep</span><span>Nov</span>
        </div>
    </div>
);

const BarChart = () => (
    <div className="flex items-end justify-between h-48 w-full mt-10 gap-2">
        {[60, 45, 90, 75, 55, 80, 65].map((h, i) => (
            <div key={i} className="flex-1 flex flex-col items-center group">
                <div 
                    className="w-full bg-blue-600/20 border-t-2 border-blue-500 rounded-t-lg group-hover:bg-blue-600/40 transition-all duration-500 relative" 
                    style={{ height: `${h}%` }}
                >
                    <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[9px] font-black text-blue-400 opacity-0 group-hover:opacity-100 transition-opacity">
                        {h}%
                    </div>
                </div>
                <span className="mt-4 text-[8px] font-black text-slate-600 uppercase">Node {i+1}</span>
            </div>
        ))}
    </div>
);

interface StatsDashboardProps {
    onStartAudit?: () => void;
}

export const StatsDashboard: React.FC<StatsDashboardProps> = ({ onStartAudit }) => {
    return (
        <div className="w-full max-w-7xl mx-auto py-12 px-4 animate-in fade-in slide-in-from-bottom-6 duration-1000">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-16 gap-8">
                <div className="text-left">
                    <div className="inline-flex items-center gap-3 px-4 py-2 bg-blue-600/10 border border-blue-500/20 rounded-2xl mb-6">
                        <SignalIcon className="w-5 h-5 text-blue-500 animate-pulse" />
                        <span className="text-[11px] font-black text-blue-400 uppercase tracking-[0.4em]">Forensic Analytics Node: Live</span>
                    </div>
                    <h2 className="text-5xl font-black text-white tracking-tighter uppercase leading-none">Market <span className="text-blue-500">Pulse</span></h2>
                    <p className="text-slate-500 text-lg font-light mt-4 max-w-xl">Forensic verification of the Kenyan real estate ecosystem using Truth-Lens neural mapping.</p>
                </div>
                <div className="bg-[#020617] border border-white/10 px-8 py-6 rounded-[2.5rem] flex items-center gap-6 shadow-2xl">
                    <div className="text-right">
                        <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-1">Global Confidence</p>
                        <p className="text-3xl font-black text-white uppercase">98.4%</p>
                    </div>
                    <div className="w-16 h-16 rounded-full border-4 border-slate-900 border-t-blue-500 rotate-45"></div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
                <StatsCard label="Total Asset Value" value="KES 1.2B" subtext="+14.2% Growth Drift" icon={BanknotesIcon} color="text-emerald-500" />
                <StatsCard label="Verified Assets" value="4,281" subtext="99.9% Forensic Clean" icon={ShieldCheckIcon} color="text-blue-500" />
                <StatsCard label="Active Clusters" value="12 Nodes" subtext="Nairobi Metro Focus" icon={GlobeAltIcon} color="text-indigo-500" />
                <StatsCard label="Neural Inquiries" value="142k" subtext="Emmanuel AI High Load" icon={CpuChipIcon} color="text-purple-500" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                <div className="bg-[#020617] border border-white/10 p-12 rounded-[3.5rem] shadow-2xl text-left">
                    <div className="flex items-center justify-between mb-10">
                        <div>
                            <h4 className="text-white font-black text-xl uppercase tracking-tight mb-2">Market Velocity Index</h4>
                            <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Real-time valuation drift over 12 months</p>
                        </div>
                        <div className="p-3 bg-blue-600/10 rounded-2xl border border-blue-500/20 text-blue-500">
                            <ArrowTrendingUpIcon className="w-6 h-6" />
                        </div>
                    </div>
                    <AreaChart />
                    <div className="grid grid-cols-3 gap-8 mt-16 pt-10 border-t border-white/5">
                        <div>
                            <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">Peak Volatility</p>
                            <p className="text-xl font-black text-white">4.2%</p>
                        </div>
                        <div>
                            <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">Buy Sentiment</p>
                            <p className="text-xl font-black text-emerald-500 uppercase">Strong</p>
                        </div>
                        <div>
                            <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-2">Sync Latency</p>
                            <p className="text-xl font-black text-white">0.4ms</p>
                        </div>
                    </div>
                </div>

                <div className="bg-[#020617] border border-white/10 p-12 rounded-[3.5rem] shadow-2xl text-left">
                    <div className="flex items-center justify-between mb-10">
                        <div>
                            <h4 className="text-white font-black text-xl uppercase tracking-tight mb-2">Regional Interest Nodes</h4>
                            <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Search volume distribution by metro cluster</p>
                        </div>
                        <div className="p-3 bg-purple-600/10 rounded-2xl border border-purple-500/20 text-purple-500">
                            <ChartPieIcon className="w-6 h-6" />
                        </div>
                    </div>
                    <BarChart />
                    <div className="space-y-4 mt-16">
                        <div className="flex items-center justify-between p-4 bg-slate-950 border border-white/5 rounded-2xl">
                            <span className="text-[10px] font-black text-white uppercase tracking-widest">Nairobi Westlands</span>
                            <span className="text-[10px] font-black text-blue-500 uppercase">92% Engagement</span>
                        </div>
                        <div className="flex items-center justify-between p-4 bg-slate-950 border border-white/5 rounded-2xl">
                            <span className="text-[10px] font-black text-white uppercase tracking-widest">Karen Estate</span>
                            <span className="text-[10px] font-black text-indigo-500 uppercase">74% Engagement</span>
                        </div>
                        <div className="flex items-center justify-between p-4 bg-slate-950 border border-white/5 rounded-2xl">
                            <span className="text-[10px] font-black text-white uppercase tracking-widest">Eldoret Hub</span>
                            <span className="text-[10px] font-black text-purple-500 uppercase">41% Engagement</span>
                        </div>
                    </div>
                </div>
            </div>

            <div className="mt-16 p-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-[3rem] shadow-3xl text-center relative overflow-hidden group">
                <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-5 transition-opacity"></div>
                <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
                    <div className="text-left">
                        <h4 className="text-2xl font-black text-white uppercase tracking-tighter mb-2">Deep Insight Required?</h4>
                        <p className="text-blue-100 text-sm font-medium">Request a neural-synthesized forensic audit for your specific portfolio goals.</p>
                    </div>
                    <button 
                        onClick={onStartAudit}
                        className="px-12 py-5 bg-white text-blue-600 font-black uppercase tracking-[0.2em] text-[10px] rounded-2xl shadow-2xl transition-all active:scale-95 flex items-center gap-3"
                    >
                        <CpuChipIcon className="w-4 h-4" /> Initialize Custom Audit
                    </button>
                </div>
            </div>
        </div>
    );
};
