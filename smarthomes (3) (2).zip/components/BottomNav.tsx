
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { 
    HomeIcon, 
    MagnifyingGlassIcon, 
    PlusIcon, 
    HeartIcon, 
    UserIcon,
    ChatBubbleLeftRightIcon,
    CircleStackIcon
} from '@heroicons/react/24/solid';

interface BottomNavProps {
    activeTab: string;
    onTabChange: (tab: string) => void;
    onPostClick: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange, onPostClick }) => {
    return (
        <div className="lg:hidden fixed bottom-0 left-0 right-0 z-[150] bg-white/80 dark:bg-black/80 backdrop-blur-2xl border-t border-zinc-200 dark:border-white/5 pb-safe">
            <div className="flex items-center justify-around h-20 px-2 max-w-md mx-auto">
                <NavBtn 
                    active={activeTab === 'Buy'} 
                    onClick={() => onTabChange('Buy')} 
                    icon={HomeIcon} 
                    label="Explore" 
                />
                <NavBtn 
                    active={activeTab === 'Stats'} 
                    onClick={() => onTabChange('Stats')} 
                    icon={CircleStackIcon} 
                    label="Nodes" 
                />
                
                {/* Android Style FAB in the center */}
                <div className="relative -top-6">
                    <button 
                        onClick={onPostClick}
                        className="w-16 h-16 bg-blue-600 text-white rounded-2xl shadow-[0_15px_40px_rgba(37,99,235,0.4)] flex items-center justify-center active:scale-90 transition-transform ring-4 ring-white dark:ring-[#050505]"
                    >
                        <PlusIcon className="w-8 h-8" />
                    </button>
                </div>

                <NavBtn 
                    active={activeTab === 'Agent'} 
                    onClick={() => onTabChange('Agent')} 
                    icon={ChatBubbleLeftRightIcon} 
                    label="Agent" 
                />
                <NavBtn 
                    active={activeTab === 'Profile'} 
                    onClick={() => onTabChange('Profile')} 
                    icon={UserIcon} 
                    label="Profile" 
                />
            </div>
        </div>
    );
};

const NavBtn = ({ active, onClick, icon: Icon, label }: any) => (
    <button 
        onClick={onClick}
        className={`flex flex-col items-center gap-1.5 px-4 py-2 transition-all duration-300 relative ${active ? 'text-blue-500' : 'text-zinc-500'}`}
    >
        {active && (
            <div className="absolute top-0 w-8 h-1 bg-blue-500 rounded-full animate-in fade-in duration-500"></div>
        )}
        <Icon className={`w-6 h-6 ${active ? 'scale-110' : ''}`} />
        <span className="text-[10px] font-bold uppercase tracking-widest">{label}</span>
    </button>
);
