
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Header, HomePageHero } from './components/Hero.tsx'; 
import { AgentCommand, SearchMode } from './components/InputArea.tsx';
import { ListingsGrid } from './components/LivePreview.tsx';
import { SystemInternals } from './components/SystemInternals.tsx';
import { MortgageCalculator } from './components/MortgageCalculator.tsx';
import { ListingDetailsModal } from './components/ListingDetailsModal.tsx';
import { PostPropertyModal } from './components/PostPropertyModal.tsx';
import { CharityAgent } from './components/CharityAgent.tsx';
import { Pricing } from './components/Pricing.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { NeuralChatWidget } from './components/NeuralChatWidget.tsx';
import { StatsDashboard } from './components/StatsDashboard.tsx';
import { InvestmentAuditModal } from './components/InvestmentAuditModal.tsx';
import { UserProfile } from './components/UserProfile.tsx';
import { BottomNav } from './components/BottomNav.tsx';
import { MobileFilterSheet } from './components/MobileFilterSheet.tsx';
import { ComparisonModal } from './components/ComparisonModal.tsx';
import { supabase } from './services/supabase.ts';
import { 
    generateListings, 
    getTrendingProperties, 
    askAgent,
    PropertyListing, 
    generateAssetVideo,
    performInvestmentAudit,
    enhancePropertyDescription,
    analyzePropertyImage,
    VisionAnalysis,
    SavedSearch
} from './services/gemini.ts';
import { 
    CpuChipIcon, 
    XMarkIcon,
    BellAlertIcon,
    ChatBubbleOvalLeftEllipsisIcon,
    AdjustmentsHorizontalIcon,
    ArrowsRightLeftIcon,
    SparklesIcon,
    ArrowPathIcon,
    TrashIcon,
    FingerPrintIcon,
    ShieldCheckIcon,
    CheckBadgeIcon,
    SignalIcon
} from '@heroicons/react/24/solid';

const BootScreen = ({ onDirectHandshake }: { onDirectHandshake: () => void }) => {
    const [isHandshaking, setIsHandshaking] = useState(false);
    
    const handleHandshake = async () => {
        setIsHandshaking(true);
        // Biometric scan delay
        await new Promise(r => setTimeout(r, 2000));
        onDirectHandshake();
    };

    return (
        <div className="fixed inset-0 z-[5000] bg-[#020203] flex flex-col items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
            
            <div className="relative mb-12 group">
                <div className={`absolute inset-0 bg-blue-600/30 blur-[100px] rounded-full transition-all duration-1000 ${isHandshaking ? 'bg-emerald-500/50 scale-150' : 'animate-pulse'}`}></div>
                <div className={`relative w-32 h-32 bg-zinc-950 border border-zinc-800 rounded-[2.5rem] flex items-center justify-center transition-all duration-700 ${isHandshaking ? 'border-emerald-500/50 shadow-[0_0_50px_rgba(16,185,129,0.4)]' : 'text-blue-500 shadow-2xl animate-in zoom-in'}`}>
                    {isHandshaking ? (
                        <FingerPrintIcon className="w-16 h-16 text-emerald-500 animate-pulse" />
                    ) : (
                        <CpuChipIcon className="w-16 h-16 animate-spin-slow" />
                    )}
                </div>
            </div>

            <div className="flex flex-col items-center gap-8 relative z-10">
                <div className="text-center space-y-2">
                    <h1 className="text-white font-black text-2xl uppercase tracking-[0.5em] animate-pulse">
                        {isHandshaking ? 'Verifying Identity Node' : 'Initializing Keja OS'}
                    </h1>
                    {isHandshaking && (
                        <p className="text-[10px] font-mono text-emerald-500 uppercase tracking-widest animate-in fade-in">emmakiche@gmail.com [ACTIVE]</p>
                    )}
                </div>

                {!isHandshaking ? (
                    <div className="space-y-6 flex flex-col items-center">
                        <div className="w-64 h-1 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                            <div className="h-full bg-blue-600 w-full animate-progress-indeterminate shadow-[0_0_15px_rgba(59,130,246,0.8)]"></div>
                        </div>
                        
                        <div className="pt-8 animate-in slide-in-from-bottom-4 duration-1000">
                            <button 
                                onClick={handleHandshake}
                                className="group relative flex items-center gap-4 px-8 py-4 bg-emerald-600/10 border border-emerald-500/20 rounded-[2rem] hover:bg-emerald-600 hover:text-white transition-all duration-500 shadow-[0_0_30px_rgba(16,185,129,0.1)] active:scale-95"
                            >
                                <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full animate-ping"></div>
                                <div className="p-2 bg-emerald-500/20 rounded-xl group-hover:bg-white/20 transition-colors">
                                    <FingerPrintIcon className="w-5 h-5 text-emerald-500 group-hover:text-white" />
                                </div>
                                <div className="text-left">
                                    <p className="text-[8px] font-black text-emerald-500 group-hover:text-emerald-200 uppercase tracking-widest">Trusted Node Detected</p>
                                    <p className="text-[11px] font-black text-white uppercase tracking-tight">Handshake: emmakiche@gmail.com</p>
                                </div>
                            </button>
                        </div>
                    </div>
                ) : (
                    <div className="space-y-3 flex flex-col items-center">
                         <div className="flex gap-1">
                            {[0,1,2,3].map(i => (
                                <div key={i} className="w-8 h-1 bg-emerald-500/20 rounded-full overflow-hidden">
                                    <div className="h-full bg-emerald-500 animate-progress-indeterminate" style={{ animationDelay: `${i * 150}ms` }}></div>
                                </div>
                            ))}
                         </div>
                         <span className="text-[8px] font-black text-zinc-600 uppercase tracking-widest">Biometric Parity Syncing...</span>
                    </div>
                )}
            </div>
        </div>
    );
};

const NeuralScanOverlay = () => (
    <div className="fixed inset-0 z-[1000] pointer-events-none overflow-hidden flex flex-col items-center justify-center bg-black/40 backdrop-blur-sm animate-in fade-in duration-500">
        <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
        <div className="relative flex flex-col items-center gap-8">
            <div className="w-24 h-24 rounded-[1.8rem] bg-slate-900 border border-blue-500/40 flex items-center justify-center text-blue-500 shadow-[0_0_50px_rgba(59,130,246,0.3)]">
                <ArrowPathIcon className="w-12 h-12 animate-spin" />
            </div>
            <h3 className="text-white font-black text-sm uppercase tracking-[0.6em] animate-pulse">Neural Registry Sync</h3>
        </div>
    </div>
);

const SystemToast = ({ message, onClose }: { message: string, onClose: () => void }) => (
    <div className="fixed top-24 right-8 z-[1100] animate-in slide-in-from-right-10 fade-in duration-500">
        <div className="bg-zinc-950/90 backdrop-blur-2xl border border-blue-500/30 p-6 rounded-[2rem] shadow-[0_30px_70px_rgba(0,0,0,0.6)] flex items-center gap-6 min-w-[320px] group relative overflow-hidden">
            <div className="p-3.5 bg-blue-600/10 rounded-2xl border border-blue-500/20 text-blue-500">
                <BellAlertIcon className="w-6 h-6 animate-pulse" />
            </div>
            <div className="text-left flex-1">
                <p className="text-[9px] font-black text-blue-400 uppercase tracking-[0.4em] mb-1">Emmanuel Dispatch Node</p>
                <p className="text-sm font-black text-white tracking-tight leading-tight">{message}</p>
            </div>
            <button onClick={onClose} className="p-2 text-zinc-600 hover:text-white transition-colors">
                <XMarkIcon className="w-5 h-5" />
            </button>
        </div>
    </div>
);

const App: React.FC = () => {
  const [user, setUser] = useState<any>(null);
  const [isBooting, setIsBooting] = useState(true);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [listings, setListings] = useState<PropertyListing[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState('Buy');
  const [selectedListing, setSelectedListing] = useState<PropertyListing | null>(null);
  const [showPostModal, setShowPostModal] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [showDevMode, setShowDevMode] = useState(false);
  const [headerSearchQuery, setHeaderSearchQuery] = useState('');
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [isFilterSheetOpen, setIsFilterSheetOpen] = useState(false);
  const [isComparisonModalOpen, setIsComparisonModalOpen] = useState(false);
  const [selectedForComparison, setSelectedForComparison] = useState<string[]>([]);
  const [savedSearches, setSavedSearches] = useState<SavedSearch[]>([]);
  const [auditInitialLocation, setAuditInitialLocation] = useState('');
  const [auditReport, setAuditReport] = useState<any>(null);
  const [analysis, setAnalysis] = useState<VisionAnalysis | null>(null);
  const [generatedMedia, setGeneratedMedia] = useState<{ type: 'image' | 'video', url: string, propertyId?: string } | null>(null);
  const [systemToast, setSystemToast] = useState<string | null>(null);
  
  // Infinite Scroll & Pagination State
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [batch, setBatch] = useState(1);
  const loaderSentinelRef = useRef<HTMLDivElement>(null);
  
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('keja-theme');
      if (saved === 'dark' || saved === 'light') return saved;
    }
    return 'dark';
  });

  const [allMessages, setAllMessages] = useState<Record<string, any[]>>({
    'ai-emmanuel': [{ id: '1', sender: 'ai', text: "Handshake verified. Node established. Sawa?", time: 'Now' }]
  });

  const [filterBedrooms, setFilterBedrooms] = useState<number | null>(null);
  const [filterPropertyType, setFilterPropertyType] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [filterPriceRange, setFilterPriceRange] = useState<[number, number]>([0, 250000000]);

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('dark', 'light');
    root.classList.add(theme);
    localStorage.setItem('keja-theme', theme);
  }, [theme]);

  const loadInitialData = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    setUser(session?.user || null);
    const trending = await getTrendingProperties();
    setListings(trending);

    const cachedFavorites = localStorage.getItem('keja-favorites');
    if (cachedFavorites) {
        try {
            setFavorites(JSON.parse(cachedFavorites));
        } catch (e) {
            console.error("Forensic Registry Corrupt:", e);
        }
    }

    setIsBooting(false);
    const saved = localStorage.getItem('keja-saved-searches');
    if (saved) setSavedSearches(JSON.parse(saved));
  }, []);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  useEffect(() => {
    if (!isBooting) {
        localStorage.setItem('keja-favorites', JSON.stringify(favorites));
    }
  }, [favorites, isBooting]);

  const handleDirectHandshake = () => {
    // Artificial direct login sequence for specific requested email
    const mockUser = {
        id: 'direct-node-001',
        email: 'emmakiche@gmail.com',
        user_metadata: {
            full_name: 'Emma Kiche'
        }
    };
    setUser(mockUser);
    setIsBooting(false);
    setSystemToast("Direct Handshake Verified. Jambo Emma!");
  };

  // Infinite Scroll Trigger
  const fetchMoreNodes = useCallback(async () => {
      if (isLoadingMore || !hasMore || isProcessing) return;
      
      setIsLoadingMore(true);
      const nextBatch = batch + 1;
      
      try {
          const results = await generateListings(headerSearchQuery || "Kenyan High-Yield Assets", nextBatch);
          
          if (results.length === 0) {
              setHasMore(false);
          } else {
              setListings(prev => [...prev, ...results]);
              setBatch(nextBatch);
          }
      } catch (e) {
          console.error("Neural fetch timeout established:", e);
      } finally {
          setIsLoadingMore(false);
      }
  }, [isLoadingMore, hasMore, headerSearchQuery, isProcessing, batch]);

  // Infinite Scroll Intersection Protocol
  useEffect(() => {
    const trigger = loaderSentinelRef.current;
    if (!trigger) return;

    const observer = new IntersectionObserver((entries) => {
        const entry = entries[0];
        if (entry.isIntersecting && (activeTab === 'Buy' || activeTab === 'Rent')) {
            fetchMoreNodes();
        }
    }, { 
        threshold: 0.1,
        rootMargin: '400px' // Start loading well before reaching absolute bottom
    });

    observer.observe(trigger);
    return () => observer.disconnect();
  }, [fetchMoreNodes, activeTab]);

  const handleSearch = async (query: string, mode: SearchMode, file?: File | null) => {
    setIsProcessing(true);
    setHeaderSearchQuery(query); 
    setSystemToast(`Synchronizing Registry Nodes for: "${query}"`);
    setAnalysis(null); 
    setHasMore(true);
    setBatch(1); // Reset pagination node on fresh search
    
    try {
      if (file) {
        setSystemToast("Truth-Lens™ Visual Scan Pulse...");
        const base64 = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
        });
        const visionResult = await analyzePropertyImage(base64, query || "Visual Forensic Analysis");
        setAnalysis(visionResult);
        // If forensic mode, we primarily care about the vision result, not generating new listings
        if (mode === 'forensic') {
            setIsProcessing(false);
            setSystemToast("Truth-Lens™ Analysis Synchronized.");
            return;
        }
      }

      if (mode === 'search') {
        const results = await generateListings(query, 1);
        setListings(results);
        setSystemToast(`Syncing ${results.length} active asset nodes.`);
      } else if (mode === 'invest') {
        setAuditInitialLocation(query);
        setIsAuditModalOpen(true);
      } else if (mode === 'forensic' && !file) {
         setSystemToast("Error: No image node detected for forensic scan.");
      }
    } catch (e) {
      console.error(e);
      setSystemToast("Registry Link Timeout.");
    } finally {
      setIsProcessing(false);
      setTimeout(() => setSystemToast(null), 4000);
    }
  };

  const handleToggleFavorite = (id: string) => {
    const isAdding = !favorites.includes(id);
    setFavorites(prev => isAdding ? [...prev, id] : prev.filter(x => x !== id));
    setSystemToast(isAdding ? "Asset archived to Saved Clusters." : "Asset removed from Registry Cache.");
    setTimeout(() => setSystemToast(null), 3000);
  };

  const handleToggleComparison = (id: string) => {
    setSelectedForComparison(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleSaveSearch = () => {
    if (!user) {
        setShowAuthModal(true);
        return;
    }
    const timestampLabel = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newSearch: SavedSearch = {
        id: Date.now().toString(),
        query: headerSearchQuery || `Registry Node @ ${timestampLabel}`,
        filters: {
            type: filterPropertyType,
            status: filterStatus,
            bedrooms: filterBedrooms,
            priceRange: filterPriceRange
        },
        timestamp: Date.now()
    };
    const updated = [newSearch, ...savedSearches].slice(0, 10);
    setSavedSearches(updated);
    localStorage.setItem('keja-saved-searches', JSON.stringify(updated));
    setSystemToast("Search Protocol cached in User Dossier.");
    setTimeout(() => setSystemToast(null), 3000);
  };

  const handleApplySavedSearch = (search: SavedSearch) => {
    setHeaderSearchQuery(search.query);
    setFilterPropertyType(search.filters.type);
    setFilterStatus(search.filters.status);
    setFilterBedrooms(search.filters.bedrooms);
    setFilterPriceRange(search.filters.priceRange);
    handleSearch(search.query, 'search');
    setSystemToast(`Activating cached node: ${search.query}`);
    setTimeout(() => setSystemToast(null), 3000);
  };

  const handleClearSavedSearches = () => {
      setSavedSearches([]);
      localStorage.removeItem('keja-saved-searches');
      setSystemToast("Protocol Registry purged.");
      setTimeout(() => setSystemToast(null), 3000);
  };

  const handleSendMessage = async (threadId: string, text: string, agent: string = 'emmanuel') => {
    const userMsg = { id: Date.now().toString(), sender: 'me', text, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), status: 'sent' };
    setAllMessages(prev => ({ ...prev, [threadId]: [...(prev[threadId] || []), userMsg] }));
    setIsProcessing(true);
    try {
      const history = (allMessages[threadId] || []).map(m => ({ role: m.sender === 'me' ? 'user' : 'model', text: m.text }));
      const response = await askAgent(agent, history, text);
      const aiMsg = { id: 'ai-' + Date.now(), sender: 'ai', text: response.text, time: 'Now', status: 'read', suggestions: response.suggestions };
      setAllMessages(prev => ({ ...prev, [threadId]: [...(prev[threadId] || []), aiMsg] }));
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  const filteredListings = useMemo(() => {
    return listings.filter(l => {
      const matchesSearch = l.location.toLowerCase().includes(headerSearchQuery.toLowerCase()) || 
                           l.title.toLowerCase().includes(headerSearchQuery.toLowerCase());
      const matchesType = filterPropertyType === 'All' || l.type === filterPropertyType;
      const matchesStatus = filterStatus === 'All' || l.status === filterStatus;
      const matchesBeds = filterBedrooms === null || l.bedrooms >= filterBedrooms;
      const matchesPrice = l.price <= filterPriceRange[1];
      return matchesSearch && matchesType && matchesStatus && matchesBeds && matchesPrice;
    });
  }, [listings, headerSearchQuery, filterPropertyType, filterStatus, filterBedrooms, filterPriceRange]);

  if (isBooting) return <BootScreen onDirectHandshake={handleDirectHandshake} />;

  return (
    <div className={`min-h-screen transition-colors duration-700 ${theme === 'dark' ? 'bg-[#020203] text-white' : 'bg-zinc-50 text-zinc-900'}`}>
      <Header 
        onOpenDev={() => setShowDevMode(true)}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onPostProperty={() => setShowPostModal(true)}
        user={user}
        onAuthClick={() => setShowAuthModal(true)}
        onSignOut={() => { setUser(null); supabase.auth.signOut(); }}
        searchQuery={headerSearchQuery}
        onSearchChange={setHeaderSearchQuery}
        theme={theme}
        onToggleTheme={() => setTheme(prev => prev === 'dark' ? 'light' : 'dark')}
      />

      {isProcessing && <NeuralScanOverlay />}
      {systemToast && <SystemToast message={systemToast} onClose={() => setSystemToast(null)} />}

      <main className="pb-40 text-left">
        {activeTab === 'Buy' && (
          <>
            <HomePageHero firstListing={listings[0]} />
            <AgentCommand 
              onSearch={handleSearch} 
              isProcessing={isProcessing}
              filterPropertyType={filterPropertyType}
              onPropertyTypeChange={setFilterPropertyType}
              filterStatus={filterStatus}
              onStatusChange={setFilterStatus}
              filterPriceRange={filterPriceRange}
              onPriceRangeChange={setFilterPriceRange}
              savedSearches={savedSearches}
              onApplySaved={handleApplySavedSearch}
              onSaveSearch={handleSaveSearch}
              onClearSaved={handleClearSavedSearches}
            />
            <div id="listings-section" className="max-w-[1600px] mx-auto px-6 md:px-16 py-24 text-left">
              <div className="flex items-center justify-between mb-12">
                  <div className="flex flex-col">
                      <h2 className="text-5xl font-black uppercase tracking-tighter">Global <span className="text-blue-500">Registry</span></h2>
                      <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.4em] mt-2">Active forensic nodes: {filteredListings.length}</p>
                  </div>
                  <div className="flex items-center gap-4">
                      {selectedForComparison.length >= 2 && (
                          <div className="flex items-center gap-3 animate-in slide-in-from-right-4 duration-500">
                             <button 
                               onClick={() => setSelectedForComparison([])}
                               className="p-4 bg-slate-900 text-slate-500 hover:text-white rounded-2xl border border-white/5 transition-all"
                               title="Clear selection registry"
                             >
                               <TrashIcon className="w-5 h-5" />
                             </button>
                             <button 
                               onClick={() => setIsComparisonModalOpen(true)}
                               className="flex items-center gap-3 px-8 py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-[2rem] text-[11px] font-black uppercase tracking-widest shadow-[0_15px_40px_rgba(16,185,129,0.4)] transition-all border border-emerald-400/30 active:scale-95"
                             >
                                 <ArrowsRightLeftIcon className="w-5 h-5" />
                                 Compare {selectedForComparison.length} Nodes
                             </button>
                          </div>
                      )}
                  </div>
              </div>
              <ListingsGrid 
                listings={filteredListings}
                onViewDetails={(item) => setSelectedListing(item)}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                filterStatus={filterStatus}
                onStatusChange={setFilterStatus}
                filterType={filterPropertyType}
                onTypeChange={setFilterPropertyType}
                filterBedrooms={filterBedrooms}
                onBedroomsChange={setFilterBedrooms}
                filterPriceRange={filterPriceRange}
                onPriceRangeChange={setFilterPriceRange}
                onCloseAnalysis={() => { setGeneratedMedia(null); setAuditReport(null); setAnalysis(null); }}
                generatedMedia={generatedMedia}
                auditReport={auditReport}
                analysis={analysis}
                isProcessing={isProcessing}
                selectedForComparison={selectedForComparison}
                onToggleComparison={handleToggleComparison}
                isLoadingMore={isLoadingMore}
              />
              
              {/* Infinite Scroll Sentinel Node */}
              {hasMore && (
                <div 
                    ref={loaderSentinelRef} 
                    className="h-32 w-full flex items-center justify-center mt-12" 
                    aria-hidden="true" 
                >
                    <div className="flex flex-col items-center gap-4 animate-in fade-in duration-1000">
                        <div className="w-10 h-10 rounded-xl bg-slate-900 border border-blue-500/20 flex items-center justify-center text-blue-500 shadow-2xl">
                            <ArrowPathIcon className="w-6 h-6 animate-spin" />
                        </div>
                        <span className="text-[10px] font-black text-blue-500 uppercase tracking-[0.6em] animate-pulse">Awaiting Registry Expansion...</span>
                    </div>
                </div>
              )}
            </div>
          </>
        )}

        {activeTab === 'Rent' && (
          <div className="max-w-[1600px] mx-auto px-6 md:px-16 py-24 text-left">
            <h2 className="text-5xl font-black mb-16 uppercase tracking-tighter">Rental <span className="text-blue-500">Nodes</span></h2>
            <ListingsGrid 
                listings={filteredListings.filter(l => l.listing_type === 'Rent' || l.listing_type === 'Lease')}
                onViewDetails={(item) => setSelectedListing(item)}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                filterStatus={filterStatus}
                onStatusChange={setFilterStatus}
                filterType={filterPropertyType}
                onTypeChange={setFilterPropertyType}
                filterBedrooms={filterBedrooms}
                onBedroomsChange={setFilterBedrooms}
                filterPriceRange={filterPriceRange}
                onPriceRangeChange={setFilterPriceRange}
                onCloseAnalysis={() => { setGeneratedMedia(null); setAuditReport(null); setAnalysis(null); }}
                generatedMedia={generatedMedia}
                auditReport={auditReport}
                analysis={analysis}
                isProcessing={isProcessing}
                selectedForComparison={selectedForComparison}
                onToggleComparison={handleToggleComparison}
                isLoadingMore={isLoadingMore}
              />
              {hasMore && (
                <div ref={loaderSentinelRef} className="h-32 w-full flex items-center justify-center mt-12">
                   <div className="w-10 h-10 border-t-2 border-blue-500 rounded-full animate-spin"></div>
                </div>
              )}
          </div>
        )}

        {activeTab === 'Calculator' && <MortgageCalculator />}
        {activeTab === 'Stats' && <StatsDashboard onStartAudit={() => setIsAuditModalOpen(true)} />}
        {activeTab === 'Pricing' && <Pricing />}
        {activeTab === 'Agent' && <CharityAgent />}
        {activeTab === 'Profile' && (
          <UserProfile 
            user={user} 
            onAuthClick={() => setShowAuthModal(true)} 
            favorites={favorites} 
            allListings={listings} 
            onViewDetails={(item) => setSelectedListing(item)} 
            onToggleFavorite={handleToggleFavorite}
            savedSearches={savedSearches}
            onApplySaved={handleApplySavedSearch}
          />
        )}
      </main>

      {/* World-Class Floating Comparison Hub (Comparison Bandage) */}
      {selectedForComparison.length > 0 && (
          <div className="fixed bottom-32 left-1/2 -translate-x-1/2 z-[200] animate-in slide-in-from-bottom-20 duration-500 w-full max-w-4xl px-6 pointer-events-none">
              <div className="bg-slate-950/80 backdrop-blur-3xl border border-blue-500/30 rounded-[2.5rem] p-6 shadow-[0_40px_100px_rgba(0,0,0,0.8)] flex items-center justify-between gap-10 pointer-events-auto relative overflow-hidden group/comp-hub hover:scale-[1.02] transition-all duration-700 animate-hub-pulse">
                  <div className="absolute inset-0 bg-blue-600/[0.03] animate-pulse pointer-events-none"></div>
                  
                  <div className="flex items-center gap-8 min-w-0">
                      <div className="flex -space-x-4">
                          {listings.filter(l => selectedForComparison.includes(l.id)).slice(0, 4).map((p, i) => (
                              <div key={p.id} className="w-16 h-16 rounded-2xl border-4 border-slate-950 overflow-hidden shadow-xl ring-1 ring-white/5 animate-in zoom-in duration-500 transition-transform hover:scale-125 hover:z-10 cursor-pointer">
                                  <img src={p.image_url} className="w-full h-full object-cover" alt="" />
                              </div>
                          ))}
                          {selectedForComparison.length > 4 && (
                              <div className="w-16 h-16 rounded-2xl border-4 border-slate-950 bg-slate-900 flex items-center justify-center text-xs font-black text-blue-500 ring-1 ring-white/5">
                                  +{selectedForComparison.length - 4}
                              </div>
                          )}
                      </div>
                      <div className="text-left">
                          <p className="text-white font-black text-lg uppercase tracking-tight leading-none mb-1">{selectedForComparison.length} Nodes Targetted</p>
                          <p className="text-[10px] text-blue-400 font-black uppercase tracking-[0.4em] flex items-center gap-2">
                             <SignalIcon className="w-3 h-3 animate-pulse" /> Comparison Hub Active
                          </p>
                      </div>
                  </div>

                  <div className="flex items-center gap-4 shrink-0">
                      <button 
                        onClick={() => setSelectedForComparison([])}
                        className="p-4 bg-slate-900/50 hover:bg-rose-600 text-slate-500 hover:text-white rounded-2xl border border-white/5 transition-all shadow-inner group/trash active:scale-90"
                      >
                          <TrashIcon className="w-6 h-6 group-hover/trash:scale-110 transition-transform" />
                      </button>
                      <button 
                        onClick={() => setIsComparisonModalOpen(true)}
                        disabled={selectedForComparison.length < 2}
                        className="px-10 py-5 bg-blue-600 hover:bg-blue-500 disabled:opacity-30 text-white rounded-2xl font-black uppercase tracking-[0.2em] text-[11px] shadow-[0_20px_50px_rgba(37,99,235,0.4)] transition-all active:scale-95 flex items-center gap-4 group/audit relative overflow-hidden"
                      >
                          <div className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover/audit:translate-x-[100%] transition-transform duration-1000 pointer-events-none"></div>
                          <ArrowsRightLeftIcon className="w-5 h-5 group-audit:rotate-12 transition-transform" />
                          {selectedForComparison.length < 2 ? 'Select More Nodes' : 'Execute Parity Audit'}
                      </button>
                  </div>
              </div>
          </div>
      )}

      {selectedListing && (
        <ListingDetailsModal 
          listing={selectedListing} 
          onClose={() => setSelectedListing(null)}
          favorites={favorites}
          onToggleFavorite={handleToggleFavorite}
          allMessages={allMessages}
          onSendMessage={handleSendMessage}
          onLinkProperty={() => {}}
          onRateProperty={(id, rating) => {
             // In a real app, persist this
             setListings(prev => prev.map(l => l.id === id ? {...l, user_rating: rating} : l));
          }}
        />
      )}

      {showAuthModal && <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />}
      {showPostModal && (
        <PostPropertyModal 
          isOpen={showPostModal} 
          onClose={() => setShowPostModal(false)} 
          onSuccess={(data) => {
             const systemMsg = `New asset node deployed [${data.title}]. Synchronizing optimizations.`;
             handleSendMessage('ai-emmanuel', systemMsg);
          }}
        />
      )}
      {showDevMode && <SystemInternals isOpen={showDevMode} onClose={() => setShowDevMode(false)} />}
      
      {isComparisonModalOpen && (
        <ComparisonModal 
            isOpen={isComparisonModalOpen}
            onClose={() => setIsComparisonModalOpen(false)}
            properties={listings.filter(l => selectedForComparison.includes(l.id))}
            onViewDetails={(item) => {
                setSelectedListing(item);
                setIsComparisonModalOpen(false);
            }}
        />
      )}

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} onPostClick={() => setShowPostModal(true)} />
      <NeuralChatWidget allMessages={allMessages} onSendMessage={handleSendMessage} />
    </div>
  );
};

export default App;
