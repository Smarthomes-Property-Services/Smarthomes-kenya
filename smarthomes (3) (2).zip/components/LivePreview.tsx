
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef, useCallback } from 'react';
import mapboxgl from 'mapbox-gl';
import { 
    MapPinIcon, 
    SignalIcon, 
    SparklesIcon, 
    BoltIcon, 
    HeartIcon, 
    XMarkIcon, 
    FireIcon, 
    CheckBadgeIcon, 
    DocumentMagnifyingGlassIcon, 
    Square3Stack3DIcon, 
    ExclamationTriangleIcon, 
    HomeModernIcon, 
    TagIcon, 
    ChevronDownIcon, 
    CameraIcon, 
    ArrowUpRightIcon, 
    StarIcon, 
    ArrowPathIcon, 
    ChartBarIcon, 
    ArrowTrendingUpIcon, 
    CubeIcon,
    PhotoIcon,
    InformationCircleIcon,
    AdjustmentsHorizontalIcon,
    FunnelIcon,
    CheckIcon,
    CheckCircleIcon,
    PresentationChartBarIcon,
    ArrowTrendingDownIcon,
    VideoCameraIcon,
    PlayIcon,
    ArrowsRightLeftIcon,
    CpuChipIcon,
    CircleStackIcon,
    BanknotesIcon,
    BeakerIcon, 
    ArrowDownTrayIcon,
    ArrowPathRoundedSquareIcon,
    ShieldCheckIcon,
    CommandLineIcon,
    ShieldExclamationIcon,
    MagnifyingGlassIcon,
    ScaleIcon
} from '@heroicons/react/24/solid';
import { PropertyListing, VisionAnalysis, MarketPulse as MarketPulseData, getMarketPulse, generatePropertyImage, generateAssetVideo } from '../services/gemini.ts';

mapboxgl.accessToken = 'pk.eyJ1Ijoic21hcnRob21lc2tlbnlhIiwiYSI6ImNscTM5bjFvejAxbHYya254cDJ2ZHF0ZncifQ.uS0N6D9Jk5fK8O_w9f-v_A';

interface ListingsGridProps {
  listings: PropertyListing[];
  isMapView?: boolean;
  isProcessing?: boolean;
  processingProperty?: PropertyListing | null;
  favorites?: string[];
  onToggleFavorite?: (id: string) => void;
  auditReport?: any | null;
  analysis?: VisionAnalysis | null;
  generatedMedia?: { type: 'image' | 'video', url: string, propertyId?: string } | null;
  onCloseAnalysis: () => void;
  onViewDetails?: (item: PropertyListing) => void;
  onRunAudit?: (item: PropertyListing) => void;
  filterStatus: string;
  onStatusChange: (status: string) => void;
  filterType: string;
  onTypeChange: (type: string) => void;
  filterBedrooms: number | null;
  onBedroomsChange: (beds: number | null) => void;
  filterPriceRange: [number, number];
  onPriceRangeChange: (range: [number, number]) => void;
  selectedForComparison: string[];
  onToggleComparison: (id: string) => void;
  onRateProperty: (id: string, rating: number) => void;
  isLoadingMore?: boolean;
}

const PROPERTY_TYPES = ["All", "Apartment", "House", "Mansion", "Office", "Villa", "Land", "Penthouse"];
const STATUS_OPTIONS = ["All", "Available", "Rented", "Under Offer", "Sold"];

// Reusable Tooltip Component for forensic explanations
const Tooltip: React.FC<{ text: string, children: React.ReactNode }> = ({ text, children }) => (
    <div className="group/tooltip relative inline-block">
        {children}
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-4 px-4 py-2 bg-slate-950 border border-white/10 rounded-xl text-[9px] font-black text-white uppercase tracking-widest whitespace-normal w-56 opacity-0 group-hover/tooltip:opacity-100 transition-all duration-300 pointer-events-none z-[100] shadow-[0_20px_50px_rgba(0,0,0,0.9)] scale-90 group-hover/tooltip:scale-100 origin-bottom leading-relaxed text-center">
            {text}
            <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-slate-950" />
        </div>
    </div>
);

const SpecBadge = ({ icon: Icon, value, label, color }: any) => (
    <div className="flex flex-col items-start gap-1 p-3 bg-black/20 border border-white/5 rounded-2xl group/spec hover:border-blue-500/30 transition-all shadow-inner">
        <div className={`p-1.5 rounded-lg bg-slate-900 border border-white/5 ${color} group-hover/spec:scale-110 transition-transform shadow-md`}><Icon className="w-4 h-4" /></div>
        <div className="min-w-0 mt-1">
            <p className="text-[11px] font-black text-white uppercase tracking-tighter leading-none truncate">{value}</p>
            <p className="text-[7px] font-black text-slate-600 uppercase tracking-widest leading-none mt-1">{label}</p>
        </div>
    </div>
);

const PropertyCard: React.FC<{ 
    item: PropertyListing; 
    onViewDetails?: (item: PropertyListing) => void;
    favorites: string[];
    onToggleFavorite?: (id: string) => void;
    isSelectedForComparison: boolean;
    onToggleComparison: (id: string) => void;
    onRateProperty: (id: string, rating: number) => void;
}> = ({ item, onViewDetails, favorites, onToggleFavorite, isSelectedForComparison, onToggleComparison, onRateProperty }) => {
    const isFavorited = favorites.includes(item.id);
    const [localImage, setLocalImage] = useState(item.image_url);
    const [isGeneratingImage, setIsGeneratingImage] = useState(false);
    const [isSynthesized, setIsSynthesized] = useState(false);
    const [tourVideoUrl, setTourVideoUrl] = useState<string | null>(item.video_url || null);
    
    const [mouseOffset, setMouseOffset] = useState({ x: 0, y: 0, rawX: 50, rawY: 50 });
    const [isHovered, setIsHovered] = useState(false);

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) - 0.5;
        const y = ((e.clientY - rect.top) / rect.height) - 0.5;
        const rawX = ((e.clientX - rect.left) / rect.width) * 100;
        const rawY = ((e.clientY - rect.top) / rect.height) * 100;
        setMouseOffset({ x, y, rawX, rawY });
    };

    const checkIsPlaceholder = (url: string | undefined) => {
        if (!url || url.trim() === '') return true;
        const lowerUrl = url.toLowerCase();
        return (
            lowerUrl.includes('placeholder') || 
            lowerUrl.includes('example.com') ||
            lowerUrl.includes('house.jpg') ||
            lowerUrl.includes('apartment.png') ||
            lowerUrl.includes('photo-1512917774080') || 
            lowerUrl.includes('photo-1560518883-ce09059eeffa') || 
            (!url.startsWith('http') && !url.startsWith('data:'))
        );
    };

    const hasNoImage = checkIsPlaceholder(localImage);

    const triggerImageSynthesis = useCallback(async (e?: React.MouseEvent) => {
        if (e) e.stopPropagation();
        if (isGeneratingImage) return;
        setIsGeneratingImage(true);
        try {
            const prompt = `Hyper-realistic professional real estate photography of a luxurious, modern ${item.type} located in ${item.location}, Kenya. Golden hour cinematic lighting, ultra-detailed 8k architectural shot, sharp textures, lush landscaping. Atmosphere: Prestigious, high-end.`;
            const imageUrl = await generatePropertyImage(prompt);
            setLocalImage(imageUrl);
            setIsSynthesized(true);
        } catch (err) {
            console.error("Neural Synthesis Failed:", err);
            if (!localImage || checkIsPlaceholder(localImage)) {
                setLocalImage('https://images.unsplash.com/photo-1600585154340-be6199f7a099?auto=format&fit=crop&w=1200&q=80');
            }
        } finally {
            setIsGeneratingImage(false);
        }
    }, [item.type, item.location, isGeneratingImage, localImage]);

    useEffect(() => {
        if (hasNoImage && !isGeneratingImage) {
            const timer = setTimeout(() => triggerImageSynthesis(), Math.random() * 2000 + 500); 
            return () => clearTimeout(timer);
        }
    }, [hasNoImage, triggerImageSynthesis]);

    const getScoreConfig = (score: number) => {
        if (score >= 8) return { 
            bg: isHovered ? 'bg-emerald-400' : 'bg-emerald-500/90', 
            border: 'border-emerald-400/40', 
            text: 'text-emerald-500/60',
            label: 'High Confidence'
        };
        if (score >= 5) return { 
            bg: isHovered ? 'bg-amber-400' : 'bg-amber-500/90', 
            border: 'border-amber-400/40', 
            text: 'text-amber-500/60',
            label: 'Medium Confidence' 
        };
        return { 
            bg: isHovered ? 'bg-rose-400' : 'bg-rose-500/90', 
            border: 'border-rose-400/40', 
            text: 'text-rose-500/60',
            label: 'Low Confidence'
        };
    };

    const scoreConfig = getScoreConfig(item.vibe_score);

    return (
        <div 
            className={`group relative flex flex-col bg-slate-900 border rounded-[3rem] overflow-hidden transition-all duration-700 text-left preserve-3d ${isSelectedForComparison ? 'border-emerald-500 shadow-[0_40px_100px_rgba(16,185,129,0.2)] scale-[1.01]' : 'border-white/5 hover:border-blue-500/40 hover:-translate-y-2 hover:shadow-[0_40px_80px_rgba(59,130,246,0.15)]'}`}
            onMouseMove={handleMouseMove}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => { setIsHovered(false); setMouseOffset({ x: 0, y: 0, rawX: 50, rawY: 50 }); }}
            style={{
                transform: isHovered 
                    ? `perspective(2000px) rotateX(${mouseOffset.y * -6}deg) rotateY(${mouseOffset.x * 6}deg)` 
                    : 'perspective(2000px) rotateX(0deg) rotateY(0deg)',
                transition: 'transform 0.4s cubic-bezier(0.22, 1, 0.36, 1), border 0.3s ease, shadow 0.3s ease'
            }}
        >
            <div 
                className="absolute inset-0 pointer-events-none z-30 transition-opacity duration-700"
                style={{
                    opacity: isHovered ? 1 : 0,
                    background: `radial-gradient(400px circle at ${mouseOffset.rawX}% ${mouseOffset.rawY}%, rgba(59, 130, 246, 0.08), transparent 50%)`
                }}
            />

            <div className="absolute top-6 left-6 z-40">
                <Tooltip text={isSelectedForComparison ? "Remove from audit registry" : "Add to forensic comparison matrix"}>
                    <button 
                        onClick={(e) => { e.stopPropagation(); onToggleComparison(item.id); }}
                        className={`w-11 h-11 rounded-2xl backdrop-blur-xl border transition-all duration-500 flex items-center justify-center shadow-xl active:scale-90 ${isSelectedForComparison ? 'bg-emerald-600 border-emerald-400 text-white shadow-[0_0_20px_rgba(16,185,129,0.5)]' : 'bg-black/40 border-white/20 text-slate-400 hover:text-white hover:border-blue-500/50'}`}
                    >
                        <ArrowsRightLeftIcon className={`w-5 h-5 transition-transform duration-500 ${isSelectedForComparison ? 'rotate-180 scale-110' : ''}`} />
                    </button>
                </Tooltip>
            </div>

            <div className="h-64 w-full relative overflow-hidden bg-slate-950 cursor-pointer" onClick={() => onViewDetails?.(item)}>
                {isGeneratingImage ? (
                    <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950/80 p-8 text-center animate-pulse">
                        <CpuChipIcon className="w-10 h-10 text-emerald-500 animate-spin-slow mb-4" />
                        <span className="text-[9px] font-black text-emerald-400 uppercase tracking-[0.4em]">Neural Handshake...</span>
                    </div>
                ) : (
                    <div className="w-full h-full relative group/img-container">
                        <img src={localImage} alt="" className={`w-full h-full object-cover transition-all duration-[1500ms] ${isHovered ? 'scale-110' : 'scale-100'} ${isSelectedForComparison ? 'opacity-90 grayscale-[0.3]' : 'opacity-85'}`} />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-90 transition-opacity group-hover/img-container:opacity-40"></div>
                        
                        <div className="absolute top-6 right-6">
                            <button onClick={(e) => { e.stopPropagation(); onToggleFavorite?.(item.id); }} className={`p-3 rounded-2xl backdrop-blur-xl border transition-all shadow-xl active:scale-90 ${isFavorited ? 'bg-rose-600 border-rose-400 text-white' : 'bg-black/40 border-white/20 text-slate-400 hover:text-white'}`}>
                                <HeartIcon className="w-5 h-5" />
                            </button>
                        </div>

                        {isSynthesized && (
                            <div className="absolute bottom-6 left-6 px-3 py-1.5 bg-emerald-600/90 backdrop-blur-md border border-emerald-400/40 rounded-xl text-[8px] font-black text-white uppercase tracking-widest flex items-center gap-2 shadow-2xl">
                                <SparklesIcon className="w-3.5 h-3.5" /> Neural Asset
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* Structured Information Architecture */}
            <div className="p-7 space-y-7 flex-1 flex flex-col relative bg-slate-900/40 backdrop-blur-sm">
                
                {/* Section 1: Identity Node */}
                <div className="flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                            <span className={`px-2.5 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest border ${item.listing_type === 'Sale' ? 'bg-indigo-600/10 border-indigo-500/20 text-indigo-400' : 'bg-emerald-600/10 border-emerald-500/20 text-emerald-400'}`}>
                                {item.listing_type}
                            </span>
                            <span className="px-2.5 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest border bg-zinc-800/50 border-white/5 text-zinc-400">
                                {item.tenure}
                            </span>
                        </div>
                        {item.is_verified && (
                            <div className="flex items-center gap-1.5 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 rounded-md">
                                <CheckBadgeIcon className="w-3.5 h-3.5 text-emerald-500" />
                                <span className="text-[7px] font-black text-emerald-500 uppercase tracking-widest">Verified Dossier</span>
                            </div>
                        )}
                    </div>
                    <div className="min-w-0">
                        <h3 className="text-white font-black text-2xl uppercase tracking-tighter truncate leading-none mb-2 group-hover:text-blue-500 transition-colors duration-500">{item.title}</h3>
                        <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.4em] flex items-center gap-2">
                            <MapPinIcon className="w-3.5 h-3.5 text-blue-600/60" /> {item.location}
                        </p>
                    </div>
                </div>

                {/* Section 2: Valuation Cluster (Economic Group) */}
                <div className={`p-5 rounded-[2.5rem] flex items-center justify-between transition-all duration-700 relative overflow-hidden group/val-hub border ${isHovered ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-white/[0.03] border-white/5 shadow-inner'}`}>
                    <div className="text-left relative z-10">
                        <span className="text-[8px] text-slate-600 font-black uppercase tracking-widest block mb-1">Valuation Registry</span>
                        <div className="flex items-baseline gap-2">
                            <span className="text-[11px] font-black text-blue-500 uppercase">{item.currency}</span>
                            <span className="text-3xl font-black text-white font-mono tracking-tighter leading-none">{(item.price/1000000).toFixed(1)}M</span>
                        </div>
                    </div>
                    <div className="text-right relative z-10">
                        <Tooltip text={`Aggregated Trust Score: ${scoreConfig.label}`}>
                            <div className="inline-flex flex-col items-end gap-1.5 cursor-help">
                                <span className={`text-[8px] font-black uppercase tracking-widest leading-none ${scoreConfig.text}`}>Trust Score</span>
                                <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl shadow-lg transition-all duration-500 border ${scoreConfig.border} ${scoreConfig.bg} ${isHovered ? 'animate-vibe-pulse-intense' : 'animate-vibe-pulse'}`}>
                                    <ShieldCheckIcon className="w-4 h-4 text-white" />
                                    <span className="text-xs font-black text-white font-mono">{item.vibe_score.toFixed(1)}</span>
                                </div>
                            </div>
                        </Tooltip>
                    </div>
                </div>

                {/* Section 3: Architectural Specifications (Spatial Group) */}
                <div className="grid grid-cols-3 gap-2.5">
                    <SpecBadge icon={CubeIcon} value={`${item.bedrooms} BR`} label="Sleep Nodes" color="text-blue-500/70" />
                    <SpecBadge icon={SparklesIcon} value={`${item.bathrooms} BA`} label="Sanitation" color="text-indigo-500/70" />
                    <SpecBadge icon={Square3Stack3DIcon} value={item.floor_area} label="Footprint" color="text-purple-500/70" />
                </div>

                {/* Section 4: Forensic Detail Rail (Registry & Support) */}
                <div className="pt-2 flex items-center justify-between border-t border-white/5 pt-6">
                    <div className="flex items-center gap-6">
                        <Tooltip text={`Tenure: ${item.tenure}`}>
                            <div className="flex items-center gap-2 group/tenure cursor-help">
                                <DocumentMagnifyingGlassIcon className="w-4 h-4 text-slate-700 group-hover/tenure:text-blue-500 transition-colors" />
                            </div>
                        </Tooltip>
                        <div className="flex items-center gap-3">
                            <BoltIcon className={`w-4 h-4 transition-colors ${item.power_backup !== 'None' ? 'text-amber-500/60' : 'text-slate-800'}`} title={`Power: ${item.power_backup}`} />
                            <BeakerIcon className={`w-4 h-4 transition-colors ${item.water_source !== 'None' ? 'text-blue-500/60' : 'text-slate-800'}`} title={`Water: ${item.water_source}`} />
                        </div>
                    </div>
                    <div className="flex items-center gap-0.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                            <StarIcon key={star} className={`w-3 h-3 ${star <= (item.user_rating || 0) ? 'text-amber-500' : 'text-slate-800'}`} />
                        ))}
                    </div>
                </div>

                {/* Section 5: Command Hub Action */}
                <div className="pt-2">
                    <button onClick={() => onViewDetails?.(item)} className="w-full py-4 bg-white/5 hover:bg-blue-600 text-slate-400 hover:text-white rounded-[1.5rem] font-black text-[10px] uppercase tracking-[0.3em] transition-all active:scale-95 shadow-xl flex items-center justify-center gap-3 border border-white/5 hover:border-blue-400/30 group/cta-btn">
                        Analyze Full Dossier
                        <ArrowUpRightIcon className="w-4 h-4 group-hover/cta-btn:translate-x-1 group-hover/cta-btn:-translate-y-1 transition-transform" />
                    </button>
                </div>
            </div>
        </div>
    );
};

export const ListingsGrid: React.FC<ListingsGridProps> = ({ 
    listings, onCloseAnalysis, onViewDetails, favorites = [], onToggleFavorite,
    selectedForComparison, onToggleComparison, onRateProperty, analysis, auditReport, generatedMedia, isProcessing, isLoadingMore,
    filterType, onTypeChange, filterStatus, onStatusChange
}) => {
    return (
        <div className="space-y-12 animate-in fade-in duration-1000">
            {(analysis || auditReport || generatedMedia) && (
                <div className="glass-card rounded-[3.5rem] p-10 md:p-14 mb-12 relative overflow-hidden animate-in zoom-in-95 duration-700 shadow-[0_0_150px_rgba(0,0,0,0.8)] border border-blue-500/20 ring-1 ring-white/5">
                    <button onClick={onCloseAnalysis} className="absolute top-8 right-8 p-4 bg-slate-950 text-slate-500 hover:text-white rounded-2xl border border-white/5 hover:bg-rose-500/20 transition-all z-50 shadow-2xl">
                        <XMarkIcon className="w-6 h-6" />
                    </button>
                    {analysis && (
                        <div className="space-y-12 animate-in fade-in duration-1000 text-left">
                            <div className="flex flex-col md:flex-row items-center justify-between gap-8 border-b border-white/5 pb-10">
                                <div className="flex items-center gap-8 text-left w-full">
                                    <div className="p-6 bg-emerald-600/10 rounded-3xl border border-emerald-500/20 text-emerald-500 shadow-inner">
                                        <ShieldCheckIcon className="w-14 h-14" />
                                    </div>
                                    <div>
                                        <h3 className="text-4xl font-black text-white uppercase tracking-tighter leading-none">Truth-Lens™ Audit Report</h3>
                                        <div className="flex items-center gap-4 mt-3">
                                            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                                            <p className="text-[11px] font-black text-emerald-400 uppercase tracking-[0.6em]">Forensic Protocol: ANALYZED</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex items-center gap-6 px-10 py-5 bg-black/40 rounded-[2rem] border border-white/5 shadow-2xl">
                                    <div className="text-right">
                                        <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Authenticity node</p>
                                        <p className={`text-2xl font-black uppercase tracking-tighter font-mono ${analysis.scam_risk === 'Low' ? 'text-emerald-500' : 'text-rose-500'}`}>{analysis.scam_risk} RISK</p>
                                    </div>
                                    <div className="h-12 w-px bg-white/10"></div>
                                    <div className="text-left">
                                        <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Stock Status</p>
                                        <p className={`text-2xl font-black uppercase tracking-tighter font-mono ${analysis.is_stock_photo ? 'text-amber-500' : 'text-emerald-500'}`}>{analysis.is_stock_photo ? 'DUPLICATE' : 'UNIQUE'}</p>
                                    </div>
                                </div>
                            </div>

                            <div className="grid lg:grid-cols-3 gap-10">
                                <div className="space-y-10">
                                    <div className="p-10 bg-slate-950/50 rounded-[3rem] border border-white/5 relative overflow-hidden group shadow-inner flex flex-col h-full justify-between">
                                        <div className="absolute left-0 top-0 bottom-0 w-2 bg-blue-600"></div>
                                        <div>
                                            <p className="text-[10px] font-black text-blue-400 uppercase tracking-[0.5em] mb-6 flex items-center gap-3">
                                                <CommandLineIcon className="w-5 h-5" /> Neural Interpretation
                                            </p>
                                            <p className="text-2xl text-slate-200 leading-relaxed italic font-medium">"{analysis.vibe_check}"</p>
                                        </div>
                                        <div className="mt-10 pt-8 border-t border-white/5">
                                            <div className="flex items-center justify-between text-[9px] font-black text-slate-600 uppercase tracking-widest">
                                                <span>Scan Confidence</span>
                                                <span className="text-blue-500">98.4%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-6">
                                    <div className="bg-slate-950/80 p-8 rounded-[3rem] border border-white/5 shadow-2xl flex items-center gap-6 group hover:border-emerald-500/30 transition-all">
                                        <div className="p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/20 text-emerald-500 group-hover:scale-110 transition-transform shadow-inner">
                                            <BanknotesIcon className="w-8 h-8" />
                                        </div>
                                        <div className="text-left">
                                            <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mb-1">Est. Monthly Yield</p>
                                            <p className="text-3xl font-black text-white font-mono tracking-tighter">{analysis.estimated_rent}</p>
                                        </div>
                                    </div>

                                    <div className="bg-slate-950/80 p-10 rounded-[3rem] border border-white/5 shadow-2xl h-full">
                                        <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.5em] mb-8 flex items-center gap-4">
                                            <MagnifyingGlassIcon className="w-5 h-5 text-indigo-500" />
                                            Spatial Features
                                        </h4>
                                        <div className="flex flex-wrap gap-3">
                                            {analysis.features_detected.map((feat, i) => (
                                                <span key={i} className="px-5 py-2.5 bg-indigo-600/10 border border-indigo-500/20 rounded-xl text-[10px] font-black text-indigo-400 uppercase tracking-widest">
                                                    {feat}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-6">
                                    <div className="bg-slate-950/80 p-10 rounded-[3rem] border border-white/5 shadow-2xl h-full">
                                        <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.5em] mb-8 flex items-center gap-4">
                                            <ShieldExclamationIcon className="w-5 h-5 text-rose-500" />
                                            Registry Flags
                                        </h4>
                                        <div className="space-y-4">
                                            {analysis.maintenance_flags.length > 0 ? analysis.maintenance_flags.map((flag, i) => (
                                                <div key={i} className="flex items-start gap-4 p-5 bg-rose-500/5 border border-rose-500/10 rounded-2xl group hover:border-rose-500/30 transition-all">
                                                    <ExclamationTriangleIcon className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                                                    <p className="text-[11px] font-bold text-slate-400 uppercase tracking-tight leading-tight">{flag}</p>
                                                </div>
                                            )) : (
                                                <div className="flex flex-col items-center justify-center py-10 opacity-30 text-center space-y-4">
                                                    <CheckCircleIcon className="w-12 h-12 text-emerald-500" />
                                                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">No Maintenance Nodes detected</p>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            )}

            {/* Custom Filter Bar */}
            <div className="bg-slate-950/40 border border-white/5 p-6 md:p-8 rounded-[3rem] flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8 mb-4 shadow-2xl relative overflow-hidden group/refinement">
                <div className="absolute inset-0 bg-blue-600/[0.01] pointer-events-none transition-colors"></div>
                <div className="flex flex-col md:flex-row items-start md:items-center gap-6 md:gap-10 w-full lg:w-auto relative z-10 text-left">
                    <div className="flex items-center gap-4">
                        <div className="p-2.5 bg-blue-600/10 rounded-xl text-blue-500 border border-blue-500/20">
                            <AdjustmentsHorizontalIcon className="w-5 h-5" />
                        </div>
                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em]">Refine Pulse</span>
                    </div>
                    <div className="relative group/select w-full md:w-60">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none">
                            <HomeModernIcon className="w-3.5 h-3.5 text-blue-600" />
                        </div>
                        <select 
                            value={filterType}
                            onChange={(e) => onTypeChange(e.target.value)}
                            className="w-full bg-black/40 border border-white/10 text-[9px] font-black uppercase tracking-widest text-white rounded-xl pl-12 pr-10 py-3.5 outline-none focus:border-blue-500/50 appearance-none cursor-pointer hover:bg-black/60 transition-all shadow-inner"
                        >
                            {PROPERTY_TYPES.map(type => (
                                <option key={type} value={type} className="bg-slate-900">{type === 'All' ? 'Asset Class: All' : type}</option>
                            ))}
                        </select>
                        <ChevronDownIcon className="absolute right-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-600 pointer-events-none group-hover/select:text-blue-500 transition-colors" />
                    </div>
                    <div className="h-8 w-px bg-white/10 hidden md:block"></div>
                    <div className="relative group/status-select w-full md:w-52">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none">
                            <TagIcon className="w-3.5 h-3.5 text-emerald-500" />
                        </div>
                        <select 
                            value={filterStatus}
                            onChange={(e) => onStatusChange(e.target.value)}
                            className="w-full bg-black/40 border border-white/10 text-[9px] font-black uppercase tracking-widest text-white rounded-xl pl-12 pr-10 py-3.5 outline-none focus:border-emerald-500/50 appearance-none cursor-pointer hover:bg-black/60 transition-all shadow-inner"
                        >
                            {STATUS_OPTIONS.map(status => (
                                <option key={status} value={status} className="bg-slate-900">{status === 'All' ? 'Registry Status: All' : status}</option>
                            ))}
                        </select>
                        <ChevronDownIcon className="absolute right-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-600 pointer-events-none group-hover/status-select:text-emerald-500 transition-colors" />
                    </div>
                </div>
                <div className="flex items-center gap-4 relative z-10 shrink-0">
                    <div className="px-4 py-2 bg-slate-900 border border-white/5 rounded-xl flex items-center gap-2.5">
                        <SignalIcon className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Synced: {listings.length} Nodes</span>
                    </div>
                </div>
            </div>

            {/* Structured Property Card Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                {listings.map(item => (
                    <PropertyCard 
                        key={item.id} 
                        item={item} 
                        onViewDetails={onViewDetails} 
                        favorites={favorites} 
                        onToggleFavorite={onToggleFavorite} 
                        isSelectedForComparison={selectedForComparison.includes(item.id)}
                        onToggleComparison={onToggleComparison}
                        onRateProperty={onRateProperty}
                    />
                ))}
            </div>

            {isLoadingMore && (
                <div className="mt-16 flex flex-col items-center justify-center gap-4 animate-in fade-in duration-500">
                    <div className="w-10 h-10 bg-slate-900 border border-blue-500/20 rounded-xl flex items-center justify-center text-blue-500 shadow-2xl">
                        <ArrowPathIcon className="w-5 h-5 animate-spin" />
                    </div>
                    <p className="text-[9px] font-black text-blue-500 uppercase tracking-[0.4em]">Expanding Registry Node...</p>
                </div>
            )}

            {listings.length === 0 && !isLoadingMore && (
                <div className="py-64 text-center animate-in zoom-in duration-1000">
                    <ExclamationTriangleIcon className="w-24 h-24 text-slate-800 mx-auto mb-8 opacity-30 animate-pulse" />
                    <h3 className="text-5xl font-black text-white uppercase tracking-tighter mb-4 leading-none">Registry Fault</h3>
                    <p className="text-slate-600 italic tracking-[0.4em] text-xs uppercase text-center">"NO PARITY DETECTED. INITIALIZE NEW SEARCH PROTOCOL."</p>
                    <button 
                        onClick={() => { onTypeChange('All'); onStatusChange('All'); }}
                        className="mt-10 px-10 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-black text-[10px] uppercase tracking-widest transition-all shadow-3xl"
                    >
                        Reset Local Registry
                    </button>
                </div>
            )}
        </div>
    );
};
