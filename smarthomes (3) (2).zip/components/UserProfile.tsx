
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { 
    UserIcon, 
    HeartIcon, 
    AdjustmentsHorizontalIcon, 
    BellAlertIcon, 
    ShieldCheckIcon, 
    SignalIcon, 
    BanknotesIcon, 
    MapPinIcon, 
    XMarkIcon,
    IdentificationIcon,
    BoltIcon,
    CpuChipIcon,
    RocketLaunchIcon,
    Squares2X2Icon,
    EnvelopeIcon,
    ChatBubbleLeftEllipsisIcon,
    ArrowPathIcon,
    CheckCircleIcon,
    BookmarkIcon,
    ClockIcon,
    // Add missing ArrowUpRightIcon
    ArrowUpRightIcon
} from '@heroicons/react/24/solid';
import { PropertyListing, SavedSearch } from '../services/gemini';
import { updateNotificationPreferences, sendNotification } from '../services/notifications';
import { supabase } from '../services/supabase';

interface UserProfileProps {
    user: any;
    onAuthClick: () => void;
    favorites: string[];
    allListings: PropertyListing[];
    onViewDetails: (item: PropertyListing) => void;
    onToggleFavorite: (id: string) => void;
    savedSearches?: SavedSearch[];
    onApplySaved?: (search: SavedSearch) => void;
}

export const UserProfile: React.FC<UserProfileProps> = ({ 
    user, 
    onAuthClick, 
    favorites, 
    allListings, 
    onViewDetails,
    onToggleFavorite,
    savedSearches = [],
    onApplySaved
}) => {
    const [activeSection, setActiveSection] = useState<'dossier' | 'saved' | 'preferences'>('dossier');
    const [prefs, setPrefs] = useState({ email: true, sms: false, push: true });
    const [isTestingRelay, setIsTestingRelay] = useState(false);
    const [testSuccess, setTestSuccess] = useState(false);
    const [isSyncing, setIsSyncing] = useState(false);
    const [isFetchingPrefs, setIsFetchingPrefs] = useState(false);
    
    const savedListings = allListings.filter(l => favorites.includes(l.id));

    useEffect(() => {
        const loadPreferences = async () => {
            if (!user) return;
            
            setIsFetchingPrefs(true);
            try {
                const saved = localStorage.getItem(`prefs_${user.id}`);
                if (saved) setPrefs(JSON.parse(saved));

                const { data, error } = await supabase
                    .from('profiles')
                    .select('notification_prefs')
                    .eq('id', user.id)
                    .single();

                if (data?.notification_prefs) {
                    setPrefs(data.notification_prefs);
                    localStorage.setItem(`prefs_${user.id}`, JSON.stringify(data.notification_prefs));
                }
            } catch (err) {
                console.error("Neural preference fetch failed:", err);
            } finally {
                setIsFetchingPrefs(false);
            }
        };

        loadPreferences();
    }, [user]);

    const handleTogglePref = async (key: keyof typeof prefs) => {
        const newPrefs = { ...prefs, [key]: !prefs[key] };
        setPrefs(newPrefs); 
        setIsSyncing(true);

        try {
            if (user) {
                await updateNotificationPreferences(user.id, newPrefs);
                localStorage.setItem(`prefs_${user.id}`, JSON.stringify(newPrefs));
            }
        } catch (err) {
            console.error("Preference synchronization failed:", err);
        } finally {
            setTimeout(() => setIsSyncing(false), 500); 
        }
    };

    const handleTestRelay = async () => {
        if (!user || isTestingRelay) return;
        setIsTestingRelay(true);
        setTestSuccess(false);

        try {
            const activeType = prefs.email ? 'email' : (prefs.sms ? 'sms' : 'push');
            
            await sendNotification({
                user_id: user.id,
                type: activeType as any,
                title: "Relay Node System Check",
                body: `Forensic handshake successful. Your preference matrix for ${activeType.toUpperCase()} transmission is active.`
            });

            setTestSuccess(true);
            setTimeout(() => setTestSuccess(false), 3000);
        } catch (err) {
            console.error(err);
        } finally {
            setIsTestingRelay(false);
        }
    };

    if (!user) {
        return (
            <div className="max-w-4xl mx-auto py-32 px-6 animate-in fade-in zoom-in-95 duration-700">
                <div className="bg-zinc-900/40 border border-zinc-800 rounded-[3rem] p-16 flex flex-col items-center text-center shadow-3xl">
                    <div className="w-24 h-24 bg-zinc-950 border border-zinc-800 rounded-3xl flex items-center justify-center text-zinc-700 mb-8">
                        <IdentificationIcon className="w-12 h-12" />
                    </div>
                    <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-4">Neural Identity Required</h2>
                    <p className="text-zinc-500 text-sm max-w-sm mb-12 font-medium italic">"Please establish a neural link to access your personalized asset dossiers and preference matrix."</p>
                    <button 
                        onClick={onAuthClick}
                        className="px-12 py-5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl text-[11px] font-black uppercase tracking-[0.3em] shadow-2xl transition-all active:scale-95 flex items-center gap-4 border border-blue-400/30"
                    >
                        <IdentificationIcon className="w-5 h-5" />
                        Initialize Auth Sequence
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="max-w-7xl mx-auto py-12 px-6 animate-in fade-in slide-in-from-bottom-8 duration-700">
            <div className="flex flex-col lg:flex-row gap-12">
                
                {/* Profile Navigation Rail */}
                <div className="w-full lg:w-80 flex flex-col gap-6 shrink-0">
                    <div className="bg-zinc-950 border border-zinc-800 p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden group">
                        <div className="absolute inset-0 bg-blue-600/5 opacity-0 group-hover:opacity-10 transition-opacity"></div>
                        <div className="flex flex-col items-center text-center relative z-10">
                            <div className="relative mb-6">
                                <div className="w-24 h-24 rounded-[2rem] bg-blue-600 flex items-center justify-center text-white text-3xl font-black border border-blue-400/30 shadow-[0_15px_40px_rgba(37,99,235,0.4)]">
                                    {user.email?.charAt(0).toUpperCase()}
                                </div>
                                <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-emerald-500 border-4 border-zinc-950 rounded-full animate-pulse shadow-lg"></div>
                            </div>
                            <h3 className="text-white font-black text-lg uppercase tracking-tight truncate w-full mb-1">{user.email?.split('@')[0]}</h3>
                            <p className="text-[10px] text-blue-500 font-black uppercase tracking-[0.4em] mb-8">Identity Level: Alpha</p>
                            <div className="w-full space-y-2">
                                <NavButton active={activeSection === 'dossier'} onClick={() => setActiveSection('dossier')} icon={UserIcon} label="Identity Node" />
                                <NavButton active={activeSection === 'saved'} onClick={() => setActiveSection('saved')} icon={HeartIcon} label="Saved Clusters" count={favorites.length + savedSearches.length} />
                                <NavButton active={activeSection === 'preferences'} onClick={() => setActiveSection('preferences')} icon={AdjustmentsHorizontalIcon} label="Neural Prefs" />
                            </div>
                        </div>
                    </div>

                    <div className="p-8 bg-zinc-900/40 border border-zinc-800 rounded-[2rem] space-y-6 text-left">
                        <div className="flex items-center gap-4">
                            <ShieldCheckIcon className="w-5 h-5 text-emerald-500" />
                            <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Truth-Lens Security</span>
                        </div>
                        <div className="space-y-4">
                            <div className="flex justify-between items-center text-[9px] font-black uppercase text-zinc-600">
                                <span>2FA Status</span>
                                <span className="text-emerald-500">Active</span>
                            </div>
                            <div className="flex justify-between items-center text-[9px] font-black uppercase text-zinc-600">
                                <span>Data Encryption</span>
                                <span className="text-blue-500">AES-256</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Main Content Area */}
                <div className="flex-1 min-w-0">
                    {activeSection === 'dossier' && (
                        <div className="space-y-12 animate-in fade-in slide-in-from-right-4 duration-500">
                            <header className="text-left mb-12">
                                <h2 className="text-4xl font-black text-white uppercase tracking-tighter mb-4 leading-none">User <span className="text-blue-500">Dossier</span></h2>
                                <p className="text-zinc-500 text-sm font-medium uppercase tracking-[0.4em]">Node ID: {user.id?.slice(0, 12)}... (AUTHENTICATED)</p>
                            </header>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <ProfileInfoCard label="Email Address" value={user.email} icon={IdentificationIcon} color="text-blue-500" />
                                <ProfileInfoCard label="Member Since" value={new Date().toLocaleDateString()} icon={BoltIcon} color="text-amber-500" />
                                <ProfileInfoCard label="Active Alerts" value={`${savedSearches.length} Protocol Nodes`} icon={BellAlertIcon} color="text-purple-500" />
                                <ProfileInfoCard label="Trust Score" value="98.2 / 100" icon={SignalIcon} color="text-emerald-500" />
                            </div>

                            <div className="bg-zinc-900/40 border border-zinc-800 p-12 rounded-[3.5rem] relative overflow-hidden group text-left shadow-2xl">
                                <div className="absolute top-0 right-0 p-10 opacity-5 group-hover:opacity-10 transition-opacity"><CpuChipIcon className="w-40 h-40 text-blue-500" /></div>
                                <h3 className="text-xl font-black text-white uppercase tracking-tighter mb-6 flex items-center gap-4">
                                    <RocketLaunchIcon className="w-7 h-7 text-blue-500" />
                                    Portfolio Acceleration
                                </h3>
                                <p className="text-zinc-400 text-base leading-relaxed mb-10 max-w-2xl font-medium">Your profile is currently syncing with regional market drifts. We've identified <span className="text-white">3 potential high-yield nodes</span> matching your interest profile in Westlands.</p>
                                <button className="px-10 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-2xl transition-all active:scale-95 flex items-center gap-3">
                                    Launch Forensic Pulse
                                </button>
                            </div>
                        </div>
                    )}

                    {activeSection === 'saved' && (
                        <div className="space-y-16 animate-in fade-in slide-in-from-right-4 duration-500">
                            {/* Saved Search Protocols Section */}
                            <section>
                                <header className="flex items-center justify-between mb-8">
                                    <div className="text-left">
                                        <h3 className="text-2xl font-black text-white uppercase tracking-tight flex items-center gap-4">
                                            <BookmarkIcon className="w-6 h-6 text-indigo-500" />
                                            Cached Search Protocols
                                        </h3>
                                    </div>
                                </header>
                                {savedSearches.length > 0 ? (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        {savedSearches.map(search => (
                                            <button 
                                                key={search.id} 
                                                onClick={() => onApplySaved?.(search)}
                                                className="bg-zinc-900/60 border border-zinc-800 p-6 rounded-3xl text-left hover:border-indigo-500/50 transition-all group flex items-center justify-between"
                                            >
                                                <div className="flex items-center gap-4">
                                                    <div className="p-3 bg-indigo-600/10 rounded-xl text-indigo-500">
                                                        <ClockIcon className="w-5 h-5" />
                                                    </div>
                                                    <div>
                                                        <p className="text-white font-bold text-sm uppercase tracking-tight">{search.query}</p>
                                                        <p className="text-[9px] text-zinc-500 font-black uppercase tracking-widest mt-1">
                                                            {search.filters.type} • {search.filters.status}
                                                        </p>
                                                    </div>
                                                </div>
                                                <ArrowUpRightIcon className="w-4 h-4 text-zinc-700 group-hover:text-indigo-500 transition-all" />
                                            </button>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="py-12 bg-zinc-900/20 border border-zinc-800 border-dashed rounded-3xl text-center opacity-30">
                                        <p className="text-[10px] font-black uppercase tracking-[0.4em]">No protocol cache detected</p>
                                    </div>
                                )}
                            </section>

                            {/* Saved Properties Section */}
                            <section>
                                <header className="flex items-center justify-between mb-8">
                                    <div className="text-left">
                                        <h3 className="text-2xl font-black text-white uppercase tracking-tight flex items-center gap-4">
                                            <HeartIcon className="w-6 h-6 text-rose-500" />
                                            Registry Clusters
                                        </h3>
                                    </div>
                                </header>
                                {savedListings.length > 0 ? (
                                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
                                        {savedListings.map(item => (
                                            <div key={item.id} className="bg-zinc-950 border border-zinc-800 rounded-[2.5rem] overflow-hidden group hover:border-blue-500/30 transition-all shadow-xl text-left">
                                                <div className="h-44 relative overflow-hidden">
                                                    <img src={item.image_url} alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                                                    <div className="absolute top-4 right-4">
                                                        <button onClick={() => onToggleFavorite(item.id)} className="p-2.5 bg-black/60 backdrop-blur-md rounded-xl text-rose-500 border border-rose-500/30 shadow-lg active:scale-90 transition-all">
                                                            <XMarkIcon className="w-4 h-4" />
                                                        </button>
                                                    </div>
                                                </div>
                                                <div className="p-8">
                                                    <h4 className="text-white font-black text-sm uppercase truncate mb-1">{item.title}</h4>
                                                    <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-6 flex items-center gap-2">
                                                        <MapPinIcon className="w-3.5 h-3.5 text-blue-500" /> {item.location}
                                                    </p>
                                                    <div className="flex items-center justify-between">
                                                        <span className="text-emerald-500 font-mono font-black text-base">{item.currency} {item.price.toLocaleString()}</span>
                                                        <button onClick={() => onViewDetails(item)} className="p-3 bg-zinc-900 hover:bg-blue-600 text-zinc-500 hover:text-white rounded-xl border border-zinc-800 transition-all active:scale-95 shadow-lg">
                                                            <Squares2X2Icon className="w-4 h-4" />
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="py-24 flex flex-col items-center justify-center text-center opacity-30 grayscale px-10">
                                        <SignalIcon className="w-20 h-20 text-zinc-500 mb-8 animate-pulse" />
                                        <p className="text-sm font-black uppercase tracking-[0.5em] leading-relaxed max-w-sm">Cluster Registry Empty.</p>
                                    </div>
                                )}
                            </section>
                        </div>
                    )}

                    {activeSection === 'preferences' && (
                        <div className="space-y-12 animate-in fade-in slide-in-from-right-4 duration-500">
                            <header className="text-left mb-12">
                                <h2 className="text-4xl font-black text-white uppercase tracking-tighter mb-4 leading-none">Neural <span className="text-blue-500">Matrix</span></h2>
                                <p className="text-zinc-500 text-sm font-medium uppercase tracking-[0.4em]">Interaction & Optimization Protocols</p>
                            </header>

                            <div className="space-y-8">
                                <div className="bg-zinc-900/40 border border-zinc-800 p-10 rounded-[3rem] text-left relative shadow-2xl">
                                    {isFetchingPrefs && (
                                        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm z-30 flex flex-col items-center justify-center gap-4 rounded-[3rem]">
                                            <ArrowPathIcon className="w-8 h-8 text-blue-500 animate-spin" />
                                            <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Polling Secure Registry...</span>
                                        </div>
                                    )}
                                    <div className="flex items-center justify-between mb-10">
                                        <div className="flex items-center gap-4">
                                            <h3 className="text-[11px] font-black text-zinc-500 uppercase tracking-[0.4em] flex items-center gap-4">
                                                <BellAlertIcon className="w-5 h-5 text-blue-500" />
                                                Notification Logic
                                            </h3>
                                            {isSyncing && (
                                                <div className="flex items-center gap-2 text-emerald-500 text-[8px] font-black uppercase tracking-widest animate-pulse">
                                                    <ArrowPathIcon className="w-3 h-3 animate-spin" />
                                                    Syncing Node...
                                                </div>
                                            )}
                                        </div>
                                        <button 
                                            onClick={handleTestRelay}
                                            disabled={isTestingRelay}
                                            className={`px-6 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest border transition-all flex items-center gap-3 active:scale-95 ${
                                                testSuccess 
                                                ? 'bg-emerald-600/10 border-emerald-500/40 text-emerald-500' 
                                                : 'bg-blue-600/10 border-blue-500/20 text-blue-400 hover:bg-blue-600 hover:text-white'
                                            }`}
                                        >
                                            {isTestingRelay ? <ArrowPathIcon className="w-3 h-3 animate-spin" /> : (testSuccess ? <CheckCircleIcon className="w-3 h-3" /> : <SignalIcon className="w-3 h-3" />)}
                                            {isTestingRelay ? 'Dispatching...' : (testSuccess ? 'Handshake OK' : 'Transmit Pulse Test')}
                                        </button>
                                    </div>
                                    <div className="space-y-6">
                                        <PreferenceToggle 
                                            label="Email Notifications" 
                                            desc="Dispatch forensic summaries and new matches to your primary inbox node." 
                                            icon={EnvelopeIcon}
                                            isOn={prefs.email} 
                                            onToggle={() => handleTogglePref('email')} 
                                        />
                                        <PreferenceToggle 
                                            label="SMS Alert Stream" 
                                            desc="High-priority liquidity alerts via encrypted mobile relay." 
                                            icon={ChatBubbleLeftEllipsisIcon}
                                            isOn={prefs.sms} 
                                            onToggle={() => handleTogglePref('sms')} 
                                        />
                                        <PreferenceToggle 
                                            label="Push Transmission" 
                                            desc="Direct OS notifications for real-time asset node shifts." 
                                            icon={BellAlertIcon}
                                            isOn={prefs.push} 
                                            onToggle={() => handleTogglePref('push')} 
                                        />
                                    </div>
                                </div>

                                <div className="bg-zinc-900/40 border border-zinc-800 p-10 rounded-[3rem] text-left shadow-2xl">
                                    <h3 className="text-[11px] font-black text-zinc-500 uppercase tracking-[0.4em] mb-10 flex items-center gap-4">
                                        <AdjustmentsHorizontalIcon className="w-5 h-5 text-purple-500" />
                                        Forensic Filters
                                    </h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                        <div className="space-y-3">
                                            <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest pl-2">Primary Interest Node</label>
                                            <select className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-5 text-sm text-white focus:border-blue-500 outline-none appearance-none cursor-pointer">
                                                <option>Westlands Metro</option>
                                                <option>Karen Estate</option>
                                                <option>Kilimani Hub</option>
                                                <option>Lavington Node</option>
                                            </select>
                                        </div>
                                        <div className="space-y-3">
                                            <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest pl-2">Currency Display Protocol</label>
                                            <select className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-5 text-sm text-white focus:border-blue-500 outline-none appearance-none cursor-pointer">
                                                <option>KES (Kenya Shilling)</option>
                                                <option>USD (United States Dollar)</option>
                                                <option>EUR (Euro)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const NavButton = ({ active, onClick, icon: Icon, label, count }: any) => (
    <button 
        onClick={onClick}
        className={`w-full flex items-center justify-between px-6 py-4 rounded-2xl border transition-all group ${
            active ? 'bg-blue-600/10 border-blue-500/40 text-blue-500 shadow-lg' : 'bg-zinc-900 border-zinc-800 text-zinc-600 hover:text-zinc-300'
        }`}
    >
        <div className="flex items-center gap-4">
            <Icon className="w-5 h-5" />
            <span className="text-[11px] font-black uppercase tracking-widest">{label}</span>
        </div>
        {count !== undefined && (
            <span className={`text-[10px] font-black px-2 py-0.5 rounded-lg border ${active ? 'bg-blue-600 text-white border-blue-400/30' : 'bg-zinc-800 border-zinc-700 text-zinc-500'}`}>{count}</span>
        )}
    </button>
);

const ProfileInfoCard = ({ label, value, icon: Icon, color }: any) => (
    <div className="bg-zinc-900/40 border border-zinc-800 p-8 rounded-[2.5rem] flex items-center gap-6 shadow-xl relative overflow-hidden group hover:border-blue-500/20 transition-all text-left">
        <div className={`p-4 rounded-2xl bg-zinc-950 border border-zinc-800 shadow-inner shrink-0 ${color} group-hover:scale-110 transition-transform`}>
            <Icon className="w-6 h-6" />
        </div>
        <div className="min-w-0">
            <p className="text-[9px] font-black text-zinc-600 uppercase tracking-widest leading-none mb-1.5">{label}</p>
            <p className="text-base font-black text-white uppercase truncate tracking-tight">{value}</p>
        </div>
    </div>
);

const PreferenceToggle = ({ label, desc, isOn, onToggle, icon: Icon }: any) => {
    return (
        <div className="flex items-center justify-between gap-8 py-5 border-b border-zinc-800/50 last:border-0 group">
            <div className="flex items-start gap-5 min-w-0">
                <div className={`p-3 rounded-xl bg-zinc-950 border border-zinc-800 shadow-inner transition-colors ${isOn ? 'text-blue-500' : 'text-zinc-700'}`}>
                    <Icon className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                    <p className="text-white font-black text-sm uppercase tracking-tight mb-1 group-hover:text-blue-500 transition-colors">{label}</p>
                    <p className="text-[10px] text-zinc-600 font-medium italic leading-relaxed">{desc}</p>
                </div>
            </div>
            <button 
                onClick={onToggle}
                className={`w-14 h-8 rounded-full border p-1 transition-all duration-500 relative shrink-0 ${
                    isOn ? 'bg-blue-600 border-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.5)]' : 'bg-zinc-950 border-zinc-800'
                }`}
            >
                <div className={`w-5 h-5 rounded-full transition-all duration-500 shadow-md ${
                    isOn ? 'bg-white translate-x-6' : 'bg-zinc-700 translate-x-0'
                }`}></div>
            </button>
        </div>
    );
};
