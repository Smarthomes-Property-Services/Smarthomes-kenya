
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useCallback } from 'react';
import { 
    XMarkIcon, 
    PhotoIcon, 
    CheckCircleIcon, 
    CloudArrowUpIcon, 
    SparklesIcon, 
    BoltIcon, 
    BeakerIcon, 
    ScaleIcon, 
    ArrowPathIcon, 
    SignalIcon, 
    RocketLaunchIcon, 
    Squares2X2Icon, 
    TrashIcon, 
    PlusIcon, 
    MapPinIcon, 
    BanknotesIcon, 
    CheckBadgeIcon, 
    TagIcon, 
    ExclamationCircleIcon, 
    MagnifyingGlassIcon, 
    UserGroupIcon, 
    CpuChipIcon,
    LockClosedIcon
} from '@heroicons/react/24/solid';
import { enhancePropertyDescription, generatePropertyImage, EnhancedDescription } from '../services/gemini.ts';
import { sendNotification } from '../services/notifications.ts';
import { supabase } from '../services/supabase.ts';

const AMENITIES_LIST = [
    "Gym", "Pool", "Backup Generator", "Borehole", "Elevator", "CCTV", 
    "Garden", "Parking", "DSQ", "Fiber Internet", "Furnished", 
    "Pet Friendly", "Balcony", "Kids Play Area"
];

const TENURE_OPTIONS = ["Leasehold", "Freehold", "Sectional Title"];
const WATER_OPTIONS = ["Borehole", "City Council", "Borehole & Council", "Rainwater Harvesting"];
const POWER_OPTIONS = ["None", "Full Capacity Generator", "Common Area Generator", "Solar Backup", "Hybrid Grid"];
const STATUS_OPTIONS = ["Available", "Rented", "Under Offer"];

interface AssetMedia {
    file?: File;
    preview: string;
    id: string;
    isAiGenerated?: boolean;
}

interface PostPropertyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (propertyData: any) => void;
  user: any;
  onAuthRequest: () => void;
}

export const PostPropertyModal: React.FC<PostPropertyModalProps> = ({ isOpen, onClose, onSuccess, user, onAuthRequest }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: '',
    price: '',
    bedrooms: '2',
    bathrooms: '2',
    type: 'Apartment',
    listingType: 'Sale',
    status: 'Available',
    amenities: [] as string[],
    moment_type: 'Sale',
    tenure: 'Leasehold',
    waterSource: 'Borehole',
    powerBackup: 'Full Capacity Generator',
    floorArea: ''
  });
  
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [assets, setAssets] = useState<AssetMedia[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<EnhancedDescription | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleMagicDescription = async () => {
    if (!formData.title || !formData.location) {
        setFieldErrors({ title: "Node ID and Location required for neural mapping." });
        return;
    }
    setIsGenerating(true);
    setAiAnalysis(null);
    try {
        const enhanced = await enhancePropertyDescription({ ...formData, price: Number(formData.price) } as any);
        setFormData(prev => ({ ...prev, description: enhanced.description }));
        setAiAnalysis(enhanced);
    } catch (e) { console.error("AI Polish failed", e); } finally { setIsGenerating(false); }
  };

  const handleAiVisualSynthesis = async () => {
      if (!formData.title || !formData.location) return;
      setIsSynthesizing(true);
      try {
          const prompt = `Modern architectural render of ${formData.title} in ${formData.location}. Professional real estate photography.`;
          const b64 = await generatePropertyImage(prompt);
          setAssets(prev => [{ preview: b64, id: 'ai-' + Date.now(), isAiGenerated: true }, ...prev]);
      } catch (err) { console.error(err); } finally { setIsSynthesizing(false); }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (fieldErrors[name]) setFieldErrors(prev => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
        onAuthRequest();
        return;
    }
    setIsSubmitting(true);
    await new Promise(r => setTimeout(r, 2000));
    setIsSubmitting(false);
    setSubmitted(true);
    if (onSuccess) onSuccess(formData);
    setTimeout(() => onClose(), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-[#020617] border border-white/10 w-full max-w-5xl rounded-[3rem] shadow-[0_0_100px_rgba(0,0,0,1)] relative flex flex-col max-h-[95vh] overflow-hidden group">
         <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none"></div>
         
         <div className="flex items-center justify-between p-10 border-b border-white/5 bg-slate-950/50 backdrop-blur-3xl shrink-0">
            <div className="flex items-center gap-6">
                <div className="bg-blue-600/10 p-5 rounded-2xl border border-blue-500/20 text-blue-500 shadow-inner">
                    <RocketLaunchIcon className="w-10 h-10" />
                </div>
                <div className="text-left">
                    <h2 className="text-3xl font-black text-white uppercase tracking-tighter">Deploy Asset Node</h2>
                    <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
                        <p className="text-[10px] text-blue-400 font-black uppercase tracking-[0.4em]">Forensic Registry v4.5.GOAT</p>
                    </div>
                </div>
            </div>
            <button onClick={onClose} className="p-4 bg-white/5 text-slate-500 hover:text-white rounded-2xl border border-white/5 transition-all hover:bg-rose-500/20">
                <XMarkIcon className="w-8 h-8" />
            </button>
         </div>

         <div className="flex-1 overflow-y-auto custom-scrollbar p-12 space-y-12">
            {!user && (
                <div className="bg-blue-900/10 border border-blue-500/20 p-6 rounded-[2rem] flex items-center gap-6 mb-8 animate-in slide-in-from-top-4">
                    <div className="p-3 bg-blue-600/20 rounded-xl text-blue-400">
                        <LockClosedIcon className="w-6 h-6" />
                    </div>
                    <div className="text-left">
                        <h4 className="text-white font-bold text-sm uppercase tracking-wider">Authentication Required</h4>
                        <p className="text-slate-400 text-xs mt-1">You must establish a secure identity node before committing data to the registry.</p>
                    </div>
                    <button 
                        onClick={onAuthRequest}
                        className="ml-auto px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg active:scale-95"
                    >
                        Sign In
                    </button>
                </div>
            )}

            {submitted ? (
                <div className="flex flex-col items-center justify-center py-24 text-center animate-in zoom-in duration-500">
                    <div className="w-32 h-32 bg-emerald-500/10 rounded-full flex items-center justify-center text-emerald-500 mb-8 border border-emerald-500/20 shadow-[0_0_50px_rgba(16,185,129,0.2)]">
                        <CheckBadgeIcon className="w-20 h-20 animate-pulse" />
                    </div>
                    <h3 className="text-4xl font-black text-white uppercase tracking-tighter mb-2">Sync Complete</h3>
                    <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Asset established in Kenyan Global Registry</p>
                </div>
            ) : (
                <form id="post-property-form" onSubmit={handleSubmit} className="space-y-12 text-left">
                    {/* Media Node Cluster */}
                    <div className="space-y-6">
                        <div className="flex items-center justify-between">
                            <h3 className="text-[11px] font-black text-slate-500 uppercase tracking-[0.5em] flex items-center gap-3">
                                <PhotoIcon className="w-5 h-5 text-blue-500" />
                                Visual Node Cluster
                            </h3>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                            {assets.map((asset) => (
                                <div key={asset.id} className="aspect-square rounded-3xl border border-white/10 overflow-hidden relative group shadow-2xl">
                                    <img src={asset.preview} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt="" />
                                    <button type="button" onClick={() => setAssets(prev => prev.filter(a => a.id !== asset.id))} className="absolute inset-0 bg-rose-600/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                                        <TrashIcon className="w-8 h-8" />
                                    </button>
                                </div>
                            ))}
                            <button type="button" onClick={() => fileInputRef.current?.click()} className="aspect-square rounded-3xl border-2 border-dashed border-white/10 bg-white/5 hover:bg-white/10 hover:border-blue-500/50 transition-all flex flex-col items-center justify-center gap-3 group">
                                <PlusIcon className="w-8 h-8 text-slate-600 group-hover:text-blue-500 transition-colors" />
                                <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Append Node</span>
                            </button>
                            <button type="button" onClick={handleAiVisualSynthesis} disabled={isSynthesizing || !formData.title} className="aspect-square rounded-3xl border-2 border-dashed border-purple-500/20 bg-purple-500/5 hover:bg-purple-500/10 transition-all flex flex-col items-center justify-center gap-3 group disabled:opacity-30">
                                {isSynthesizing ? <ArrowPathIcon className="w-8 h-8 animate-spin text-purple-400" /> : <SparklesIcon className="w-8 h-8 text-purple-400 group-hover:scale-110 transition-transform" />}
                                <span className="text-[9px] font-black text-purple-500 uppercase tracking-widest">Neural Vision</span>
                            </button>
                        </div>
                        <input type="file" ref={fileInputRef} className="hidden" multiple onChange={(e) => {
                            if (e.target.files) {
                                const newAssets = Array.from(e.target.files).map((f: File) => ({ file: f, preview: URL.createObjectURL(f), id: Math.random().toString() }));
                                setAssets(prev => [...prev, ...newAssets]);
                            }
                        }} />
                    </div>

                    {/* Metadata Nodes */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest ml-2">Asset Title</label>
                            <input name="title" value={formData.title} onChange={handleChange} className="w-full bg-white/5 border border-white/5 rounded-2xl p-5 text-sm text-white outline-none focus:border-blue-500/50 shadow-inner" placeholder="e.g. Royal Westlands Penthouse" />
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest ml-2">Geo-Localization</label>
                            <div className="relative">
                                <MapPinIcon className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-500" />
                                <input name="location" value={formData.location} onChange={handleChange} className="w-full bg-white/5 border border-white/5 rounded-2xl p-5 pl-14 text-sm text-white outline-none focus:border-blue-500/50 shadow-inner" placeholder="e.g. Westlands, Nairobi" />
                            </div>
                        </div>
                    </div>

                    {/* Industrial Dossier Section */}
                    <div className="space-y-8 bg-slate-950/40 p-10 rounded-[3rem] border border-white/5 shadow-inner">
                        <div className="flex items-center justify-between">
                            <label className="text-[11px] font-black text-blue-500 uppercase tracking-[0.4em] flex items-center gap-3">
                                <CpuChipIcon className="w-5 h-5" />
                                Neural Narrative Synthesis
                            </label>
                            {aiAnalysis && (
                                <div className="flex items-center gap-3 px-4 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
                                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                                    <span className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">Optimized: {aiAnalysis.optimization_score}%</span>
                                </div>
                            )}
                        </div>
                        
                        <div className="relative group">
                            <textarea 
                                name="description" 
                                value={formData.description} 
                                onChange={handleChange}
                                rows={6} 
                                className="w-full bg-slate-900 border border-white/5 rounded-[2.5rem] p-8 text-sm text-slate-300 outline-none focus:border-blue-500/40 shadow-2xl resize-none transition-all placeholder:text-slate-700 font-medium leading-relaxed"
                                placeholder="Initialize asset specs for neural generation..."
                            />
                            <button 
                                type="button" 
                                onClick={handleMagicDescription}
                                disabled={isGenerating}
                                className="absolute bottom-6 right-6 px-8 py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-2xl transition-all active:scale-95 disabled:opacity-50 flex items-center gap-3"
                            >
                                {isGenerating ? <ArrowPathIcon className="w-4 h-4 animate-spin" /> : <SparklesIcon className="w-4 h-4" />}
                                {isGenerating ? 'Synthesizing...' : 'Synthesize Dossier'}
                            </button>
                        </div>

                        {/* AI ANALYSIS RESULTS - NEW WORLD CLASS FEATURE */}
                        {aiAnalysis && (
                            <div className="space-y-8 animate-in slide-in-from-top-4 duration-700">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="bg-slate-900 border border-white/10 p-8 rounded-[2.5rem] shadow-xl space-y-6">
                                        <h4 className="text-[10px] font-black text-blue-400 uppercase tracking-[0.4em] flex items-center gap-3">
                                            <MagnifyingGlassIcon className="w-4 h-4" />
                                            Neural Search Nodes (SEO)
                                        </h4>
                                        <div className="flex flex-wrap gap-2">
                                            {aiAnalysis.seo_keywords.map((kw, i) => (
                                                <span key={i} className="px-3 py-1.5 bg-blue-600/10 border border-blue-500/20 text-[9px] font-bold text-blue-300 uppercase tracking-widest rounded-xl">
                                                    {kw}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                    <div className="bg-slate-900 border border-white/10 p-8 rounded-[2.5rem] shadow-xl space-y-6">
                                        <h4 className="text-[10px] font-black text-purple-400 uppercase tracking-[0.4em] flex items-center gap-3">
                                            <UserGroupIcon className="w-4 h-4" />
                                            Ideal Asset Holder
                                        </h4>
                                        <div className="p-4 bg-white/5 rounded-2xl border border-white/5 italic text-slate-400 text-[11px] leading-relaxed">
                                            "{aiAnalysis.target_audience}"
                                        </div>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="bg-slate-900 border border-white/10 p-8 rounded-[2.5rem] shadow-xl space-y-6">
                                        <h4 className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.4em] flex items-center gap-3">
                                            <SparklesIcon className="w-4 h-4" />
                                            Unique Selling Points
                                        </h4>
                                        <ul className="space-y-3">
                                            {aiAnalysis.unique_selling_points.map((usp, i) => (
                                                <li key={i} className="flex items-start gap-3 text-[11px] text-slate-300 leading-relaxed">
                                                    <CheckCircleIcon className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                                                    {usp}
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div className="bg-slate-900 border border-white/10 p-8 rounded-[2.5rem] shadow-xl space-y-6">
                                        <h4 className="text-[10px] font-black text-amber-400 uppercase tracking-[0.4em] flex items-center gap-3">
                                            <SignalIcon className="w-4 h-4" />
                                            Market Context
                                        </h4>
                                        <div className="p-4 bg-white/5 rounded-2xl border border-white/5 text-slate-400 text-[11px] leading-relaxed">
                                            {aiAnalysis.market_context}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </form>
            )}
         </div>

         <div className="p-10 border-t border-white/5 bg-slate-950 flex justify-end gap-6 shrink-0 rounded-b-[3rem]">
            <button onClick={onClose} className="px-10 py-5 rounded-2xl font-black uppercase text-slate-500 text-[11px] tracking-widest hover:text-white transition-colors">Abort Sync</button>
            <button 
                form="post-property-form" 
                type="submit" 
                disabled={isSubmitting} 
                className={`px-16 py-5 rounded-2xl font-black uppercase tracking-[0.3em] text-[11px] shadow-2xl transition-all active:scale-95 disabled:opacity-50 flex items-center gap-4 ${user ? 'bg-blue-600 hover:bg-blue-500 text-white' : 'bg-slate-900 border border-white/10 text-slate-400 hover:text-white'}`}
            >
                {isSubmitting ? <ArrowPathIcon className="w-5 h-5 animate-spin" /> : (user ? <RocketLaunchIcon className="w-5 h-5" /> : <LockClosedIcon className="w-5 h-5" />)}
                {user ? 'Execute Deployment' : 'Sign In to Deploy'}
            </button>
         </div>
      </div>
    </div>
  );
};
