
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { 
  HomeModernIcon,
  Bars3Icon,
  XMarkIcon,
  CalculatorIcon,
  BanknotesIcon,
  CreditCardIcon,
  ArrowRightOnRectangleIcon,
  SunIcon,
  MoonIcon,
  ShoppingCartIcon,
  KeyIcon,
  UserPlusIcon,
  BuildingStorefrontIcon,
  BriefcaseIcon,
  CpuChipIcon,
  MagnifyingGlassIcon,
  ChevronDownIcon,
  ChartBarIcon,
  ArrowPathIcon,
  SignalIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  IdentificationIcon,
  MapPinIcon,
  ChevronDoubleDownIcon,
  BellIcon,
  CommandLineIcon,
  SparklesIcon,
  KeyIcon as AuthKeyIcon,
  UserGroupIcon,
  BoltIcon,
  ArrowsRightLeftIcon,
  FireIcon,
  PresentationChartLineIcon
} from '@heroicons/react/24/solid';
import { PropertyListing, MarketPulse } from '../services/gemini';

interface HeaderProps {
    onOpenDev: () => void;
    activeTab: string;
    onTabChange: (tab: string) => void;
    onPostProperty: () => void;
    user: any;
    onAuthClick: () => void;
    onSignOut: () => void;
    searchQuery: string;
    onSearchChange: (query: string) => void;
    theme: 'dark' | 'light';
    onToggleTheme: () => void;
}

const NAV_ITEMS = [
    { label: 'Buy', value: 'Buy', icon: ShoppingCartIcon },
    { label: 'Rent', value: 'Rent', icon: KeyIcon },
    { label: 'Mortgage', value: 'Mortgage', icon: BanknotesIcon },
    { label: 'Pricing', value: 'Pricing', icon: CreditCardIcon },
    { label: 'Calculator', value: 'Calculator', icon: CalculatorIcon },
    { label: 'Sell', value: 'Sell', icon: BuildingStorefrontIcon },
    { label: 'Stats', value: 'Stats', icon: ChartBarIcon },
    { label: 'Agent Workspace', value: 'Agent', icon: BriefcaseIcon },
];

const MARKET_TICKER_DATA = [
    { suburb: "Westlands", drift: "+1.2%", trend: "Up", volume: "High" },
    { suburb: "Karen", drift: "Stable", trend: "Side", volume: "Low" },
    { suburb: "Kilimani", drift: "+0.8%", trend: "Up", volume: "Medium" },
    { suburb: "Lavington", drift: "-0.2%", trend: "Down", volume: "Medium" },
    { suburb: "Runda", drift: "+2.1%", trend: "Up", volume: "High" },
    { suburb: "Eldoret", drift: "+4.2%", trend: "Up", volume: "Surging" },
    { suburb: "Mombasa", drift: "+3.5%", trend: "Up", volume: "High" },
    { suburb: "Kisumu", drift: "+2.8%", trend: "Up", volume: "Rising" }
];

const MarketTicker = ({ isDark }: { isDark: boolean }) => {
    const bgRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleScroll = () => {
            if (bgRef.current) {
                const y = window.scrollY;
                bgRef.current.style.transform = `translateX(-${y * 0.5}px)`;
            }
        };

        window.addEventListener('scroll', handleScroll, { passive: true });
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <div className={`w-full border-b py-2 overflow-hidden flex items-center shrink-0 z-[60] relative group/ticker transition-colors duration-500 ${isDark ? 'bg-[#020617] border-white/5' : 'bg-zinc-900 border-zinc-800'}`}>
            <div className="absolute inset-0 opacity-20 pointer-events-none overflow-hidden">
                <div 
                    ref={bgRef} 
                    className="absolute top-0 left-0 w-[200%] h-full bg-grid-pattern opacity-40 transition-transform duration-75 ease-linear will-change-transform"
                ></div>
            </div>
            
            <div className="absolute inset-0 bg-blue-600/[0.02] pointer-events-none"></div>
            
            <div className={`flex items-center gap-3 px-6 md:px-8 shrink-0 border-r backdrop-blur-sm relative z-20 h-full shadow-[5px_0_20px_rgba(0,0,0,0.5)] ${isDark ? 'border-white/10 bg-[#020617]/80' : 'border-white/10 bg-zinc-900/80'}`}>
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                <span className="text-[8px] md:text-[9px] font-black text-blue-400 uppercase tracking-[0.3em] whitespace-nowrap">Neural Geo-Pulse</span>
            </div>
            
            <div className="flex animate-marquee whitespace-nowrap gap-16 items-center px-8 relative z-10 group-hover/ticker:[animation-play-state:paused]">
                {[...MARKET_TICKER_DATA, ...MARKET_TICKER_DATA, ...MARKET_TICKER_DATA].map((node, i) => (
                    <div key={i} className="flex items-center gap-4 group cursor-default opacity-60 hover:opacity-100 transition-opacity">
                        <span className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                            <MapPinIcon className="w-3 h-3 text-slate-600" />
                            {node.suburb}
                        </span>
                        <div className="flex items-center gap-1.5">
                            {node.trend === 'Up' ? <ArrowTrendingUpIcon className="w-3 h-3 text-emerald-500" /> : 
                             node.trend === 'Down' ? <ArrowTrendingDownIcon className="w-3 h-3 text-rose-500" /> : 
                             <div className="w-2 h-0.5 bg-slate-500"></div>}
                            <span className={`text-[10px] md:text-[11px] font-mono font-bold ${node.trend === 'Up' ? 'text-emerald-500' : node.trend === 'Down' ? 'text-rose-500' : 'text-slate-400'}`}>{node.drift}</span>
                        </div>
                        <span className="text-[7px] md:text-[8px] font-black text-slate-500 uppercase px-2 py-0.5 bg-white/5 rounded border border-white/5 tracking-wider">{node.volume} VOL</span>
                    </div>
                ))}
            </div>
        </div>
    );
};

const PulseMetricCard = ({ label, value, trend, color, icon: Icon, subtext, delay }: any) => (
    <div 
        className="relative group bg-slate-900/40 border border-white/10 p-6 rounded-[2.5rem] backdrop-blur-xl overflow-hidden animate-in slide-in-from-bottom-6 fill-mode-both hover:border-blue-500/40 transition-all duration-500 hover:shadow-[0_20px_50px_rgba(0,0,0,0.5)] cursor-default"
        style={{ animationDelay: `${delay}ms` }}
    >
        {/* Background Aura */}
        <div className={`absolute -top-12 -right-12 w-32 h-32 blur-[40px] opacity-10 group-hover:opacity-25 transition-opacity ${color.replace('text-', 'bg-')}`}></div>
        
        <div className="relative z-10 flex flex-col gap-5 h-full">
            <div className="flex items-center justify-between">
                <div className="flex flex-col gap-1">
                    <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.4em] leading-none">{label}</p>
                    <div className="h-0.5 w-8 bg-blue-600/30 rounded-full group-hover:w-full transition-all duration-700"></div>
                </div>
                <div className={`p-3 rounded-2xl bg-white/5 border border-white/10 ${color} group-hover:scale-110 group-hover:rotate-3 transition-all duration-500 shadow-xl ring-1 ring-white/5`}>
                    <Icon className="w-5 h-5" />
                </div>
            </div>

            <div className="space-y-4">
                <div className="flex items-baseline gap-2">
                    <h4 className={`text-3xl font-black text-white font-mono tracking-tighter leading-none group-hover:text-blue-400 transition-colors`}>
                        {value}
                    </h4>
                    {trend !== undefined && (
                        <span className={`text-[10px] font-black uppercase tracking-widest ${trend > 70 ? 'text-emerald-500' : 'text-slate-500'}`}>
                            {trend > 70 ? 'Peak' : 'Stable'}
                        </span>
                    )}
                </div>
                
                <div className="space-y-2">
                    <div className="w-full bg-slate-800/50 h-2 rounded-full overflow-hidden border border-white/5 p-0.5">
                        <div 
                            className={`h-full rounded-full ${color.replace('text-', 'bg-')} shadow-[0_0_10px_currentColor] transition-all duration-[2000ms] ease-out delay-500`} 
                            style={{ width: `${trend}%` }}
                        >
                            <div className="w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent animate-scan-infinite"></div>
                        </div>
                    </div>
                    <div className="flex justify-between items-center px-1">
                        <p className="text-[8px] font-black text-slate-600 uppercase tracking-[0.2em]">{subtext}</p>
                        <span className="text-[9px] font-mono font-bold text-slate-700">{trend}%</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
);

export const Header: React.FC<HeaderProps> = ({ 
    onOpenDev, activeTab, onTabChange, user, onAuthClick, onSignOut, 
    searchQuery, onSearchChange, theme, onToggleTheme
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [hasApiKey, setHasApiKey] = useState<boolean>(false);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const isDark = theme === 'dark';

  useEffect(() => {
    const checkKey = async () => {
      if ((window as any).aistudio?.hasSelectedApiKey) {
        const selected = await (window as any).aistudio.hasSelectedApiKey();
        setHasApiKey(selected);
      }
    };
    checkKey();
    const interval = setInterval(checkKey, 5000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleNav = (tab: string) => {
    onTabChange(tab);
    setMobileMenuOpen(false);
  };

  return (
    <div className="w-full sticky top-0 z-[100] transition-all duration-300">
      <MarketTicker isDark={isDark} />
      <header className={`w-full backdrop-blur-2xl border-b shadow-2xl transition-colors duration-500 ${isDark ? 'bg-[#020617]/90 border-white/5' : 'bg-white/90 border-zinc-200'}`}>
        <div className="h-20 md:h-24 px-4 md:px-10 flex items-center justify-between gap-4 md:gap-8">
          
          <div className="flex items-center gap-3 md:gap-4 cursor-pointer group shrink-0 animate-in fade-in slide-in-from-left-4 duration-1000" onClick={() => handleNav('Buy')}>
              <div className="relative">
                  <div className="relative w-10 h-10 md:w-14 md:h-14 bg-gradient-to-br from-blue-600 to-indigo-800 rounded-xl md:rounded-2xl flex items-center justify-center shadow-[0_10px_30px_rgba(37,99,235,0.4)] group-hover:scale-105 transition-all duration-500 overflow-hidden ring-2 ring-blue-500/20">
                      <div className="absolute inset-0 bg-white/10 group-hover:animate-shimmer pointer-events-none"></div>
                      <HomeModernIcon className="w-6 h-6 md:w-8 md:h-8 text-white" />
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-4 border-[#020617] animate-pulse"></div>
              </div>
              <div className="hidden sm:block text-left animate-subtle-drift">
                  <h1 className={`text-xl md:text-2xl font-black uppercase tracking-tighter leading-none ${isDark ? 'text-white' : 'text-zinc-900'}`}>Keja<span className="text-blue-500">OS</span></h1>
                  <p className="text-[8px] md:text-[9px] font-black text-blue-400 uppercase tracking-[0.4em] mt-1 opacity-80">v4.5 Neural Grid</p>
              </div>
          </div>

          <div className="hidden lg:flex flex-1 max-w-xl relative group">
              <MagnifyingGlassIcon className={`absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 transition-colors ${isDark ? 'text-slate-500 group-focus-within:text-blue-500' : 'text-zinc-400 group-focus-within:text-blue-600'}`} />
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Scan regional nodes (e.g. Westlands, ROI > 8%)..." 
                className={`w-full border rounded-2xl py-4 pl-14 pr-4 text-sm outline-none transition-all shadow-inner ${
                    isDark 
                    ? 'bg-white/5 border-white/5 focus:border-blue-500/50 text-white placeholder:text-slate-600' 
                    : 'bg-zinc-100 border-zinc-200 focus:border-blue-500 focus:bg-white text-zinc-900 placeholder:text-zinc-400'
                }`}
              />
          </div>

          <div className="flex items-center gap-3 md:gap-4">
              <button 
                onClick={onToggleTheme} 
                className={`p-3 rounded-2xl border transition-all hidden sm:flex active:scale-95 ${
                    isDark 
                    ? 'bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border-white/5' 
                    : 'bg-zinc-100 hover:bg-zinc-200 text-zinc-500 hover:text-zinc-900 border-zinc-200'
                }`}
              >
                  {theme === 'dark' ? <SunIcon className="w-5 h-5" /> : <MoonIcon className="w-5 h-5" />}
              </button>

              <button 
                onClick={onOpenDev} 
                className={`p-3 rounded-2xl border transition-all hidden md:flex ${
                    isDark 
                    ? 'bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 border-blue-500/20' 
                    : 'bg-blue-50 hover:bg-blue-100 text-blue-600 border-blue-200'
                }`}
              >
                  <CommandLineIcon className="w-5 h-5" />
              </button>

              <div className={`h-10 w-px mx-2 hidden md:block ${isDark ? 'bg-white/10' : 'bg-zinc-200'}`}></div>

              {user ? (
                  <div className="relative" ref={userMenuRef}>
                      <button 
                        onClick={() => setShowUserMenu(!showUserMenu)}
                        className="w-10 h-10 md:w-12 md:h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white font-black text-sm border-2 border-white/10 hover:border-blue-400 transition-all shadow-xl active:scale-95"
                      >
                          {user.email?.charAt(0).toUpperCase()}
                      </button>
                      {showUserMenu && (
                          <div className={`absolute top-full right-0 mt-4 w-72 border rounded-3xl shadow-[0_30px_70px_rgba(0,0,0,0.5)] p-4 animate-in slide-in-from-top-2 duration-300 z-[110] text-left ${
                              isDark 
                              ? 'bg-slate-900 border-white/10' 
                              : 'bg-white border-zinc-200'
                          }`}>
                              <div className={`p-4 border-b mb-2 ${isDark ? 'border-white/5' : 'border-zinc-100'}`}>
                                  <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">User Node ID</p>
                                  <p className={`text-sm font-bold truncate ${isDark ? 'text-white' : 'text-zinc-900'}`}>{user.email}</p>
                              </div>
                              <button onClick={() => handleNav('Profile')} className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all text-[11px] font-black uppercase tracking-widest ${
                                  isDark 
                                  ? 'hover:bg-white/5 text-slate-400 hover:text-white' 
                                  : 'hover:bg-zinc-100 text-zinc-500 hover:text-zinc-900'
                              }`}>
                                  <IdentificationIcon className="w-5 h-5 text-blue-500" /> Account Dossier
                              </button>
                              <button onClick={onSignOut} className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all text-[11px] font-black uppercase tracking-widest mt-1 ${
                                  isDark 
                                  ? 'hover:bg-rose-500/10 text-slate-400 hover:text-rose-500' 
                                  : 'hover:bg-rose-50 text-zinc-500 hover:text-rose-600'
                              }`}>
                                  <ArrowRightOnRectangleIcon className="w-5 h-5" /> Terminate Session
                              </button>
                          </div>
                      )}
                  </div>
              ) : (
                  <button 
                    onClick={onAuthClick} 
                    className="bg-blue-600 hover:bg-blue-500 text-white font-black text-[10px] uppercase tracking-widest px-6 md:px-8 py-3.5 md:py-4 rounded-2xl transition-all shadow-lg shadow-blue-900/20 active:scale-95"
                  >
                      Initialize OS
                  </button>
              )}

              <button 
                onClick={() => setMobileMenuOpen(true)} 
                className={`xl:hidden p-3.5 rounded-2xl border ${isDark ? 'bg-white/5 text-slate-400 border-white/5' : 'bg-zinc-100 text-zinc-600 border-zinc-200'}`}
              >
                  <Bars3Icon className="w-6 h-6" />
              </button>
          </div>
        </div>

        <div className={`h-14 border-t flex items-center px-4 overflow-x-auto no-scrollbar scroll-smooth transition-colors duration-500 ${isDark ? 'border-white/5 bg-[#020617]' : 'border-zinc-200 bg-white'}`}>
            <nav className="flex items-center gap-2 h-full mx-auto">
                {NAV_ITEMS.map((item) => (
                    <button 
                      key={item.value} 
                      onClick={() => handleNav(item.value)}
                      className={`flex items-center gap-3 px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-[0.15em] transition-all whitespace-nowrap ${
                          activeTab === item.value 
                          ? 'bg-blue-600 text-white shadow-lg' 
                          : isDark 
                            ? 'text-slate-500 hover:text-white hover:bg-white/5' 
                            : 'text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100'
                      }`}
                    >
                      <item.icon className={`w-4 h-4 ${activeTab === item.value ? 'text-white' : 'text-blue-500/50'}`} />
                      {item.label}
                    </button>
                ))}
            </nav>
        </div>
      </header>

      {mobileMenuOpen && (
          <div className={`fixed inset-0 z-[150] p-8 animate-in slide-in-from-right duration-300 flex flex-col ${isDark ? 'bg-slate-950' : 'bg-white'}`}>
              <div className="flex justify-between items-center mb-16">
                  <div className="flex items-center gap-4">
                      <HomeModernIcon className="w-8 h-8 text-blue-500" />
                      <h2 className={`text-xl font-black uppercase tracking-tighter ${isDark ? 'text-white' : 'text-zinc-900'}`}>Keja OS</h2>
                  </div>
                  <button onClick={() => setMobileMenuOpen(false)} className={`p-3.5 rounded-2xl border ${isDark ? 'bg-white/5 text-white border-white/5' : 'bg-zinc-100 text-zinc-900 border-zinc-200'}`}><XMarkIcon className="w-6 h-6" /></button>
              </div>
              <div className="space-y-4 flex-1 overflow-y-auto no-scrollbar pb-20">
                  {NAV_ITEMS.map(item => (
                      <button key={item.value} onClick={() => handleNav(item.value)} className={`w-full flex items-center justify-between p-7 rounded-3xl border transition-all group ${
                          isDark 
                          ? 'bg-white/5 hover:bg-blue-600/10 border-white/5' 
                          : 'bg-zinc-50 hover:bg-blue-50 border-zinc-200'
                      }`}>
                          <div className="flex items-center gap-6">
                              <item.icon className="w-7 h-7 text-blue-500" />
                              <span className={`font-black uppercase tracking-[0.2em] text-sm ${isDark ? 'text-white' : 'text-zinc-900'}`}>{item.label}</span>
                          </div>
                          <ChevronDownIcon className={`w-5 h-5 -rotate-90 ${isDark ? 'text-slate-700' : 'text-zinc-400'}`} />
                      </button>
                  ))}
              </div>
              <div className="mt-auto">
                 <button onClick={onAuthClick} className="w-full bg-blue-600 py-6 rounded-3xl text-white font-black uppercase tracking-widest text-xs shadow-2xl">Sign In / Register</button>
              </div>
          </div>
      )}
    </div>
  );
};

export const HomePageHero: React.FC<{ firstListing?: PropertyListing, pulseData?: MarketPulse | null }> = ({ firstListing, pulseData }) => {
    return (
        <div className="w-full pt-16 md:pt-24 pb-32 px-6 md:px-16 text-left relative overflow-hidden bg-[#020617]">
            <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1200px] h-[1200px] bg-blue-600/10 blur-[200px] rounded-full pointer-events-none"></div>
            
            <div className="max-w-[1600px] mx-auto flex flex-col lg:flex-row items-center gap-16 md:gap-32">
                <div className="flex-1 space-y-12 relative z-10">
                    <div className="inline-flex items-center gap-3 px-5 py-2 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-2xl animate-in fade-in slide-in-from-left-4 duration-1000">
                        <SparklesIcon className="w-5 h-5" />
                        <span className="text-[11px] font-black uppercase tracking-[0.4em]">Forensic Neural Property Discovery</span>
                    </div>
                    
                    <div className="space-y-8">
                        <h2 className="text-7xl md:text-[10rem] font-black text-white uppercase tracking-tighter leading-[0.8] animate-in slide-in-from-bottom-8 duration-1000">
                            Truth <br /><span className="text-blue-600">Lens</span>
                        </h2>
                        
                        {!pulseData ? (
                            <p className="text-slate-400 text-xl md:text-2xl font-medium max-w-2xl leading-relaxed italic animate-in slide-in-from-bottom-10 duration-1000">
                                "Aggregating 2025 market nodes for Kenya's luxury frontier. Stop searching, start auditing."
                            </p>
                        ) : (
                            <div className="space-y-10">
                                <div className="animate-in slide-in-from-bottom-10 duration-1000">
                                    <div className="bg-white/[0.03] border border-white/5 p-8 rounded-[3rem] text-slate-300 text-lg font-medium leading-relaxed max-w-2xl shadow-inner relative group overflow-hidden">
                                        <div className="absolute inset-0 bg-blue-600/5 opacity-0 group-hover:opacity-10 transition-opacity"></div>
                                        <div className="flex items-center gap-3 mb-4">
                                            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                                            <span className="text-[10px] font-black text-blue-500 uppercase tracking-[0.4em]">Regional Market Dossier: {firstListing?.location.split(',')[0]}</span>
                                        </div>
                                        <p className="relative z-10 italic">"{pulseData.market_sentiment}"</p>
                                    </div>
                                </div>
                                
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-in slide-in-from-bottom-12 duration-1000">
                                    <PulseMetricCard 
                                        label="Valuation Drift" 
                                        value={pulseData.price_trend} 
                                        trend={pulseData.dynamics_data?.[0]?.value || 50} 
                                        color={pulseData.price_trend === 'Rising' ? 'text-emerald-500' : 'text-rose-500'} 
                                        icon={pulseData.price_trend === 'Rising' ? ArrowTrendingUpIcon : ArrowTrendingDownIcon} 
                                        subtext={`${pulseData.drift_percentage} Velocity`}
                                        delay={100}
                                    />
                                    <PulseMetricCard 
                                        label="Search Pressure" 
                                        value={pulseData.demand_level} 
                                        trend={pulseData.dynamics_data?.[1]?.value || 60} 
                                        color="text-blue-500" 
                                        icon={UserGroupIcon} 
                                        subtext="Demand Index node"
                                        delay={200}
                                    />
                                    <PulseMetricCard 
                                        label="Asset Liquidity" 
                                        value={`${pulseData.liquidity_score}/100`} 
                                        trend={pulseData.liquidity_score} 
                                        color="text-purple-500" 
                                        icon={BoltIcon} 
                                        subtext="Transaction velocity"
                                        delay={300}
                                    />
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="flex flex-wrap gap-8 animate-in slide-in-from-bottom-14 duration-1000 pt-6">
                        <button className="px-14 py-6 bg-blue-600 hover:bg-blue-500 text-white font-black uppercase tracking-[0.3em] text-xs rounded-3xl shadow-[0_25px_60px_rgba(37,99,235,0.4)] transition-all active:scale-95 border border-blue-400/20 group relative overflow-hidden">
                            <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
                            Launch Exploration
                        </button>
                        <div className="flex items-center gap-6 p-4 bg-white/5 border border-white/5 rounded-3xl pr-10 shadow-2xl backdrop-blur-sm">
                             <div className="w-14 h-14 bg-slate-900 rounded-2xl flex items-center justify-center text-blue-500 border border-white/5 shadow-inner relative group">
                                <CpuChipIcon className="w-7 h-7 group-hover:animate-spin-slow" />
                                <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full animate-pulse border-2 border-slate-900"></div>
                             </div>
                             <div>
                                <p className="text-white font-black text-sm uppercase tracking-tight">Emmanuel v4.5</p>
                                <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Active Node Pulse</p>
                             </div>
                        </div>
                    </div>
                </div>

                {firstListing && (
                    <div className="w-full lg:w-[600px] animate-in zoom-in duration-1000 hidden md:block relative group perspective-1000">
                        <div className="absolute inset-0 bg-blue-600/20 blur-[80px] opacity-0 group-hover:opacity-40 transition-opacity duration-1000"></div>
                        <div className="bg-slate-900 p-8 rounded-[4rem] border border-white/5 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] relative z-10 transform transition-transform duration-700 group-hover:rotate-y-2 group-hover:rotate-x-2">
                            <div className="absolute inset-0 bg-blue-600/5 opacity-0 group-hover:opacity-10 transition-opacity"></div>
                            <div className="aspect-[4/5] rounded-[3.5rem] overflow-hidden mb-10 relative shadow-2xl bg-black">
                                <img src={firstListing.image_url} className="w-full h-full object-cover transition-transform duration-[8000ms] group-hover:scale-110 opacity-90" />
                                <div className="absolute bottom-10 left-10 right-10 p-8 bg-black/60 backdrop-blur-2xl border border-white/10 rounded-[2.5rem] flex items-center justify-between shadow-3xl">
                                    <div>
                                        <p className="text-blue-400 text-[10px] font-black uppercase tracking-[0.5em] mb-1.5">{firstListing.location}</p>
                                        <h3 className="text-2xl font-black text-white uppercase tracking-tighter truncate max-w-[200px]">{firstListing.title}</h3>
                                    </div>
                                    <div className="text-right">
                                        <span className="text-[9px] text-slate-500 font-black uppercase tracking-widest block mb-1">ROI Score</span>
                                        <span className="text-3xl font-black text-emerald-400 font-mono tracking-tighter">{firstListing.vibe_score * 10}%</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex items-center justify-between px-6 pt-2">
                                <div className="flex items-baseline gap-2">
                                    <span className="text-xs font-black text-slate-500 uppercase tracking-widest">Valuation</span>
                                    <span className="text-4xl font-black text-white font-mono tracking-tighter">{(firstListing.price/1000000).toFixed(1)}M</span>
                                </div>
                                <div className="p-5 bg-blue-600/10 rounded-2xl border border-blue-500/20 text-blue-500 group-hover:scale-110 transition-transform">
                                    <SignalIcon className="w-6 h-6 animate-pulse" />
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
