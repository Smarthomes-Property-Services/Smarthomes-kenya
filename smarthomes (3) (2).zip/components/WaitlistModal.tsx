
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { XMarkIcon, CheckCircleIcon, LockClosedIcon, SparklesIcon, SignalIcon } from '@heroicons/react/24/solid';

interface WaitlistModalProps {
  isOpen: boolean;
  onClose: () => void;
  searchIntent: string;
}

export const WaitlistModal: React.FC<WaitlistModalProps> = ({ isOpen, onClose, searchIntent }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Saving Lead to Waitlist:", { name, phone, searchIntent });
    setSubmitted(true);
    
    setTimeout(() => {
        onClose();
        setTimeout(() => {
            setSubmitted(false);
            setName('');
            setPhone('');
        }, 500);
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-300">
        <div className="w-full max-w-md bg-[#09090b] border border-white/10 rounded-[3rem] shadow-[0_0_100px_rgba(0,0,0,1)] overflow-hidden relative scale-100 animate-in zoom-in-95 duration-200">
            <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none"></div>
            
            <button onClick={onClose} className="absolute top-6 right-6 p-2 bg-white/5 hover:bg-white/10 rounded-full text-slate-500 hover:text-white transition-all z-20">
                <XMarkIcon className="w-5 h-5" />
            </button>
            
            <div className="p-10 relative z-10 text-left">
                {submitted ? (
                    <div className="flex flex-col items-center justify-center text-center py-12 animate-in fade-in slide-in-from-bottom-4">
                        <div className="w-24 h-24 bg-emerald-600/10 rounded-full flex items-center justify-center mb-8 border border-emerald-500/20 shadow-[0_0_40px_rgba(16,185,129,0.3)]">
                            <CheckCircleIcon className="w-12 h-12 text-emerald-500 animate-pulse" />
                        </div>
                        <h3 className="text-3xl font-black text-white uppercase tracking-tighter mb-4">Registry Synced</h3>
                        <p className="text-slate-400 text-sm font-medium leading-relaxed max-w-xs mx-auto">
                            The agent node for <span className="text-blue-400 font-bold">"{searchIntent}"</span> has been activated in your name.
                        </p>
                        <div className="flex items-center gap-3 mt-8 px-4 py-2 bg-white/5 rounded-xl">
                            <SignalIcon className="w-4 h-4 text-emerald-500 animate-pulse" />
                            <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Redirecting...</span>
                        </div>
                    </div>
                ) : (
                    <>
                        <div className="mb-8">
                            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-amber-500/10 border border-amber-500/20 rounded-full text-[9px] font-black text-amber-500 uppercase tracking-widest mb-6">
                                <SparklesIcon className="w-3 h-3" /> Priority Access Node
                            </div>
                            <h2 className="text-4xl font-black text-white uppercase tracking-tighter mb-4 leading-none">
                                Join the <span className="text-blue-500">Waitlist</span>
                            </h2>
                            <p className="text-slate-500 text-sm font-medium leading-relaxed">
                                Forensic scan initiated for <span className="text-blue-400 italic font-bold">"{searchIntent}"</span>. 
                                <br/>Our AI is aggregating 42 restricted sources. Where should we dispatch the dossier?
                            </p>
                        </div>
                        
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="space-y-2">
                                <label className="block text-[10px] font-black text-slate-600 uppercase tracking-[0.2em] pl-3">Full Name Signature</label>
                                <input 
                                    type="text" 
                                    required
                                    value={name}
                                    onChange={e => setName(e.target.value)}
                                    className="w-full bg-slate-900 border border-white/10 rounded-2xl px-6 py-4 text-white text-sm font-medium placeholder-slate-700 focus:border-blue-500 outline-none transition-all shadow-inner"
                                    placeholder="e.g. Kamau Otieno"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="block text-[10px] font-black text-slate-600 uppercase tracking-[0.2em] pl-3">WhatsApp Relay Node</label>
                                <input 
                                    type="tel" 
                                    required
                                    value={phone}
                                    onChange={e => setPhone(e.target.value)}
                                    className="w-full bg-slate-900 border border-white/10 rounded-2xl px-6 py-4 text-white text-sm font-medium placeholder-slate-700 focus:border-blue-500 outline-none transition-all shadow-inner"
                                    placeholder="e.g. 0712 345 678"
                                />
                            </div>
                            <button 
                                type="submit"
                                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black uppercase tracking-[0.2em] text-[11px] py-5 rounded-2xl shadow-2xl transition-all active:scale-95 mt-4 border border-blue-400/30"
                            >
                                Activate Notification Node
                            </button>
                            <div className="flex items-center justify-center gap-3 mt-6 opacity-50">
                                <LockClosedIcon className="w-3 h-3 text-slate-500" />
                                <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest">
                                    AES-256 Encrypted Handshake
                                </p>
                            </div>
                        </form>
                    </>
                )}
            </div>
        </div>
    </div>
  );
};
