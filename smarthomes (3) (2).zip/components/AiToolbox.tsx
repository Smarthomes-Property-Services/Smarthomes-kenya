
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef } from 'react';
import { SparklesIcon, PhotoIcon, VideoCameraIcon, XMarkIcon, RocketLaunchIcon, ArrowPathIcon, MicrophoneIcon, StopIcon, MagnifyingGlassIcon, PlayIcon, DocumentMagnifyingGlassIcon } from '@heroicons/react/24/solid';
import { generateHighQualityImage, generateVeoVideo, transcribeAudio, analyzeVideo } from '../services/gemini';

export const AiToolbox: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const [mode, setMode] = useState<'image' | 'video' | 'transcribe' | 'analyze-video'>('image');
    const [prompt, setPrompt] = useState('');
    const [aspectRatio, setAspectRatio] = useState('1:1');
    const [imageSize, setImageSize] = useState('1K');
    const [isLoading, setIsLoading] = useState(false);
    const [resultUrl, setResultUrl] = useState<string | null>(null);
    const [analysisResult, setAnalysisResult] = useState<string | null>(null);
    const [transcription, setTranscription] = useState<string | null>(null);
    const [isRecording, setIsRecording] = useState(false);
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setSelectedFile(e.target.files[0]);
        }
    };

    const handleGenerate = async () => {
        if (!prompt.trim() && mode !== 'transcribe') return;
        setIsLoading(true);
        setResultUrl(null);
        setAnalysisResult(null);
        try {
            if (mode === 'image') {
                const url = await generateHighQualityImage(prompt, aspectRatio, imageSize);
                setResultUrl(url);
            } else if (mode === 'video') {
                let startImageB64 = undefined;
                if (selectedFile) {
                    startImageB64 = await new Promise<string>((resolve) => {
                        const reader = new FileReader();
                        reader.onload = () => resolve(reader.result as string);
                        reader.readAsDataURL(selectedFile);
                    });
                }
                const url = await generateVeoVideo(prompt, aspectRatio as any, startImageB64);
                setResultUrl(url);
            } else if (mode === 'analyze-video') {
                if (!selectedFile) return;
                const videoB64 = await new Promise<string>((resolve) => {
                    const reader = new FileReader();
                    reader.onload = () => resolve(reader.result as string);
                    reader.readAsDataURL(selectedFile);
                });
                const result = await analyzeVideo(videoB64, prompt || "Provide key information from this video.");
                setAnalysisResult(result);
            }
        } catch (e) {
            console.error(e);
        } finally {
            setIsLoading(false);
        }
    };

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorderRef.current = new MediaRecorder(stream);
            audioChunksRef.current = [];
            mediaRecorderRef.current.ondataavailable = (e) => audioChunksRef.current.push(e.data);
            mediaRecorderRef.current.onstop = async () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                const reader = new FileReader();
                reader.readAsDataURL(audioBlob);
                reader.onloadend = async () => {
                    const base64Audio = (reader.result as string).split(',')[1];
                    setIsLoading(true);
                    try {
                        const text = await transcribeAudio(base64Audio, 'audio/webm');
                        setTranscription(text);
                    } catch (e) { console.error(e); }
                    finally { setIsLoading(false); }
                };
            };
            mediaRecorderRef.current.start();
            setIsRecording(true);
        } catch (e) { console.error(e); }
    };

    const stopRecording = () => {
        mediaRecorderRef.current?.stop();
        setIsRecording(false);
    };

    return (
        <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-300">
            <div className="bg-slate-950 border border-white/10 w-full max-w-4xl rounded-[3rem] shadow-3xl overflow-hidden flex flex-col max-h-[90vh]">
                <div className="p-8 border-b border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-blue-600/10 rounded-2xl text-blue-500">
                            <SparklesIcon className="w-6 h-6" />
                        </div>
                        <h2 className="text-2xl font-black text-white uppercase tracking-tighter">Neural Forge</h2>
                    </div>
                    <button onClick={onClose} className="p-2 text-slate-500 hover:text-white transition-colors">
                        <XMarkIcon className="w-8 h-8" />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-10 space-y-10 text-left">
                    <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-white/5 w-fit overflow-x-auto no-scrollbar">
                        <button onClick={() => { setMode('image'); setResultUrl(null); }} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${mode === 'image' ? 'bg-blue-600 text-white' : 'text-slate-500'}`}>Image Gen</button>
                        <button onClick={() => { setMode('video'); setResultUrl(null); }} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${mode === 'video' ? 'bg-blue-600 text-white' : 'text-slate-500'}`}>Video Gen</button>
                        <button onClick={() => { setMode('analyze-video'); setAnalysisResult(null); }} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${mode === 'analyze-video' ? 'bg-blue-600 text-white' : 'text-slate-500'}`}>Video Intel</button>
                        <button onClick={() => { setMode('transcribe'); setTranscription(null); }} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${mode === 'transcribe' ? 'bg-blue-600 text-white' : 'text-slate-500'}`}>Transcription</button>
                    </div>

                    {(mode === 'image' || mode === 'video' || mode === 'analyze-video') && (
                        <>
                            <div className="space-y-4">
                                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Creative Prompt / Query</label>
                                <textarea 
                                    value={prompt}
                                    onChange={e => setPrompt(e.target.value)}
                                    className="w-full bg-black border border-white/10 rounded-[2rem] p-6 text-white text-sm focus:border-blue-500 outline-none resize-none"
                                    placeholder={mode === 'image' ? "Hyper-realistic penthouse in Runda..." : mode === 'video' ? "Drone flyover of a luxury villa..." : "Analyze this video for architectural key points..."}
                                    rows={3}
                                />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                                {mode !== 'analyze-video' && (
                                    <div className="space-y-4">
                                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Aspect Ratio</label>
                                        <select value={aspectRatio} onChange={e => setAspectRatio(e.target.value)} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-4 text-white text-xs outline-none appearance-none">
                                            <option value="1:1">1:1 (Square)</option>
                                            <option value="2:3">2:3 (Classic Portrait)</option>
                                            <option value="3:2">3:2 (Classic Landscape)</option>
                                            <option value="3:4">3:4 (Portrait)</option>
                                            <option value="4:3">4:3 (Standard)</option>
                                            <option value="9:16">9:16 (Vertical/Story)</option>
                                            <option value="16:9">16:9 (Landscape/Widescreen)</option>
                                            <option value="21:9">21:9 (Cinematic)</option>
                                        </select>
                                    </div>
                                )}
                                {mode === 'image' && (
                                    <div className="space-y-4">
                                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Image Quality (Size)</label>
                                        <select value={imageSize} onChange={e => setImageSize(e.target.value)} className="w-full bg-slate-900 border border-white/10 rounded-2xl p-4 text-white text-xs outline-none appearance-none">
                                            <option value="1K">1K (Standard)</option>
                                            <option value="2K">2K (High Detail)</option>
                                            <option value="4K">4K (Ultra Quality)</option>
                                        </select>
                                    </div>
                                )}
                                {(mode === 'video' || mode === 'analyze-video') && (
                                    <div className="space-y-4">
                                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-4">Attach Asset (Optional for Video Gen, Required for Intel)</label>
                                        <div 
                                            onClick={() => fileInputRef.current?.click()}
                                            className={`w-full bg-slate-900 border border-white/10 rounded-2xl p-4 text-white text-xs flex items-center justify-between cursor-pointer hover:border-blue-500/50 transition-all ${selectedFile ? 'text-emerald-400' : 'text-slate-500'}`}
                                        >
                                            <span className="truncate">{selectedFile ? selectedFile.name : "Select photo/video file..."}</span>
                                            {mode === 'video' ? <PhotoIcon className="w-4 h-4" /> : <VideoCameraIcon className="w-4 h-4" />}
                                        </div>
                                        <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileChange} accept={mode === 'video' ? "image/*" : "video/*"} />
                                    </div>
                                )}
                            </div>
                        </>
                    )}

                    {mode === 'transcribe' && (
                        <div className="flex flex-col items-center gap-10 py-10">
                            <button 
                                onClick={isRecording ? stopRecording : startRecording}
                                className={`w-32 h-32 rounded-full flex items-center justify-center transition-all ${isRecording ? 'bg-red-600 animate-pulse' : 'bg-blue-600 hover:bg-blue-500 shadow-xl'}`}
                            >
                                {isRecording ? <StopIcon className="w-12 h-12 text-white" /> : <MicrophoneIcon className="w-12 h-12 text-white" />}
                            </button>
                            <p className="text-white font-black uppercase tracking-widest text-xs">{isRecording ? "Recording Pulse..." : "Activate Mic Node"}</p>
                            
                            {transcription && (
                                <div className="w-full bg-black border border-white/10 rounded-[2rem] p-8 text-slate-300 italic text-lg leading-relaxed animate-in fade-in slide-in-from-bottom-2">
                                    "{transcription}"
                                </div>
                            )}
                        </div>
                    )}

                    {analysisResult && (
                        <div className="bg-slate-900 border border-white/10 rounded-[2rem] p-8 text-slate-200 leading-relaxed animate-in zoom-in-95 duration-500">
                             <div className="flex items-center gap-3 mb-4 text-blue-400">
                                <DocumentMagnifyingGlassIcon className="w-6 h-6" />
                                <span className="text-[10px] font-black uppercase tracking-widest">Video Analysis Complete</span>
                             </div>
                             <p className="whitespace-pre-line">{analysisResult}</p>
                        </div>
                    )}

                    {resultUrl && (
                        <div className="bg-black border border-white/10 rounded-[3rem] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-500">
                            {mode === 'image' ? (
                                <img src={resultUrl} className="w-full h-auto" />
                            ) : (
                                <video src={resultUrl} className="w-full" controls autoPlay loop />
                            )}
                        </div>
                    )}
                </div>

                <div className="p-8 border-t border-white/5 bg-slate-900/50 flex justify-end">
                    {(mode === 'image' || mode === 'video' || mode === 'analyze-video') && (
                        <button 
                            onClick={handleGenerate}
                            disabled={isLoading || (!prompt.trim() && mode !== 'analyze-video')}
                            className="px-12 py-5 bg-blue-600 hover:bg-blue-500 text-white rounded-[1.75rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-2xl transition-all disabled:opacity-50 flex items-center gap-4"
                        >
                            {isLoading ? <ArrowPathIcon className="w-5 h-5 animate-spin" /> : <RocketLaunchIcon className="w-5 h-5" />}
                            Execute Synthesis
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};
