
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
    ResponsiveContainer, 
    AreaChart, 
    Area, 
    XAxis, 
    YAxis, 
    Tooltip as ReTooltip, 
    RadarChart, 
    PolarGrid, 
    PolarAngleAxis, 
    PolarRadiusAxis, 
    Radar,
    LineChart,
    Line,
    CartesianGrid,
    BarChart,
    Bar,
    Cell
} from 'recharts';
import { 
    XMarkIcon, 
    BuildingOfficeIcon, 
    CpuChipIcon, 
    ArrowPathIcon, 
    MapPinIcon, 
    SparklesIcon, 
    ScaleIcon, 
    BoltIcon, 
    CalendarIcon,
    CheckIcon, 
    CheckCircleIcon,
    ArrowDownTrayIcon, 
    BanknotesIcon, 
    CheckBadgeIcon, 
    BeakerIcon, 
    DocumentTextIcon, 
    AdjustmentsHorizontalIcon, 
    CommandLineIcon, 
    VideoCameraIcon, 
    FingerPrintIcon, 
    ChatBubbleLeftRightIcon, 
    FireIcon, 
    PresentationChartLineIcon, 
    ChatBubbleBottomCenterIcon, 
    PlayIcon, 
    LockClosedIcon, 
    ShieldCheckIcon as ShieldCheckSolid, 
    DocumentMagnifyingGlassIcon, 
    CircleStackIcon, 
    MagnifyingGlassPlusIcon, 
    ChevronLeftIcon, 
    ChevronRightIcon, 
    ArrowTrendingUpIcon, 
    ArrowTrendingDownIcon, 
    ChatBubbleOvalLeftEllipsisIcon, 
    RocketLaunchIcon, 
    SignalIcon, 
    Squares2X2Icon, 
    ChartBarIcon, 
    MagnifyingGlassIcon, 
    UserGroupIcon, 
    StarIcon, 
    GlobeAltIcon, 
    ShieldExclamationIcon, 
    CameraIcon, 
    ExclamationTriangleIcon, 
    ShieldCheckIcon, 
    PhotoIcon, 
    ArrowUpRightIcon, 
    ClipboardDocumentIcon, 
    HashtagIcon, 
    TargetIcon, 
    LightBulbIcon, 
    ArrowTrendingUpIcon as TrendingUp, 
    PresentationChartBarIcon, 
    FaceSmileIcon, 
    ClockIcon as TimeIcon, 
    CubeIcon, 
    Square3Stack3DIcon, 
    LinkIcon, 
    ShieldCheckIcon as ShieldCheckBtn, 
    InformationCircleIcon, 
    TagIcon, 
    BriefcaseIcon, 
    BuildingStorefrontIcon, 
    HomeModernIcon, 
    SpeakerWaveIcon
} from '@heroicons/react/24/solid';
import { PropertyListing, enhancePropertyDescription, MarketPulse, getMarketPulse, EnhancedDescription, generateAssetVideo, analyzePropertyImage, VisionAnalysis, generatePropertyImage, performInvestmentAudit, InvestmentAuditReport, speakDescription, editPropertyImage } from '../services/gemini.ts';

interface ListingDetailsModalProps {
    listing: PropertyListing | null;
    favorites?: string[];
    onToggleFavorite?: (id: string) => void;
    onClose: () => void;
    allMessages: Record<string, any[]>;
    onSendMessage: (threadId: string, text: string) => void;
    onLinkProperty: (threadId: string, property: any) => void;
    onRateProperty: (id: string, rating: number) => void;
}

const PLACEHOLDER_TEXT = "Shadow Aggregator detected this asset, but a forensic narrative is currently pending. Neural link required for full dossier.";

// Tooltip Protocol Component
const Tooltip: React.FC<{ text: string, children: React.ReactNode, width?: string, title?: string }> = ({ text, children, width = "w-64", title = "Forensic Protocol Info" }) => (
    <div className="group/tooltip relative inline-block">
        {children}
        <div className={`absolute bottom-full left-1/2 -translate-x-1/2 mb-4 px-5 py-4 bg-slate-950 border border-blue-500/30 rounded-[1.5rem] text-[10px] font-medium text-slate-300 tracking-normal leading-relaxed whitespace-normal ${width} opacity-0 group-hover/tooltip:opacity-100 transition-all duration-300 pointer-events-none z-[100] shadow-[0_30px_70px_rgba(0,0,0,0.9)] scale-90 group-hover/tooltip:scale-100 origin-bottom border-b-4 border-b-blue-600 backdrop-blur-xl`}>
            <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2 border-b border-white/5 pb-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></div>
                    <span className="text-blue-400 font-black uppercase tracking-[0.2em] text-[8px]">{title}</span>
                </div>
                <p className="leading-relaxed">{text}</p>
            </div>
            <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-blue-600" />
        </div>
    </div>
);

const TabTrigger: React.FC<{ active: boolean, onClick: () => void, label: string, icon: any, id: string }> = ({ active, onClick, label, icon: Icon, id }) => (
    <button 
        id={id}
        onClick={onClick}
        role="tab"
        aria-selected={active}
        className={`flex items-center gap-3 px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all duration-500 outline-none ${active ? 'bg-indigo-600 text-white shadow-[0_15px_30px_rgba(79,70,229,0.4)]' : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-900'}`}
    >
        <Icon className={`w-4 h-4 transition-transform duration-500 ${active ? 'scale-110' : ''}`} />
        {label}
    </button>
);

const StatItem = ({ label, value, icon: Icon, color, subValue, isLoading }: any) => (
    <div className="bg-zinc-50 dark:bg-zinc-900/40 p-8 rounded-[3rem] border border-zinc-200 dark:border-zinc-800 hover:border-indigo-500/30 transition-all group relative overflow-hidden text-left shadow-xl dark:shadow-2xl">
        {isLoading && (
            <div className="absolute inset-0 bg-white/60 dark:bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center z-20">
                <ArrowPathIcon className="w-6 h-6 text-indigo-600 dark:text-blue-500 animate-spin mb-3" />
                <span className="text-[8px] font-black text-indigo-600 dark:text-blue-400 uppercase tracking-widest animate-pulse">Establishing Node...</span>
            </div>
        )}
        <div className={`p-4 rounded-2xl bg-white dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 mb-6 inline-block ${color} group-hover:scale-110 transition-all duration-500 shadow-inner`}>
            <Icon className="w-7 h-7" />
        </div>
        <p className="text-[10px] font-black text-zinc-400 dark:text-zinc-600 uppercase tracking-[0.4em] mb-2">{label}</p>
        <p className="text-xl font-black text-zinc-900 dark:text-white uppercase tracking-tighter leading-tight">{value || '---'}</p>
        {subValue && <p className="text-[9px] font-black text-zinc-500 uppercase tracking-widest mt-2 bg-white/50 dark:bg-zinc-900/60 px-2 py-0.5 rounded w-fit">{subValue}</p>}
    </div>
);

const SpecCard = ({ label, value, icon: Icon }: any) => (
    <div className="bg-slate-900/40 border border-white/5 p-6 rounded-[2rem] flex items-center gap-5 hover:border-blue-500/20 transition-all group">
        <div className="p-3 bg-blue-600/10 rounded-xl text-blue-500 group-hover:scale-110 transition-transform">
            <Icon className="w-6 h-6" />
        </div>
        <div className="overflow-hidden">
            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1 truncate">{label}</p>
            <p className="text-sm font-black text-white uppercase tracking-tight truncate" title={value?.toString()}>{value}</p>
        </div>
    </div>
);

const MetricRow = ({ label, value, icon: Icon, color }: any) => (
    <div className="flex items-center justify-between group">
        <div className="flex items-center gap-5">
            <div className={`p-3 rounded-xl bg-zinc-950 border border-zinc-800 shadow-inner ${color || 'text-zinc-500'} group-hover:scale-110 transition-transform`}>
                <Icon className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-black text-zinc-600 dark:text-zinc-500 uppercase tracking-widest">{label}</span>
        </div>
        <span className="text-sm font-black text-zinc-900 dark:text-white uppercase tracking-tight">{value}</span>
    </div>
);

const VaultNode = ({ label, status, icon: Icon, isLocked }: any) => (
    <div className={`p-8 rounded-[3rem] border transition-all duration-500 group relative overflow-hidden text-left ${isLocked ? 'bg-zinc-100/50 dark:bg-zinc-950/40 border-zinc-200 dark:border-zinc-800 opacity-60' : 'bg-white dark:bg-zinc-900/60 border-zinc-200 dark:border-zinc-800 hover:border-blue-500/30 shadow-xl'}`}>
        <div className="flex items-center justify-between mb-8">
            <div className={`p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-100 dark:border-zinc-800 ${isLocked ? 'text-zinc-400' : 'text-blue-500'} group-hover:scale-110 transition-transform shadow-inner`}>
                <Icon className="w-6 h-6" />
            </div>
            {isLocked ? (
                <LockClosedIcon className="w-5 h-5 text-zinc-600" />
            ) : (
                <CheckBadgeIcon className="w-5 h-5 text-emerald-500" />
            )}
        </div>
        <p className="text-[10px] font-black text-zinc-400 dark:text-zinc-600 uppercase tracking-[0.4em] mb-2">{label}</p>
        <p className={`text-xl font-black uppercase tracking-tighter leading-none ${isLocked ? 'text-zinc-500' : 'text-zinc-900 dark:text-white'}`}>{status}</p>
        {isLocked && (
            <div className="absolute inset-0 bg-black/5 flex items-center justify-center opacity-0 group-hover:opacity-10 transition-opacity">
                <span className="text-[8px] font-black text-white bg-zinc-900 px-3 py-1 rounded-full uppercase tracking-[0.2em] shadow-2xl">Access Restricted</span>
            </div>
        )}
    </div>
);

const InteractiveImage = ({ src, nextImage, prevImage, hasMultiple }: { src: string, nextImage: () => void, prevImage: () => void, hasMultiple: boolean }) => {
    const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
    const [isHovering, setIsHovering] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;
        setMousePos({ x, y });
    };

    return (
        <div 
            ref={containerRef}
            className="w-full h-full relative group/viewer cursor-none overflow-hidden bg-zinc-100 dark:bg-zinc-950"
            onMouseMove={handleMouseMove}
            onMouseEnter={() => setIsHovering(true)}
            onMouseLeave={() => {
                setMousePos({ x: 0, y: 0 });
                setIsHovering(false);
            }}
        >
            <img 
                src={src} 
                className={`w-full h-full object-cover transition-all duration-1000 cubic-bezier(0.16, 1, 0.3, 1) ${isHovering ? 'scale-[1.1] blur-[0.5px]' : 'scale-100'}`} 
                alt="Asset Visual"
            />
            
            {isHovering && (
                <div 
                    className="absolute z-30 pointer-events-none w-64 h-64 border-4 border-indigo-500/50 rounded-full overflow-hidden shadow-[0_0_100px_rgba(79,70,229,0.4)] backdrop-blur-sm -translate-x-1/2 -translate-y-1/2 ring-[100vw] ring-black/40"
                    style={{ left: `${mousePos.x}%`, top: `${mousePos.y}%` }}
                >
                    <img 
                        src={src} 
                        className="absolute w-[400%] h-[400%] max-w-none object-cover transition-transform duration-100 ease-out"
                        style={{ 
                            left: `-${mousePos.x * 4 - 50}%`, 
                            top: `-${mousePos.y * 4 - 50}%` 
                        }}
                    />
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-indigo-600 px-3 py-1 rounded-full text-[7px] font-black text-white uppercase tracking-widest">Loupe 4X</div>
                </div>
            )}

            {hasMultiple && (
                <div className="absolute inset-y-0 left-0 w-32 flex items-center justify-center opacity-0 group-viewer/hover:opacity-100 transition-opacity z-50">
                    <button onClick={(e) => { e.stopPropagation(); prevImage(); }} className="p-6 bg-black/60 hover:bg-black rounded-full border border-white/10 text-white transition-all shadow-3xl hover:scale-110">
                        <ChevronLeftIcon className="w-8 h-8" />
                    </button>
                </div>
            )}
            {hasMultiple && (
                <div className="absolute inset-y-0 right-0 w-32 flex items-center justify-center opacity-0 group-viewer/hover:opacity-100 transition-opacity z-50">
                    <button onClick={(e) => { e.stopPropagation(); nextImage(); }} className="p-6 bg-black/60 hover:bg-black rounded-full border border-white/10 text-white transition-all shadow-3xl hover:scale-110">
                        <ChevronRightIcon className="w-8 h-8" />
                    </button>
                </div>
            )}
        </div>
    );
};

export const ListingDetailsModal: React.FC<ListingDetailsModalProps> = ({ 
    listing, onClose, allMessages, onSendMessage, onLinkProperty, onRateProperty
}) => {
    const [activeTab, setActiveTab] = useState<'overview' | 'market' | 'vault' | 'logs'>('overview');
    const [enhancedData, setEnhancedData] = useState<EnhancedDescription | null>(null);
    const [isPolishing, setIsPolishing] = useState(false);
    const [isScanning, setIsScanning] = useState(false);
    const [isSynthesizing, setIsSynthesizing] = useState(false);
    const [visionAnalysis, setVisionAnalysis] = useState<VisionAnalysis | null>(null);
    const [isFetchingPulse, setIsFetchingPulse] = useState(false);
    const [currentImgIdx, setCurrentImgIdx] = useState(0);
    const [pulseData, setPulseData] = useState<MarketPulse | null>(null);
    const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
    const [videoStep, setVideoStep] = useState(0);
    const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
    const [copyStatus, setCopyStatus] = useState<string | null>(null);
    const [isSpeaking, setIsSpeaking] = useState(false);
    const [isEditingPhoto, setIsEditingPhoto] = useState(false);
    const [editPrompt, setEditPrompt] = useState('');
    const audioRef = useRef<HTMLAudioElement | null>(null);
    
    // Audit Specific State
    const [auditReport, setAuditReport] = useState<InvestmentAuditReport | null>(null);
    const [isAuditing, setIsAuditing] = useState(false);
    
    const images = listing?.images && listing.images.length > 0 ? listing.images : [listing?.image_url || ''];

    const videoLoadingMessages = [
        "Synthesizing Virtual Agent Emmanuel...",
        "Calibrating Interior Fly-Through Trajectories...",
        "Polishing Neural Drone Optics...",
        "Rendering Cinematic Real Estate Assets...",
        "Establishing Property Node Perspective..."
    ];

    const fetchMarketPulseData = async (location: string) => {
        setIsFetchingPulse(true);
        try {
            const data = await getMarketPulse(location);
            setPulseData(data);
        } catch (err) {
            console.error("Pulse error:", err);
        } finally {
            setIsFetchingPulse(false);
        }
    };

    useEffect(() => {
        if (activeTab === 'market' && !pulseData && listing) {
            fetchMarketPulseData(listing.location);
        }
    }, [activeTab, listing, pulseData]);

    // Updated handleForensicAudit to use the structured object returned by performInvestmentAudit
    const handleForensicAudit = async () => {
        if (!listing || isAuditing) return;
        setIsAuditing(true);
        setAuditReport(null);
        try {
            const goal = `Analyze deep ROI potential, capital appreciation drifts, and risk assessment for this ${listing.type} in ${listing.location}.`;
            const report = await performInvestmentAudit(listing.location, goal);
            setAuditReport(report);
        } catch (err) {
            console.error("Audit failed:", err);
        } finally {
            setIsAuditing(false);
        }
    };

    const handleTruthLensScan = async () => {
        if (isScanning || !listing) return;
        setIsScanning(true);
        setVisionAnalysis(null);
        try {
            const result = await analyzePropertyImage(images[currentImgIdx], `Analyzing ${listing.title} in ${listing.location}`);
            setVisionAnalysis(result);
        } catch (err) {
            console.error("Truth-Lens™ Scan failed:", err);
        } finally {
            setIsScanning(false);
        }
    };

    const handleLaunchTour = async () => {
        if (isGeneratingVideo || !listing) return;
        setIsGeneratingVideo(true);
        setVideoStep(0);
        try {
            const url = await generateAssetVideo(`Cinematic tour of ${listing.title} in ${listing.location}`, listing.image_url);
            setGeneratedVideoUrl(url);
        } catch (err) {
            console.error(err);
        } finally {
            setIsGeneratingVideo(false);
        }
    };

    const handleTTS = async () => {
        if (isSpeaking) {
            audioRef.current?.pause();
            setIsSpeaking(false);
            return;
        }
        const textToSpeak = enhancedData?.description || listing?.description || PLACEHOLDER_TEXT;
        setIsSpeaking(true);
        try {
            const base64Audio = await speakDescription(textToSpeak);
            if (base64Audio) {
                const audio = new Audio(`data:audio/pcm;base64,${base64Audio}`);
                audioRef.current = audio;
                audio.play();
                audio.onended = () => setIsSpeaking(false);
            }
        } catch (e) {
            console.error(e);
            setIsSpeaking(false);
        }
    };

    const handlePhotoEdit = async () => {
        if (!editPrompt.trim() || isEditingPhoto) return;
        setIsEditingPhoto(true);
        try {
            const editedUrl = await editPropertyImage(editPrompt, images[currentImgIdx]);
            // For demo purposes, we replace the first image or current image index
            // In a real app we might append to the array
            alert("Neural Edit Complete. Asset established in local registry buffer.");
        } catch (e) {
            console.error(e);
        } finally {
            setIsEditingPhoto(false);
        }
    };

    useEffect(() => {
        if (listing) {
            setPulseData(null);
            setEnhancedData(listing.enhanced_data || null); 
            setGeneratedVideoUrl(null);
            setVisionAnalysis(null);
            setAuditReport(null);
            setCurrentImgIdx(0);
        }
    }, [listing]);

    const handleAIEnhance = async () => {
        if (isPolishing || !listing) return;
        setIsPolishing(true);
        try {
            // Check if we have pulse data, if not, try to fetch it quickly for context
            let currentPulse = pulseData;
            if (!currentPulse) {
                try {
                    currentPulse = await getMarketPulse(listing.location);
                    setPulseData(currentPulse);
                } catch (e) {
                    console.warn("Market pulse fetch failed during enhancement, proceeding without context.", e);
                }
            }

            const enhanced = await enhancePropertyDescription(listing, currentPulse);
            setEnhancedData(enhanced);
        } catch (error) { 
            console.error(error); 
        } finally { 
            setIsPolishing(false); 
        }
    };

    if (!listing) return null;

    // Determine verification status: either explicitly verified in listing data OR confirmed via Truth-Lens analysis
    const isVerified = listing.is_verified || (visionAnalysis?.scam_risk === 'Low');

    return (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-0 md:p-10 bg-black/60 dark:bg-black/98 backdrop-blur-2xl animate-in fade-in duration-700">
            <div className="bg-white dark:bg-[#050507] border border-zinc-200 dark:border-zinc-800 w-full max-w-[1800px] h-full md:h-[95vh] md:rounded-[5rem] overflow-hidden shadow-[0_0_200px_rgba(0,0,0,0.8)] relative flex flex-col transition-colors text-left">
                
                {/* Modal Header Protocol */}
                <div className="px-10 md:px-20 py-10 border-b border-zinc-100 dark:border-zinc-900 bg-white/60 dark:bg-zinc-950/60 backdrop-blur-3xl flex flex-col lg:flex-row items-center justify-between sticky top-0 z-50 shrink-0 gap-10">
                    <div className="flex items-center gap-10 w-full lg:w-auto text-left">
                        <div className="bg-indigo-600 p-6 rounded-[2.25rem] shadow-[0_20px_50px_rgba(79,70,229,0.4)]">
                            <BuildingOfficeIcon className="w-12 h-12 text-white" />
                        </div>
                        <div className="min-w-0">
                            <div className="flex items-center gap-5 mb-3">
                                <h2 className="text-4xl md:text-5xl font-black text-zinc-900 dark:text-white tracking-tighter uppercase leading-none truncate">{listing.title}</h2>
                                {isVerified && (
                                    <div className="flex items-center gap-2 px-4 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full shadow-[0_0_20px_rgba(16,185,129,0.2)] animate-in zoom-in duration-500">
                                        <div className="p-1 bg-emerald-500 rounded-full">
                                            <CheckIcon className="w-3 h-3 text-white" />
                                        </div>
                                        <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest">Verified Dossier</span>
                                    </div>
                                )}
                            </div>
                            <div className="flex items-center gap-4 flex-wrap text-left">
                                <MapPinIcon className="w-6 h-6 text-indigo-600" />
                                <p className="text-[14px] font-black text-zinc-400 dark:text-zinc-500 uppercase tracking-[0.5em]">{listing.location}</p>
                            </div>
                        </div>
                    </div>

                    <nav className="flex bg-zinc-100 dark:bg-zinc-900/80 border border-zinc-200 dark:border-zinc-800 p-2 rounded-3xl shadow-inner overflow-x-auto no-scrollbar" role="tablist">
                        <TabTrigger id="tab-overview" active={activeTab === 'overview'} onClick={() => setActiveTab('overview')} label="Asset Dossier" icon={AdjustmentsHorizontalIcon} />
                        <TabTrigger id="tab-market" active={activeTab === 'market'} onClick={() => setActiveTab('market')} label="Market Intel" icon={ChartBarIcon} />
                        <TabTrigger id="tab-vault" active={activeTab === 'vault'} onClick={() => setActiveTab('vault')} label="Digital Vault" icon={LockClosedIcon} />
                    </nav>

                    <button onClick={onClose} className="p-5 bg-zinc-100 dark:bg-zinc-900/80 text-zinc-900 dark:text-white rounded-3xl border border-zinc-200 dark:border-zinc-800 hover:border-red-500/40 transition-all active:scale-90">
                        <XMarkIcon className="w-8 h-8" />
                    </button>
                </div>

                <div className="flex-1 overflow-hidden">
                    <div className="h-full overflow-y-auto custom-scrollbar bg-white dark:bg-[#030305] bg-grid-pattern relative">
                        {activeTab === 'overview' && (
                            <div className="animate-in fade-in slide-in-from-bottom-10 duration-1000 pb-40">
                                <div className={`h-[450px] md:h-[750px] relative overflow-hidden group/main-viewer bg-slate-950 ${generatedVideoUrl ? 'ring-4 ring-blue-500 animate-pulse' : ''}`}>
                                    {generatedVideoUrl ? (
                                        <div className="w-full h-full relative">
                                            <video src={generatedVideoUrl} className="w-full h-full object-cover" controls autoPlay loop />
                                            <div className="absolute top-12 left-16 px-6 py-3 bg-red-600/90 backdrop-blur-xl border border-red-400/40 rounded-full flex items-center gap-4 shadow-3xl z-40 animate-pulse">
                                                <div className="w-3 h-3 rounded-full bg-white animate-ping"></div>
                                                <span className="text-xs font-black text-white uppercase tracking-widest">Emmanuel AI Live Tour</span>
                                            </div>
                                        </div>
                                    ) : (
                                        <InteractiveImage 
                                            src={images[currentImgIdx]} 
                                            nextImage={() => setCurrentImgIdx((currentImgIdx + 1) % images.length)} 
                                            prevImage={() => setCurrentImgIdx((currentImgIdx - 1 + images.length) % images.length)} 
                                            hasMultiple={images.length > 1}
                                        />
                                    )}

                                    <div className="absolute top-12 right-12 flex flex-col gap-4 z-40">
                                        <Tooltip text="Neural TTS: Hear forensic asset details spoken by Core Kore voice node.">
                                            <button 
                                                onClick={handleTTS}
                                                className={`p-5 backdrop-blur-3xl border border-white/20 text-white rounded-3xl shadow-2xl transition-all active:scale-95 group/tts ${isSpeaking ? 'bg-emerald-600 animate-pulse' : 'bg-white/10 hover:bg-emerald-600'}`}
                                            >
                                                <SpeakerWaveIcon className="w-8 h-8" />
                                            </button>
                                        </Tooltip>
                                        {!generatedVideoUrl && (
                                            <Tooltip text="Perform a deep forensic visual scan for scam risks & stock usage (Gemini Pro).">
                                                <button 
                                                    onClick={handleTruthLensScan}
                                                    disabled={isScanning}
                                                    className="p-5 bg-white/10 hover:bg-indigo-600 backdrop-blur-3xl border border-white/20 text-white rounded-3xl shadow-2xl transition-all active:scale-95 group/scan"
                                                >
                                                    {isScanning ? <ArrowPathIcon className="w-8 h-8 animate-spin" /> : <CameraIcon className="w-8 h-8 group-hover/scan:scale-110 transition-transform" />}
                                                </button>
                                            </Tooltip>
                                        )}
                                    </div>

                                    {!generatedVideoUrl && (
                                        <div className="absolute inset-0 flex flex-col items-center justify-center opacity-0 group-hover/main-viewer:opacity-100 transition-opacity bg-black/40 backdrop-blur-[2px] z-40">
                                            {isGeneratingVideo ? (
                                                <div className="flex flex-col items-center gap-6 animate-in zoom-in duration-500">
                                                    <div className="w-24 h-24 bg-blue-600 rounded-[2.5rem] border border-white/20 flex items-center justify-center shadow-2xl animate-pulse">
                                                        <VideoCameraIcon className="w-12 h-12 text-white" />
                                                    </div>
                                                    <h4 className="text-xl font-black text-white uppercase tracking-widest">{videoLoadingMessages[videoStep]}</h4>
                                                </div>
                                            ) : (
                                                <Tooltip text="Synthesize a cinematic walkthrough with Veo 3.">
                                                    <button 
                                                        onClick={handleLaunchTour}
                                                        className="px-12 py-6 bg-white hover:bg-blue-600 text-black hover:text-white rounded-[2.5rem] font-black uppercase tracking-[0.3em] text-xs shadow-3xl transition-all flex items-center gap-4 group/tour-btn hover:scale-105"
                                                    >
                                                        <PlayIcon className="w-6 h-6 transition-transform group-hover/tour-btn:scale-125" />
                                                        Launch Cinematic Tour (Veo 3)
                                                    </button>
                                                </Tooltip>
                                            )}
                                        </div>
                                    )}

                                    <div className="absolute bottom-12 left-16 z-20">
                                         <div className="bg-white/80 dark:bg-black/70 backdrop-blur-2xl border border-zinc-200 dark:border-white/10 px-12 py-6 rounded-[3rem] shadow-2xl flex items-center gap-12 group/valuation-bar transition-all hover:bg-white/90 dark:hover:bg-black/90">
                                            <div className="border-r border-zinc-200 dark:border-zinc-800 pr-12 text-left">
                                                <span className="text-[11px] font-black text-indigo-600 uppercase tracking-[0.5em] block mb-2">Valuation Node</span>
                                                <div className="flex items-baseline gap-3">
                                                    <span className="text-sm font-black text-zinc-400 uppercase">{listing.currency}</span>
                                                    <span className="text-5xl font-black text-zinc-900 dark:text-white font-mono tracking-tighter">{listing.price.toLocaleString()}</span>
                                                </div>
                                            </div>
                                         </div>
                                    </div>
                                </div>

                                <div className="p-16 md:p-24 space-y-24 text-left">
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                                        <SpecCard label="Asset Class" value={listing.type} icon={BuildingOfficeIcon} />
                                        <SpecCard label="Configuration" value={`${listing.bedrooms} Beds / ${listing.bathrooms} Baths`} icon={CubeIcon} />
                                        <SpecCard label="Floor Area" value={listing.floor_area} icon={Squares2X2Icon} />
                                        <SpecCard label="Year Built" value={listing.year_built} icon={CalendarIcon} />
                                        <SpecCard label="Tenure" value={listing.tenure} icon={ScaleIcon} />
                                        <SpecCard label="Water Source" value={listing.water_source} icon={BeakerIcon} />
                                        <SpecCard label="Power Backup" value={listing.power_backup} icon={BoltIcon} />
                                        <SpecCard label="Availability" value={listing.status} icon={TagIcon} />
                                    </div>

                                    <div className="bg-slate-900/40 p-10 rounded-[3rem] border border-white/5 shadow-inner">
                                        <div className="flex items-center gap-4 mb-6">
                                            <PhotoIcon className="w-6 h-6 text-blue-500" />
                                            <h3 className="text-sm font-black text-white uppercase tracking-widest">Neural Photo Lab</h3>
                                        </div>
                                        <div className="flex gap-4">
                                            <input 
                                                value={editPrompt} 
                                                onChange={e => setEditPrompt(e.target.value)} 
                                                placeholder="e.g. 'Add a retro cinematic filter' or 'Make it evening lighting'..." 
                                                className="flex-1 bg-black border border-white/10 rounded-2xl p-4 text-xs text-white outline-none focus:border-blue-500"
                                            />
                                            <button 
                                                onClick={handlePhotoEdit}
                                                disabled={isEditingPhoto || !editPrompt.trim()}
                                                className="px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all disabled:opacity-50"
                                            >
                                                {isEditingPhoto ? "Synthesizing..." : "Edit Photo"}
                                            </button>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
                                        <div className="lg:col-span-2 space-y-16">
                                            <div className="bg-zinc-50 dark:bg-zinc-900/40 p-16 rounded-[4rem] border border-zinc-100 dark:border-zinc-800 shadow-xl relative overflow-hidden">
                                                <header className="flex flex-col md:flex-row items-center justify-between mb-12 gap-8">
                                                    <div className="flex items-center gap-8 text-left w-full">
                                                        <div className="p-5 bg-purple-600/10 rounded-[1.75rem] border border-purple-500/20 text-purple-600">
                                                            <CommandLineIcon className="w-10 h-10" />
                                                        </div>
                                                        <div>
                                                            <h3 className="text-xl font-black text-zinc-900 dark:text-white uppercase tracking-[0.5em]">Forensic Narrative</h3>
                                                            <p className="text-[11px] text-zinc-400 font-bold uppercase tracking-widest mt-2">Emmanuel AI v4.5 Active</p>
                                                        </div>
                                                    </div>
                                                    <button 
                                                        onClick={handleAIEnhance} 
                                                        disabled={isPolishing} 
                                                        className="px-10 py-5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl transition-all flex items-center gap-4 text-[11px] font-black uppercase tracking-widest shadow-2xl whitespace-nowrap group"
                                                    >
                                                        {isPolishing ? <ArrowPathIcon className="w-5 h-5 animate-spin" /> : <SparklesIcon className="w-5 h-5 group-hover:scale-125 transition-transform" />}
                                                        Neural Synthesis
                                                    </button>
                                                </header>
                                                <div className="text-3xl md:text-4xl leading-snug font-medium italic text-zinc-800 dark:text-zinc-200 text-left mb-10">
                                                    "{enhancedData?.description || listing.description || PLACEHOLDER_TEXT}"
                                                </div>

                                                {/* New Enhanced Data Visualization */}
                                                {enhancedData && (
                                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12 pt-12 border-t border-zinc-200 dark:border-zinc-800">
                                                        <div>
                                                            <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.4em] mb-6 flex items-center gap-3">
                                                                <SparklesIcon className="w-4 h-4" /> Unique Selling Points
                                                            </h4>
                                                            <ul className="space-y-4">
                                                                {enhancedData.unique_selling_points?.map((usp, i) => (
                                                                    <li key={i} className="flex items-start gap-3 text-sm text-zinc-600 dark:text-zinc-400">
                                                                        <CheckBadgeIcon className="w-5 h-5 text-emerald-500 shrink-0" />
                                                                        {usp}
                                                                    </li>
                                                                ))}
                                                            </ul>
                                                        </div>
                                                        <div>
                                                            <h4 className="text-[10px] font-black text-blue-500 uppercase tracking-[0.4em] mb-6 flex items-center gap-3">
                                                                <MagnifyingGlassIcon className="w-4 h-4" /> SEO Keywords
                                                            </h4>
                                                            <div className="flex flex-wrap gap-2">
                                                                {enhancedData.seo_keywords?.map((kw, i) => (
                                                                    <span key={i} className="px-3 py-1.5 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-lg text-xs font-bold uppercase tracking-wide">
                                                                        {kw}
                                                                    </span>
                                                                ))}
                                                            </div>
                                                            {enhancedData.market_context && (
                                                                <div className="mt-8 p-4 bg-amber-500/5 border border-amber-500/10 rounded-2xl">
                                                                    <h4 className="text-[10px] font-black text-amber-500 uppercase tracking-[0.4em] mb-2 flex items-center gap-3">
                                                                        <SignalIcon className="w-4 h-4" /> Market Context
                                                                    </h4>
                                                                    <p className="text-sm text-zinc-600 dark:text-zinc-400 leading-relaxed font-medium">
                                                                        {enhancedData.market_context}
                                                                    </p>
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                )}
                                            </div>

                                            <div className="bg-indigo-600/5 dark:bg-indigo-600/10 border border-indigo-600/10 rounded-[4rem] p-16 space-y-12 animate-in slide-in-from-top-4 duration-700 text-left">
                                                <header className="flex items-center justify-between w-full">
                                                    <div className="flex items-center gap-8">
                                                        <div className="p-5 bg-indigo-600/10 rounded-[1.75rem] border border-indigo-500/20 text-indigo-600">
                                                            <PresentationChartLineIcon className="w-10 h-10" />
                                                        </div>
                                                        <div>
                                                            <h3 className="text-xl font-black text-zinc-900 dark:text-white uppercase tracking-[0.5em]">Strategic Investment Audit</h3>
                                                            <p className="text-[11px] text-zinc-400 font-bold uppercase tracking-widest mt-2">Deep Thinking Mode v4.5</p>
                                                        </div>
                                                    </div>
                                                    <button 
                                                        onClick={handleForensicAudit}
                                                        disabled={isAuditing}
                                                        className="px-8 py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-2xl transition-all active:scale-95 disabled:opacity-50 flex items-center gap-3"
                                                    >
                                                        {isAuditing ? <ArrowPathIcon className="w-4 h-4 animate-spin" /> : <ShieldCheckBtn className="w-4 h-4" />}
                                                        {isAuditing ? "Thinking..." : "Execute Full Audit"}
                                                    </button>
                                                </header>
                                                
                                                {auditReport && (
                                                    <div className="space-y-10 animate-in fade-in duration-1000">
                                                        <div className="p-8 bg-zinc-950 rounded-[2rem] border border-white/5 text-slate-300 italic text-lg leading-relaxed">
                                                            "{auditReport.summary}"
                                                        </div>
                                                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                                            <div className="bg-white dark:bg-zinc-950 p-8 rounded-[2.5rem] border border-zinc-100 dark:border-zinc-800 shadow-xl w-full">
                                                                <p className="text-[9px] font-black text-zinc-500 uppercase tracking-widest mb-3">Est. Annual Yield</p>
                                                                <p className="text-4xl font-black text-emerald-500 font-mono tracking-tighter">{auditReport.rental_yield}</p>
                                                            </div>
                                                            <div className="bg-white dark:bg-zinc-950 p-8 rounded-[2.5rem] border border-zinc-100 dark:border-zinc-800 shadow-xl w-full">
                                                                <p className="text-[9px] font-black text-zinc-500 uppercase tracking-widest mb-3">Appreciation (5Y)</p>
                                                                <p className="text-4xl font-black text-indigo-500 font-mono tracking-tighter">{auditReport.capital_appreciation}</p>
                                                            </div>
                                                            <div className="bg-white dark:bg-zinc-950 p-8 rounded-[2.5rem] border border-zinc-100 dark:border-zinc-800 shadow-xl w-full">
                                                                <p className="text-[9px] font-black text-zinc-500 uppercase tracking-widest mb-3">Asset Risk Score</p>
                                                                <p className={`text-4xl font-black font-mono tracking-tighter ${auditReport.risk_assessment === 'Low' ? 'text-emerald-500' : 'text-amber-500'}`}>{auditReport.risk_assessment}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
