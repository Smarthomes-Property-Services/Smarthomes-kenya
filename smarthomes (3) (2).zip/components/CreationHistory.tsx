/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { UserIcon, CpuChipIcon } from '@heroicons/react/24/solid';

interface Message {
    role: 'user' | 'agent';
    text: string;
}

interface ChatHistoryProps {
  messages: Message[];
}

export const ChatHistory: React.FC<ChatHistoryProps> = ({ messages }) => {
  if (messages.length === 0) return null;

  return (
    <div className="w-full max-w-4xl mx-auto px-4 mb-6 space-y-4">
        {messages.map((msg, idx) => (
            <div key={idx} className={`flex items-start gap-3 ${msg.role === 'agent' ? '' : 'flex-row-reverse'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${msg.role === 'agent' ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30' : 'bg-zinc-800 text-zinc-400'}`}>
                    {msg.role === 'agent' ? <CpuChipIcon className="w-4 h-4" /> : <UserIcon className="w-4 h-4" />}
                </div>
                <div className={`p-3 rounded-2xl max-w-[80%] text-sm leading-relaxed ${
                    msg.role === 'agent' 
                    ? 'bg-zinc-800/40 text-zinc-200 border border-zinc-700/50 rounded-tl-none' 
                    : 'bg-zinc-100 text-black rounded-tr-none'
                }`}>
                    {msg.text}
                </div>
            </div>
        ))}
    </div>
  );
};