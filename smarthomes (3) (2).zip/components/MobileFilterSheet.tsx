
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { 
    XMarkIcon, 
    HomeModernIcon, 
    TagIcon, 
    BanknotesIcon, 
    AdjustmentsHorizontalIcon,
    ChevronDoubleDownIcon,
    SignalIcon,
    CheckIcon,
    ArrowTrendingUpIcon,
    ArrowTrendingDownIcon
} from '@heroicons/react/24/solid';

interface MobileFilterSheetProps {
    isOpen: boolean;
    onClose: () => void;
    filterType: string;
    onTypeChange: (val: string) => void;
    filterStatus: string;
    onStatusChange: (val: string) => void;
    filterBedrooms: number | null;
    onBedroomsChange: (val: number | null) => void;
    filterPriceRange: [number, number];
    onPriceRangeChange: (val: [number, number]) => void;
    resultsCount: number;
}

const PROPERTY_TYPES = ["All", "Apartment", "House", "Mansion", "Office", "Villa", "Land", "Penthouse"];
const STATUS_OPTIONS = ["All", "Available", "Rented", "Under Offer", "Sold"];

export const MobileFilterSheet: React.FC<MobileFilterSheetProps> = ({
    isOpen, onClose, filterType, onTypeChange, filterStatus, onStatusChange, 
    filterBedrooms, onBedroomsChange, filterPriceRange, onPriceRangeChange, resultsCount
}) => {
    if (!isOpen) return null;

    const formatPrice = (val: number) => {
        if (val >= 1000000) return `${(val / 1000000).toFixed(1)}M`;
        if (val >= 1000) return `${(val / 1000).toFixed(0)}K`;
        return val.toString();
    };

    const handleMinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = Number(e.target.value);
        if (val <= filterPriceRange[1]) {
            onPriceRangeChange([val, filterPriceRange[1]]);
        }
    };

    const handleMaxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = Number(e.target.value);
        if (val >= filterPriceRange[0]) {
            onPriceRangeChange([filterPriceRange[0], val]);
        }
    };

    return (
        <div className="fixed inset-0 z-[1000] lg:hidden flex items-end justify-center animate-in fade-in duration-300">
            <div 
                className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
                onClick={onClose}
            />
            
            <div className="w-full bg-slate-950 border-t border-white/10 rounded-t-[3rem] shadow-[0_-20px_60px_rgba(0,0,0,0.8)] relative z-10 max-h-[95vh] flex flex-col animate-in slide-in-from-bottom-20 duration-500">
                {/* Drag Handle & Header */}
                <div className="flex flex-col items-center p-4 shrink-0" onClick={onClose}>
                    <div className="w-12 h-1.5 bg-white/10 rounded-full mb-6" />
                    <div className="flex items-center justify-between w-full px-4">
                        <div className="flex items-center gap-3">
                            <div className="p-2.5 bg-blue-600/10 rounded-xl border border-blue-500/20 text-blue-500">
                                <AdjustmentsHorizontalIcon className="w-5 h-5" />
                            </div>
                            <h3 className="text-xl font-black text-white uppercase tracking-tighter">Forensic Filter</h3>
                        </div>
                        <button onClick={onClose} className="p-3 bg-white/5 text-slate-400 rounded-2xl border border-white/5 active:scale-90 transition-all">
                            <XMarkIcon className="w-6 h-6" />
                        </button>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-8 space-y-12 no-scrollbar">
                    {/* Valuation Node Section (The Enhanced Price Range) */}
                    <section className="space-y-8 bg-white/[0.02] border border-white/5 rounded-[2.5rem] p-6">
                        <div className="flex justify-between items-center">
                            <label className="text-[10px] font-black text-blue-500 uppercase tracking-[0.4em] flex items-center gap-3">
                                <BanknotesIcon className="w-4 h-4" />
                                Valuation Matrix
                            </label>
                            <div className="flex items-center gap-2 px-3 py-1 bg-blue-600/10 border border-blue-500/20 rounded-full">
                                <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest">Spread: {formatPrice(filterPriceRange[1] - filterPriceRange[0])}</span>
                            </div>
                        </div>

                        {/* Dual Slider Cluster */}
                        <div className="space-y-10">
                            {/* Floor Slider */}
                            <div className="space-y-4">
                                <div className="flex justify-between items-end px-2">
                                    <span className="text-[8px] font-black text-slate-600 uppercase tracking-widest flex items-center gap-2">
                                        <ArrowTrendingDownIcon className="w-3 h-3" /> Floor Node
                                    </span>
                                    <span className="text-xl font-mono font-black text-white">
                                        <span className="text-[10px] text-slate-500 mr-1 uppercase">KES</span>
                                        {formatPrice(filterPriceRange[0])}
                                    </span>
                                </div>
                                <input 
                                    type="range" min="0" max="250000000" step="1000000"
                                    value={filterPriceRange[0]}
                                    onChange={handleMinChange}
                                    className="w-full h-3 bg-white/5 rounded-full appearance-none cursor-pointer accent-blue-500 shadow-inner ring-4 ring-slate-950"
                                />
                            </div>

                            {/* Ceiling Slider */}
                            <div className="space-y-4">
                                <div className="flex justify-between items-end px-2">
                                    <span className="text-[8px] font-black text-slate-600 uppercase tracking-widest flex items-center gap-2">
                                        <ArrowTrendingUpIcon className="w-3 h-3" /> Ceiling Node
                                    </span>
                                    <span className="text-xl font-mono font-black text-emerald-500">
                                        <span className="text-[10px] text-slate-500 mr-1 uppercase">KES</span>
                                        {formatPrice(filterPriceRange[1])}
                                    </span>
                                </div>
                                <input 
                                    type="range" min="0" max="250000000" step="1000000"
                                    value={filterPriceRange[1]}
                                    onChange={handleMaxChange}
                                    className="w-full h-3 bg-white/5 rounded-full appearance-none cursor-pointer accent-emerald-500 shadow-inner ring-4 ring-slate-950"
                                />
                            </div>
                        </div>

                        <div className="flex justify-between px-2 text-[7px] font-black text-slate-800 uppercase tracking-[0.3em]">
                            <span>Registry Min: 0</span>
                            <span>Registry Max: 250M+</span>
                        </div>
                    </section>

                    {/* Property Type Grid */}
                    <section className="space-y-6">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] pl-2 flex items-center gap-3">
                            <HomeModernIcon className="w-4 h-4 text-blue-500" />
                            Asset Classification
                        </label>
                        <div className="grid grid-cols-2 gap-3">
                            {PROPERTY_TYPES.map(type => (
                                <button 
                                    key={type}
                                    onClick={() => onTypeChange(type)}
                                    className={`px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all flex items-center justify-between ${
                                        filterType === type 
                                        ? 'bg-blue-600 border-blue-400 text-white shadow-lg' 
                                        : 'bg-white/5 border-white/5 text-slate-400'
                                    }`}
                                >
                                    {type}
                                    {filterType === type && <CheckIcon className="w-3.5 h-3.5" />}
                                </button>
                            ))}
                        </div>
                    </section>

                    {/* Bedrooms - Segmented Control */}
                    <section className="space-y-6">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] pl-2">Bedroom Nodes</label>
                        <div className="flex bg-white/5 p-1.5 rounded-2xl border border-white/5 overflow-x-auto no-scrollbar">
                            {[null, 1, 2, 3, 4].map(num => (
                                <button 
                                    key={String(num)}
                                    onClick={() => onBedroomsChange(num)}
                                    className={`flex-1 min-w-[64px] py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                                        filterBedrooms === num 
                                        ? 'bg-blue-600 text-white shadow-xl' 
                                        : 'text-slate-500'
                                    }`}
                                >
                                    {num === null ? 'All' : num + 'B'}
                                </button>
                            ))}
                        </div>
                    </section>

                    {/* Asset Status */}
                    <section className="space-y-6">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] pl-2 flex items-center gap-3">
                            <TagIcon className="w-4 h-4 text-amber-500" />
                            Registry Status
                        </label>
                        <div className="flex flex-wrap gap-2">
                            {STATUS_OPTIONS.map(status => (
                                <button 
                                    key={status}
                                    onClick={() => onStatusChange(status)}
                                    className={`px-5 py-3 rounded-full text-[9px] font-black uppercase tracking-widest border transition-all ${
                                        filterStatus === status 
                                        ? 'bg-amber-600 border-amber-400 text-white shadow-lg' 
                                        : 'bg-white/5 border-white/5 text-slate-500'
                                    }`}
                                >
                                    {status}
                                </button>
                            ))}
                        </div>
                    </section>
                </div>

                {/* Footer Action */}
                <div className="p-8 border-t border-white/5 bg-slate-900/50 backdrop-blur-2xl shrink-0">
                    <button 
                        onClick={onClose}
                        className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black uppercase tracking-[0.3em] text-xs py-6 rounded-3xl shadow-[0_20px_50px_rgba(37,99,235,0.4)] transition-all active:scale-95 flex items-center justify-center gap-4"
                    >
                        <SignalIcon className="w-5 h-5 animate-pulse" />
                        Apply & Synchronize ({resultsCount} Nodes)
                    </button>
                </div>
            </div>
        </div>
    );
};
