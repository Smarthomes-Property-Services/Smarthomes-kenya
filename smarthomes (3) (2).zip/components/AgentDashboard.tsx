
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
    BriefcaseIcon, 
    ChartBarIcon, 
    CpuChipIcon, 
    CheckIcon, 
    PaperAirplaneIcon, 
    UserIcon, 
    SignalIcon, 
    XMarkIcon, 
    CalendarIcon,
    RectangleGroupIcon, 
    ShieldExclamationIcon, 
    ClipboardDocumentCheckIcon,
    BellAlertIcon,
    ArrowTrendingUpIcon, 
    BanknotesIcon, 
    DocumentTextIcon,
    WrenchIcon,
    ScaleIcon,
    ShieldCheckIcon,
    InformationCircleIcon,
    ExclamationTriangleIcon,
    UserGroupIcon,
    ChevronDownIcon,
    MapPinIcon,
    ArrowUpRightIcon,
    InboxStackIcon,
    BoltIcon,
    SparklesIcon,
    CommandLineIcon,
    SquaresPlusIcon,
    ChatBubbleLeftEllipsisIcon,
    PhoneIcon,
    EnvelopeIcon,
    MagnifyingGlassIcon,
    FunnelIcon,
    ArrowPathIcon,
    ClockIcon,
    BuildingOfficeIcon,
    UserCircleIcon,
    ChatBubbleOvalLeftIcon,
    FingerPrintIcon,
    KeyIcon,
    IdentificationIcon,
    FunnelIcon as FunnelSolid,
    PresentationChartLineIcon
} from '@heroicons/react/24/solid';
import { PropertyListing, AIAgent, getAvailableAgents, CommunicationLog, performInvestmentAudit, InvestmentAuditReport } from '../services/gemini.ts';

// --- Types ---
export interface Task {
    id: string;
    title: string;
    dueDate: string;
    priority: 'Low' | 'Medium' | 'High';
    isCompleted: boolean;
    propertyContext?: string;
}

export interface ClientNode {
    id: string;
    name: string;
    budget: string;
    targetProperty: string;
    trustScore: number;
    kycStatus: 'Verified' | 'Pending' | 'Flagged';
    lastSync: string;
    source: string;
}

export interface AgentDashboardProps {
    allMessages: Record<string, any[]>;
    chatThreads: any[];
    onSendMessage: (threadId: string, text: string, agent?: string) => Promise<void> | void;
    listings?: PropertyListing[];
    initialMode?: 'agent' | 'landlord';
    onGenerateVideo?: (property: PropertyListing) => void;
}

const agentIcons: Record<string, any> = {
    emmanuel: ChartBarIcon,
    prashanth: ShieldCheckIcon,
    easylease: DocumentTextIcon,
    easyfix: WrenchIcon,
    thanga: ScaleIcon
};

const QUICK_REPLIES = [
    { category: "Availability", text: "Node is active and available." },
    { category: "Pricing", text: "Valuation node matches listed price." },
    { category: "Viewing", text: "Schedule viewing protocol for tomorrow." },
    { category: "Verification", text: "Dossier verification check complete." },
    { category: "Lease", text: "Lease contract node ready for handshake." }
];

const StatNode = ({ label, value, subtext, color, icon: Icon }: any) => (
    <div className="bg-slate-950 border border-white/5 p-10 rounded-[3rem] text-left group hover:border-blue-500/20 transition-all shadow-3xl relative overflow-hidden flex flex-col justify-between h-72">
        <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity"><Icon className="w-32 h-32" /></div>
        <div className="flex items-center justify-between relative z-10">
            <p className="text-[11px] font-black text-slate-600 uppercase tracking-[0.4em]">{label}</p>
            <div className={`p-4 rounded-2xl bg-slate-900 border border-white/5 ${color} shadow-inner group-hover:scale-110 transition-transform`}><Icon className="w-6 h-6" /></div>
        </div>
        <div className="relative z-10">
            <h6 className={`text-5xl font-black ${color} tracking-tighter mb-4 uppercase leading-none`}>{value}</h6>
            <div className="flex items-center gap-3">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></div>
                <p className="text-[11px] font-bold text-slate-700 uppercase tracking-[0.3em]">{subtext}</p>
            </div>
        </div>
    </div>
);

const NavRailBtn = ({ active, onClick, icon: Icon, label }: any) => (
    <button onClick={onClick} className="flex flex-col items-center gap-4 group outline-none relative">
        {active && <div className="absolute -left-12 top-1/2 -translate-y-1/2 w-2 h-16 bg-blue-500 rounded-full blur-sm animate-pulse"></div>}
        <div className={`p-6 rounded-[2rem] border transition-all duration-700 ${active ? 'bg-blue-600 border-blue-400 text-white shadow-[0_20px_60px_rgba(37,99,235,0.4)] scale-110' : 'bg-slate-900 border-white/5 text-slate-600 hover:text-white hover:bg-slate-800'}`}>
            <Icon className={`w-8 h-8 transition-all ${active ? 'scale-110' : 'group-hover:scale-110'}`} />
        </div>
        <span className={`text-[10px] font-black uppercase tracking-[0.5em] transition-all duration-700 ${active ? 'text-blue-500' : 'text-slate-800 group-hover:text-slate-500'}`}>{label}</span>
    </button>
);

export const AgentDashboard: React.FC<AgentDashboardProps> = ({ 
    allMessages, onSendMessage, listings = [], initialMode = 'agent'
}) => {
    const [mode, setMode] = useState<'agent' | 'landlord'>(initialMode);
    const [activeTab, setActiveTab] = useState<'management' | 'agentic' | 'stats' | 'communication'>('management');
    const [mgmtTab, setMgmtTab] = useState<'portfolio' | 'tasks'>('portfolio');
    const [commView, setCommView] = useState<'inquiries' | 'registry'>('inquiries');
    const [activeAgentId, setActiveAgentId] = useState<string>('emmanuel');
    const [isThinking, setIsThinking] = useState(false);
    const [availableAgents, setAvailableAgents] = useState<AIAgent[]>([]);
    
    // Communication & Sync State
    const [commFilter, setCommFilter] = useState('');
    const [propertyFilter, setPropertyFilter] = useState('All');
    const [statusFilter, setStatusFilter] = useState<'All' | 'High Priority' | 'Pending'>('All');
    const [typeFilter, setTypeFilter] = useState<'All' | 'WhatsApp' | 'Email' | 'Portal'>('All');
    const [selectedLog, setSelectedLog] = useState<CommunicationLog | null>(null);
    const [isSendingReply, setIsSendingReply] = useState(false);
    const [manualReply, setManualReply] = useState('');
    
    // Registry Sync States
    const [isSyncingRegistry, setIsSyncingRegistry] = useState(false);
    const [syncProgress, setSyncProgress] = useState(0);
    const [syncLogs, setSyncLogs] = useState<string[]>([]);
    const [clientRegistry, setClientRegistry] = useState<ClientNode[]>([]);

    // Strategic ROI Audit State
    const [isAuditing, setIsAuditing] = useState(false);
    const [lastAuditReport, setLastAuditReport] = useState<InvestmentAuditReport | null>(null);

    const mockCommLogs: CommunicationLog[] = [
        { id: 'log-1', clientId: 'usr-44', clientName: 'Kamau Otieno', propertyId: 'nbo-01', propertyName: 'GTC Executive Residence', lastMessage: 'Is the 3D tour link for node #01 available?', timestamp: '2024-05-20', type: 'WhatsApp', status: 'High Priority' },
        { id: 'log-2', clientId: 'usr-89', clientName: 'Sarah Jenkins', propertyId: 'nbo-02', propertyName: 'Runda Evergreen Townhouse', lastMessage: 'Verification protocol for borehole logs required.', timestamp: '2024-05-19', type: 'Email', status: 'Pending' },
        { id: 'log-3', clientId: 'usr-12', clientName: 'Ahmed Mohammed', propertyId: 'nbo-01', propertyName: 'GTC Executive Residence', lastMessage: 'Requested ROI drift summary for Westlands Metro.', timestamp: '2024-05-18', type: 'Portal', status: 'Synced' },
        { id: 'log-4', clientId: 'usr-55', clientName: 'Jane Doe', propertyId: 'nbo-02', propertyName: 'Runda Evergreen Townhouse', lastMessage: 'Are the utilities nodes integrated in the KES 85M valuation?', timestamp: '2024-05-20', type: 'WhatsApp', status: 'High Priority' },
    ];

    useEffect(() => {
        getAvailableAgents().then(setAvailableAgents);
    }, []);

    const [tasks, setTasks] = useState<Task[]>([
        { id: '1', title: 'Verify tenure protocol for Lavington Node #44', dueDate: '2024-06-12', priority: 'High', isCompleted: false },
        { id: '2', title: 'Broadcast liquidity alert: Tatu City Drifts', dueDate: '2024-06-13', priority: 'Medium', isCompleted: false },
        { id: '3', title: 'Audit borehole log veracity: Karen Estate', dueDate: '2024-06-14', priority: 'High', isCompleted: false },
    ]);

    const TABS = [
        { id: 'management', label: 'Nodes', icon: InboxStackIcon },
        { id: 'communication', label: 'Comm Hub', icon: ChatBubbleLeftEllipsisIcon },
        { id: 'agentic', label: 'Command', icon: CpuChipIcon },
        { id: 'stats', label: 'Pulse', icon: ChartBarIcon }
    ] as const;

    const filteredLogs = useMemo(() => {
        return mockCommLogs.filter(log => {
            const matchesSearch = log.clientName.toLowerCase().includes(commFilter.toLowerCase()) ||
                                 log.propertyName.toLowerCase().includes(commFilter.toLowerCase()) ||
                                 log.lastMessage.toLowerCase().includes(commFilter.toLowerCase());
            const matchesProperty = propertyFilter === 'All' || log.propertyName === propertyFilter;
            const matchesStatus = statusFilter === 'All' || log.status === statusFilter;
            const matchesType = typeFilter === 'All' || log.type === typeFilter;

            return matchesSearch && matchesProperty && matchesStatus && matchesType;
        });
    }, [commFilter, propertyFilter, statusFilter, typeFilter]);

    const handleSyncRegistry = async () => {
        setIsSyncingRegistry(true);
        setSyncProgress(0);
        setSyncLogs([]);
        
        const steps = [
            "Initializing secure neural handshake...",
            "Fetching encrypted identity nodes...",
            "Scanning regional liquidity drifts...",
            "Verifying KYC Integrity Matrix...",
            "Establishing Registry Parity...",
            "Handshake Successful. Syncing Client Dossiers."
        ];

        for (let i = 0; i < steps.length; i++) {
            await new Promise(r => setTimeout(r, 400 + Math.random() * 600));
            setSyncLogs(prev => [...prev, `[PROTO] ${steps[i]}`]);
            setSyncProgress(((i + 1) / steps.length) * 100);
        }

        const syncedData: ClientNode[] = [
            { id: 'usr-44', name: 'Kamau Otieno', budget: 'KES 35M', targetProperty: 'GTC Executive Residence', trustScore: 98, kycStatus: 'Verified', lastSync: 'Now', source: 'WhatsApp Relay' },
            { id: 'usr-89', name: 'Sarah Jenkins', budget: 'KES 95M', targetProperty: 'Runda Evergreen Townhouse', trustScore: 100, kycStatus: 'Verified', lastSync: 'Now', source: 'Portal Direct' },
            { id: 'usr-12', name: 'Ahmed Mohammed', budget: 'KES 28.5M', targetProperty: 'GTC Executive Residence', trustScore: 92, kycStatus: 'Verified', lastSync: 'Now', source: 'Email Node' },
            { id: 'usr-55', name: 'Jane Doe', budget: 'KES 85M', targetProperty: 'Runda Evergreen Townhouse', trustScore: 84, kycStatus: 'Pending', lastSync: 'Now', source: 'Referral Alpha' }
        ];

        setClientRegistry(syncedData);
        setIsSyncingRegistry(false);
        setCommView('registry');
    };

    const handleStrategicROIAnalysis = async () => {
        if (!selectedLog || isAuditing) return;
        setIsAuditing(true);
        setLastAuditReport(null);
        try {
            const location = selectedLog.propertyName.toLowerCase().includes('runda') ? 'Runda, Nairobi' : 'Westlands, Nairobi';
            const goal = `Analyze ROI potential for ${selectedLog.clientName}'s interest in ${selectedLog.propertyName}. Thesis: Capital appreciation vs current market drifts.`;
            const report = await performInvestmentAudit(location, goal);
            setLastAuditReport(report);
            
            // Integrate into chat
            const threadId = `client-${selectedLog.clientId}`;
            await onSendMessage(threadId, `Emmanuel AI Strategic Report Node Established. Strategic Recommendation: "${report.strategic_recommendation}". ROI Potential: ${report.roi_potential}. Risk node: ${report.risk_assessment}.`);
        } catch (err) {
            console.error(err);
        } finally {
            setIsAuditing(false);
        }
    };

    const handleQuickReply = async (reply: string) => {
        if (!selectedLog) return;
        setIsSendingReply(true);
        
        const threadId = `client-${selectedLog.clientId}`;
        await onSendMessage(threadId, reply);
        
        await new Promise(r => setTimeout(r, 1500));
        
        setIsSendingReply(false);
        setManualReply('');
    };

    const handleManualSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!manualReply.trim()) return;
        handleQuickReply(manualReply);
    };

    return (
        <div className="flex h-full w-full bg-[#020617] rounded-[4rem] overflow-hidden border border-white/10 shadow-[0_0_150px_rgba(0,0,0,1)] text-left relative group/dashboard ring-1 ring-white/5">
            <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none"></div>

            {/* Sync Overlay */}
            {isSyncingRegistry && (
                <div className="absolute inset-0 z-[100] bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-12">
                    <div className="w-full max-w-2xl space-y-10">
                        <div className="flex flex-col items-center gap-6">
                            <div className="relative">
                                <div className="absolute inset-0 bg-blue-500/20 blur-3xl animate-pulse rounded-full"></div>
                                <div className="relative w-24 h-24 bg-slate-900 border border-blue-500/30 rounded-[2rem] flex items-center justify-center text-blue-500">
                                    <ArrowPathIcon className="w-12 h-12 animate-spin" />
                                </div>
                            </div>
                            <h3 className="text-2xl font-black text-white uppercase tracking-[0.4em] animate-pulse">Neural Registry Sync</h3>
                        </div>
                        
                        <div className="space-y-4">
                            <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden border border-white/5">
                                <div 
                                    className="h-full bg-blue-600 transition-all duration-500 shadow-[0_0_15px_rgba(59,130,246,0.8)]" 
                                    style={{ width: `${syncProgress}%` }}
                                ></div>
                            </div>
                            <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase tracking-widest">
                                <span>Parity Handshake</span>
                                <span>{Math.round(syncProgress)}%</span>
                            </div>
                        </div>

                        <div className="bg-black/60 border border-white/5 rounded-3xl p-8 h-48 overflow-y-auto font-mono text-[11px] space-y-2 no-scrollbar">
                            {syncLogs.map((log, i) => (
                                <div key={i} className="text-blue-400 opacity-80 animate-in slide-in-from-bottom-1">{log}</div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* Sidebar Rail */}
            <div className="w-28 bg-slate-950 border-r border-white/5 flex flex-col items-center py-16 gap-16 shrink-0 z-10 hidden lg:flex">
                {TABS.map(tab => (
                    <NavRailBtn 
                        key={tab.id}
                        active={activeTab === tab.id} 
                        onClick={() => setActiveTab(tab.id)} 
                        icon={tab.icon} 
                        label={tab.label} 
                    />
                ))}
                <div className="mt-auto flex flex-col items-center gap-8 pb-4">
                     <button className="w-14 h-14 rounded-2xl bg-slate-900 border border-white/5 flex items-center justify-center text-slate-600 hover:text-white transition-all active:scale-90"><BellAlertIcon className="w-7 h-7" /></button>
                     <div className="w-14 h-14 rounded-3xl bg-blue-600 flex items-center justify-center text-white font-black text-sm border-4 border-slate-950 shadow-2xl cursor-pointer hover:rotate-6 transition-all ring-1 ring-white/20">A</div>
                </div>
            </div>

            {/* Workspace Content */}
            <div className="flex-1 flex flex-col overflow-hidden relative z-10 bg-[#010309] pb-24 lg:pb-0">
                <div className="h-28 px-8 md:px-16 border-b border-white/5 bg-slate-950/40 backdrop-blur-3xl flex items-center justify-between shrink-0">
                    <div className="flex items-center gap-10 md:gap-16 h-full">
                        <div className="flex items-center gap-6 md:gap-10">
                            <div className="p-4 md:p-5 bg-blue-600/10 rounded-[1.5rem] md:rounded-[1.75rem] border border-blue-500/20 text-blue-500 shadow-inner group-hover/dashboard:rotate-3 transition-transform duration-1000">
                                <CommandLineIcon className="w-7 h-7 md:w-9 md:h-9" />
                            </div>
                            <div className="text-left">
                                <h2 className="text-xl md:text-3xl font-black text-white uppercase tracking-tighter leading-none mb-2">
                                    {activeTab === 'communication' ? 'Forensic Comm Hub' : 'Forensic Workspace'}
                                </h2>
                                <div className="flex items-center gap-3">
                                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                                    <span className="text-[9px] md:text-[10px] font-black text-emerald-500 uppercase tracking-[0.4em]">Emmanuel Node: SYNCHRONIZED</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
                    {/* Main Work Area */}
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-6 md:p-16">
                        {activeTab === 'management' && (
                            <div className="space-y-16 animate-in slide-in-from-right-8 duration-700">
                                <div className="flex items-center gap-12 border-b border-white/5 pb-10">
                                    <button onClick={() => setMgmtTab('portfolio')} className={`flex items-center gap-4 text-[13px] font-black uppercase tracking-[0.4em] transition-all relative ${mgmtTab === 'portfolio' ? 'text-white' : 'text-slate-600 hover:text-slate-400'}`}>
                                        <RectangleGroupIcon className="w-6 h-6" /> Portfolio Cluster
                                        {mgmtTab === 'portfolio' && <div className="absolute -bottom-10 left-0 right-0 h-1 bg-blue-600 rounded-full shadow-[0_0_15px_rgba(59,130,246,0.8)]"></div>}
                                    </button>
                                    <button onClick={() => setMgmtTab('tasks')} className={`flex items-center gap-4 text-[13px] font-black uppercase tracking-[0.4em] transition-all relative ${mgmtTab === 'tasks' ? 'text-white' : 'text-slate-600 hover:text-slate-400'}`}>
                                        <ClipboardDocumentCheckIcon className="w-6 h-6" /> Forensic Queue
                                        {mgmtTab === 'tasks' && <div className="absolute -bottom-10 left-0 right-0 h-1 bg-blue-600 rounded-full shadow-[0_0_15px_rgba(59,130,246,0.8)]"></div>}
                                    </button>
                                </div>

                                {mgmtTab === 'portfolio' ? (
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                                        {listings.map(item => (
                                            <div key={item.id} className="bg-slate-900/50 border border-white/5 p-8 rounded-[3.5rem] group hover:border-blue-500/40 transition-all text-left shadow-2xl flex flex-col">
                                                <div className="h-56 rounded-[2.5rem] overflow-hidden mb-10 relative shrink-0 shadow-3xl">
                                                    <img src={item.image_url} className="w-full h-full object-cover transition-transform duration-[6000ms] group-hover:scale-110" />
                                                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80"></div>
                                                    <div className="absolute top-6 right-6 px-4 py-2 bg-slate-950/80 backdrop-blur-xl rounded-2xl border border-white/10 text-[10px] font-black text-emerald-400 font-mono tracking-tighter">
                                                        ROI: {(item.vibe_score * 0.8).toFixed(1)}%
                                                    </div>
                                                </div>
                                                <div className="mb-6 space-y-4">
                                                    <h4 className="text-white font-black text-2xl uppercase tracking-tighter truncate leading-none mb-2">{item.title}</h4>
                                                    <p className="text-slate-600 text-[11px] font-black uppercase tracking-widest flex items-center gap-2"><MapPinIcon className="w-4 h-4 text-blue-500" /> {item.location}</p>
                                                    <div className="pt-6 border-t border-white/5 flex items-end justify-between">
                                                        <div className="flex flex-col gap-1">
                                                            <span className="text-[9px] text-slate-700 font-black uppercase tracking-widest">Valuation node</span>
                                                            <span className="text-2xl font-mono font-black text-white">{item.currency} {(item.price/1000000).toFixed(1)}M</span>
                                                        </div>
                                                        <button className="p-4 bg-white text-slate-950 rounded-2xl transition-all hover:bg-blue-600 hover:text-white shadow-xl active:scale-90"><ArrowUpRightIcon className="w-6 h-6" /></button>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="max-w-5xl space-y-8 pb-32">
                                        {tasks.map(task => (
                                            <div key={task.id} className={`flex items-center justify-between p-10 rounded-[3.5rem] border transition-all duration-700 shadow-2xl relative overflow-hidden group ${task.isCompleted ? 'bg-slate-950 opacity-40 grayscale border-white/5' : 'bg-slate-900 border-white/10 hover:border-blue-500/40'}`}>
                                                {!task.isCompleted && <div className="absolute left-0 top-0 bottom-0 w-2 bg-blue-600 group-hover:shadow-[0_0_15px_rgba(59,130,246,0.6)] transition-all"></div>}
                                                <div className="flex items-center gap-12">
                                                    <button onClick={() => setTasks(tasks.map(t => t.id === task.id ? {...t, isCompleted: !t.isCompleted} : t))} className={`w-14 h-14 rounded-2xl border flex items-center justify-center transition-all ${task.isCompleted ? 'bg-emerald-600 border-emerald-500 text-white' : 'bg-slate-950 border-white/5 text-slate-700 hover:text-blue-500 hover:border-blue-500/40 shadow-inner'}`}>
                                                        <CheckIcon className="w-8 h-8" />
                                                    </button>
                                                    <div className="text-left">
                                                        <h5 className={`text-2xl font-black uppercase tracking-tighter ${task.isCompleted ? 'line-through text-slate-800' : 'text-white'}`}>{task.title}</h5>
                                                        <div className="flex items-center gap-8 mt-3">
                                                            <span className="text-[11px] font-black text-slate-600 uppercase tracking-widest flex items-center gap-3"><CalendarIcon className="w-4 h-4 text-blue-500/50" /> Protocol Deadline: {task.dueDate}</span>
                                                            <span className={`text-[10px] font-black px-4 py-1 rounded-xl border ${task.priority === 'High' ? 'bg-rose-600/10 border-rose-500/30 text-rose-500' : 'bg-blue-600/10 border-blue-500/30 text-blue-500'} uppercase tracking-widest`}>{task.priority} Priority</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        )}

                        {activeTab === 'communication' && (
                            <div className="space-y-8 animate-in slide-in-from-bottom-8 duration-700 h-full flex flex-col">
                                {/* Forensic Workspace Dashboard Summary */}
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 shrink-0">
                                    <div className="bg-slate-950/60 border border-white/5 p-6 rounded-[2.5rem] flex items-center gap-5 shadow-xl">
                                        <div className="p-3 bg-rose-600/10 border border-rose-500/20 text-rose-500 rounded-xl">
                                            <BellAlertIcon className="w-6 h-6 animate-pulse" />
                                        </div>
                                        <div className="text-left">
                                            <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest">High Priority Nodes</p>
                                            <p className="text-2xl font-black text-white leading-none">{mockCommLogs.filter(l => l.status === 'High Priority').length} Critical</p>
                                        </div>
                                    </div>
                                    <div className="bg-slate-950/60 border border-white/5 p-6 rounded-[2.5rem] flex items-center gap-5 shadow-xl">
                                        <div className="p-3 bg-emerald-600/10 border border-emerald-500/20 text-emerald-500 rounded-xl">
                                            <ChatBubbleOvalLeftIcon className="w-6 h-6" />
                                        </div>
                                        <div className="text-left">
                                            <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest">Active Transmissions</p>
                                            <p className="text-2xl font-black text-white leading-none">{mockCommLogs.length} Active</p>
                                        </div>
                                    </div>
                                    <div className="bg-slate-950/60 border border-white/5 p-6 rounded-[2.5rem] flex items-center gap-5 shadow-xl">
                                        <div className="p-3 bg-blue-600/10 border border-blue-500/20 text-blue-500 rounded-xl">
                                            <UserGroupIcon className="w-6 h-6" />
                                        </div>
                                        <div className="text-left">
                                            <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest">Verified Handshakes</p>
                                            <p className="text-2xl font-black text-white leading-none">12.8k Total</p>
                                        </div>
                                    </div>
                                </div>

                                {/* Forensic Search & Filter Node Cluster */}
                                <div className="bg-slate-950/80 p-8 rounded-[3.5rem] border border-white/10 shadow-3xl space-y-8 relative z-20 overflow-hidden">
                                    <div className="absolute inset-0 bg-blue-600/[0.02] pointer-events-none"></div>
                                    
                                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8 relative z-10">
                                        <div className="flex bg-black p-1.5 rounded-2xl border border-white/10 shadow-inner shrink-0">
                                            <button 
                                                onClick={() => setCommView('inquiries')} 
                                                className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-3 ${commView === 'inquiries' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-600 hover:text-slate-400'}`}
                                            >
                                                <InboxStackIcon className="w-4 h-4" /> Live Inquiries
                                            </button>
                                            <button 
                                                onClick={() => setCommView('registry')} 
                                                className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-3 ${commView === 'registry' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-600 hover:text-slate-400'}`}
                                            >
                                                <FingerPrintIcon className="w-4 h-4" /> Vetted Registry
                                            </button>
                                        </div>

                                        <div className="flex-1 relative group">
                                            <MagnifyingGlassIcon className={`absolute left-6 top-1/2 -translate-y-1/2 w-6 h-6 transition-colors ${commFilter ? 'text-blue-500' : 'text-slate-700'}`} />
                                            <input 
                                                value={commFilter}
                                                onChange={e => setCommFilter(e.target.value)}
                                                placeholder="Initialize Forensic Scan: Search Client, Property or Transmission content..." 
                                                className="w-full bg-black border border-white/10 rounded-[1.75rem] py-5 pl-16 pr-8 text-sm text-white focus:border-blue-500 outline-none transition-all shadow-inner placeholder:text-slate-800 font-medium" 
                                            />
                                            {commFilter && (
                                                <button onClick={() => setCommFilter('')} className="absolute right-6 top-1/2 -translate-y-1/2 p-1.5 bg-white/5 hover:bg-white/10 rounded-lg text-slate-500">
                                                    <XMarkIcon className="w-4 h-4" />
                                                </button>
                                            )}
                                        </div>
                                        
                                        <button 
                                            onClick={handleSyncRegistry}
                                            className="px-10 py-5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-[1.75rem] text-[11px] font-black uppercase tracking-[0.2em] shadow-[0_15px_40px_rgba(79,70,229,0.4)] flex items-center gap-4 transition-all active:scale-95 border border-indigo-400/30 shrink-0"
                                        >
                                            <ArrowPathIcon className="w-5 h-5" />
                                            Registry Sync
                                        </button>
                                    </div>

                                    {/* Intelligence Filter Chips */}
                                    <div className="flex flex-wrap items-center gap-4 border-t border-white/5 pt-6 relative z-10">
                                        <div className="flex items-center gap-3 mr-4">
                                            <FunnelSolid className="w-4 h-4 text-slate-700" />
                                            <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Forensic Drifts:</span>
                                        </div>
                                        
                                        <FilterChip active={statusFilter === 'High Priority'} onClick={() => setStatusFilter(statusFilter === 'High Priority' ? 'All' : 'High Priority')} label="Priority Node" count={mockCommLogs.filter(l => l.status === 'High Priority').length} color="rose" />
                                        <FilterChip active={statusFilter === 'Pending'} onClick={() => setStatusFilter(statusFilter === 'Pending' ? 'All' : 'Pending')} label="Pending Handshake" count={mockCommLogs.filter(l => l.status === 'Pending').length} color="amber" />
                                        <div className="w-px h-6 bg-white/10 mx-2"></div>
                                        <FilterChip active={typeFilter === 'WhatsApp'} onClick={() => setTypeFilter(typeFilter === 'WhatsApp' ? 'All' : 'WhatsApp')} label="WhatsApp Relay" icon={ChatBubbleLeftEllipsisIcon} color="emerald" />
                                        <FilterChip active={typeFilter === 'Email'} onClick={() => setTypeFilter(typeFilter === 'Email' ? 'All' : 'Email')} label="Email Node" icon={EnvelopeIcon} color="blue" />
                                        
                                        <div className="ml-auto">
                                            <div className="flex items-center gap-3 px-5 py-2 bg-slate-900 border border-white/5 rounded-xl">
                                                <SignalIcon className="w-4 h-4 text-emerald-500 animate-pulse" />
                                                <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Matched: {filteredLogs.length} Nodes</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {commView === 'inquiries' ? (
                                    <div className="grid grid-cols-1 gap-6 overflow-y-auto custom-scrollbar flex-1 pb-20">
                                        {filteredLogs.length > 0 ? filteredLogs.map(log => (
                                            <div 
                                                key={log.id} 
                                                onClick={() => setSelectedLog(log)}
                                                className={`flex flex-col lg:flex-row lg:items-center justify-between p-10 rounded-[3.5rem] border transition-all duration-700 cursor-pointer group relative overflow-hidden ${selectedLog?.id === log.id ? 'bg-blue-600/15 border-blue-500 shadow-[0_20px_70px_rgba(37,99,235,0.2)] scale-[1.01]' : 'bg-slate-900/40 border-white/5 hover:border-blue-500/30 shadow-2xl'}`}
                                            >
                                                {/* Visual Pulse Connection Line */}
                                                {selectedLog?.id === log.id && <div className="absolute left-0 top-0 bottom-0 w-2 bg-blue-600 group-hover:shadow-[0_0_20px_rgba(59,130,246,0.8)] transition-all"></div>}
                                                
                                                <div className="flex items-start lg:items-center gap-10">
                                                    <div className={`p-6 rounded-[2rem] bg-black border border-white/10 shadow-inner group-hover:scale-110 group-hover:rotate-3 transition-all duration-700 ${log.type === 'WhatsApp' ? 'text-emerald-500 shadow-[inset_0_0_15px_rgba(16,185,129,0.1)]' : log.type === 'Email' ? 'text-blue-400 shadow-[inset_0_0_15px_rgba(59,130,246,0.1)]' : 'text-amber-500 shadow-[inset_0_0_15px_rgba(245,158,11,0.1)]'}`}>
                                                        {log.type === 'WhatsApp' ? <ChatBubbleLeftEllipsisIcon className="w-8 h-8" /> : log.type === 'Email' ? <EnvelopeIcon className="w-8 h-8" /> : <PhoneIcon className="w-8 h-8" />}
                                                    </div>
                                                    <div className="text-left space-y-3">
                                                        <div className="flex items-center gap-6">
                                                            <h5 className="text-2xl font-black text-white uppercase tracking-tighter group-hover:text-blue-500 transition-colors">{log.clientName}</h5>
                                                            <div className="flex items-center gap-2">
                                                                <span className={`text-[9px] font-black px-4 py-1 rounded-xl border ${log.status === 'High Priority' ? 'bg-rose-500/20 border-rose-500 text-rose-500 animate-pulse' : 'bg-emerald-500/20 border-emerald-500 text-emerald-500'} uppercase tracking-widest`}>{log.status}</span>
                                                                <span className="text-[8px] font-black text-slate-800 uppercase tracking-[0.2em] bg-slate-950 px-2 py-1 rounded-lg border border-white/5">#ID-{log.id.split('-')[1]}</span>
                                                            </div>
                                                        </div>
                                                        <div className="flex items-center gap-4">
                                                            <BuildingOfficeIcon className="w-4 h-4 text-blue-500/60" />
                                                            <p className="text-[11px] font-black text-blue-500 uppercase tracking-[0.2em]">{log.propertyName}</p>
                                                        </div>
                                                        <div className="relative">
                                                            <p className="text-base text-slate-400 font-medium italic line-clamp-1 group-hover:text-slate-200 transition-colors">"{log.lastMessage}"</p>
                                                            {commFilter && log.lastMessage.toLowerCase().includes(commFilter.toLowerCase()) && (
                                                                <div className="absolute -left-2 top-0 bottom-0 w-1 bg-blue-500 rounded-full animate-pulse"></div>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="mt-8 lg:mt-0 flex items-center justify-between lg:justify-end gap-16 border-t lg:border-t-0 border-white/5 pt-8 lg:pt-0">
                                                    <div className="text-left lg:text-right space-y-1">
                                                        <p className="text-[9px] font-black text-slate-700 uppercase tracking-[0.3em]">Synapse Transmission</p>
                                                        <div className="flex items-center lg:justify-end gap-3">
                                                            <ClockIcon className="w-3.5 h-3.5 text-slate-800" />
                                                            <p className="text-sm font-mono font-bold text-white uppercase">{log.timestamp}</p>
                                                        </div>
                                                    </div>
                                                    <button className="p-5 bg-white/5 rounded-[1.75rem] border border-white/10 text-slate-500 hover:text-blue-500 hover:border-blue-500/40 hover:bg-blue-600/10 transition-all active:scale-90 shadow-2xl">
                                                        <ArrowUpRightIcon className="w-7 h-7 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                                                    </button>
                                                </div>
                                            </div>
                                        )) : (
                                            <div className="flex flex-col items-center justify-center py-48 text-center animate-in zoom-in duration-700">
                                                <div className="relative mb-12">
                                                    <div className="absolute inset-0 bg-blue-500/10 blur-[100px] rounded-full animate-pulse"></div>
                                                    <ExclamationTriangleIcon className="w-32 h-32 text-slate-900 border border-white/5 rounded-full p-8 shadow-inner relative z-10" />
                                                </div>
                                                <h4 className="text-3xl font-black text-white uppercase tracking-tighter mb-4">Forensic Registry Miss</h4>
                                                <p className="text-sm font-medium uppercase tracking-[0.3em] text-slate-700 max-w-sm mx-auto leading-relaxed">"NO PARITY DETECTED FOR CURRENT SCAN PARAMETERS."</p>
                                                <button 
                                                    onClick={() => { setCommFilter(''); setStatusFilter('All'); setTypeFilter('All'); }}
                                                    className="mt-12 px-14 py-6 bg-slate-900 hover:bg-slate-800 text-white rounded-[2rem] text-[11px] font-black uppercase tracking-widest border border-white/5 shadow-2xl transition-all active:scale-95"
                                                >
                                                    Reset Scan Protocols
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <div className="overflow-y-auto flex-1 pb-20 custom-scrollbar animate-in fade-in duration-700">
                                        {clientRegistry.length > 0 ? (
                                            <div className="grid grid-cols-1 gap-4">
                                                <div className="hidden lg:grid grid-cols-6 px-10 py-6 text-[10px] font-black text-slate-700 uppercase tracking-[0.4em]">
                                                    <span className="col-span-2">Identity Node</span>
                                                    <span>Financial Drift</span>
                                                    <span>Target Asset</span>
                                                    <span>Integrity Matrix</span>
                                                    <span className="text-right">Action</span>
                                                </div>
                                                {clientRegistry.map(client => (
                                                    <div key={client.id} className="grid grid-cols-1 lg:grid-cols-6 items-center px-10 py-8 bg-slate-900/40 border border-white/5 rounded-[2.5rem] group hover:border-blue-500/40 transition-all shadow-xl">
                                                        <div className="col-span-2 flex items-center gap-6">
                                                            <div className="w-14 h-14 rounded-2xl bg-black border border-white/10 flex items-center justify-center text-slate-500 group-hover:text-blue-500 group-hover:border-blue-500/20 transition-all shadow-inner">
                                                                <UserIcon className="w-6 h-6" />
                                                            </div>
                                                            <div className="text-left">
                                                                <p className="text-lg font-black text-white uppercase tracking-tight leading-none mb-1.5">{client.name}</p>
                                                                <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest">{client.source}</p>
                                                            </div>
                                                        </div>
                                                        <div className="text-left py-4 lg:py-0">
                                                            <div className="flex items-center gap-3 text-emerald-500 font-mono font-black text-lg">
                                                                <BanknotesIcon className="w-4 h-4 opacity-40" />
                                                                {client.budget}
                                                            </div>
                                                        </div>
                                                        <div className="text-left py-4 lg:py-0">
                                                            <p className="text-[11px] font-black text-slate-400 uppercase tracking-tight truncate leading-relaxed">
                                                                <BuildingOfficeIcon className="w-4 h-4 inline-block mr-2 text-blue-500/50" />
                                                                {client.targetProperty}
                                                            </p>
                                                        </div>
                                                        <div className="text-left py-4 lg:py-0">
                                                            <div className="flex items-center gap-4">
                                                                <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden border border-white/5">
                                                                    <div 
                                                                        className={`h-full ${client.trustScore > 90 ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.6)]' : 'bg-blue-500'} transition-all`} 
                                                                        style={{ width: `${client.trustScore}%` }}
                                                                    ></div>
                                                                </div>
                                                                <span className="text-[11px] font-mono font-black text-white">{client.trustScore}%</span>
                                                            </div>
                                                            <span className={`text-[8px] font-black uppercase tracking-[0.2em] mt-1 inline-block ${client.kycStatus === 'Verified' ? 'text-emerald-500' : 'text-amber-500'}`}>KYC: {client.kycStatus}</span>
                                                        </div>
                                                        <div className="flex justify-end">
                                                            <button className="px-8 py-3.5 bg-white/5 hover:bg-blue-600 text-slate-500 hover:text-white rounded-xl border border-white/10 hover:border-blue-400/40 text-[9px] font-black uppercase tracking-widest transition-all shadow-lg active:scale-95">
                                                                Initialize Dossier
                                                            </button>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        ) : (
                                            <div className="flex flex-col items-center justify-center py-40 opacity-30 text-center px-12">
                                                <IdentificationIcon className="w-24 h-24 mb-10 text-slate-700 animate-pulse" />
                                                <h4 className="text-2xl font-black text-white uppercase tracking-tighter mb-4">Registry Offline</h4>
                                                <p className="text-sm font-medium uppercase tracking-[0.3em] max-w-md leading-relaxed">
                                                    Global identity nodes are not yet synchronized. Trigger a **Forensic Registry Sync** to pull verified lead dossiers.
                                                </p>
                                                <button 
                                                    onClick={handleSyncRegistry}
                                                    className="mt-12 px-14 py-5 bg-blue-600 hover:bg-blue-500 text-white rounded-3xl text-[11px] font-black uppercase tracking-[0.4em] shadow-3xl transition-all"
                                                >
                                                    Establish Handshake
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        )}

                        {activeTab === 'agentic' && (
                            <div className="flex-1 flex overflow-hidden animate-in fade-in duration-700 h-full">
                                <div className="w-96 bg-slate-950/40 border-r border-white/5 flex flex-col p-12 gap-6 overflow-y-auto custom-scrollbar shrink-0 hidden lg:flex">
                                    <p className="text-[11px] font-black text-slate-600 uppercase tracking-[0.5em] mb-4">Forensic Nodes</p>
                                    {availableAgents.map((agent) => (
                                        <button 
                                            key={agent.id}
                                            onClick={() => setActiveAgentId(agent.id)}
                                            className={`w-full flex items-center gap-6 p-6 rounded-3xl border transition-all duration-700 text-left relative overflow-hidden group shadow-lg ${
                                                activeAgentId === agent.id 
                                                ? 'bg-blue-600/10 border-blue-500/40 shadow-[0_20px_60px_rgba(37,99,235,0.1)] scale-[1.02]' 
                                                : 'bg-slate-900 border-white/5 hover:bg-slate-800'
                                            }`}
                                        >
                                            {activeAgentId === agent.id && <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-blue-500"></div>}
                                            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border transition-all shadow-inner ${activeAgentId === agent.id ? 'bg-blue-600 border-blue-400 text-white' : 'bg-slate-950 border-white/5 text-slate-700'}`}>
                                                {React.createElement(agentIcons[agent.id] || CpuChipIcon, { className: "w-7 h-7" })}
                                            </div>
                                            <div>
                                                <h5 className={`text-base font-black uppercase tracking-tight leading-none mb-1.5 ${activeAgentId === agent.id ? 'text-white' : 'text-slate-500'}`}>{agent.name}</h5>
                                                <p className={`text-[10px] font-black uppercase tracking-[0.2em] ${activeAgentId === agent.id ? 'text-blue-400' : 'text-slate-800'}`}>{agent.role}</p>
                                            </div>
                                        </button>
                                    ))}
                                </div>
                                <div className="flex-1 flex flex-col bg-[#050505] relative">
                                    <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
                                    <div className="flex-1 overflow-y-auto p-8 md:p-16 space-y-12 custom-scrollbar relative z-10">
                                        {(allMessages[`agent-${activeAgentId}`] || []).map((msg: any) => (
                                            <div key={msg.id} className={`flex gap-6 md:gap-8 max-w-[95%] md:max-w-[85%] ${msg.sender === 'me' ? 'ml-auto flex-row-reverse' : ''} animate-in fade-in duration-700`}>
                                                <div className={`w-12 h-12 md:w-16 md:h-16 rounded-[1.5rem] md:rounded-[1.75rem] flex items-center justify-center shrink-0 border shadow-2xl ${msg.sender === 'ai' ? 'bg-gradient-to-br from-blue-600 to-indigo-600 border-blue-400/40 text-white' : 'bg-slate-800 border-white/10 text-slate-500'}`}>
                                                    {msg.sender === 'ai' ? <CpuChipIcon className="w-8 h-8 md:w-10 md:h-10" /> : <UserIcon className="w-8 h-8 md:w-10 md:h-10" />}
                                                </div>
                                                <div className={`p-6 md:p-10 rounded-[2.5rem] md:rounded-[3.5rem] text-sm leading-relaxed border backdrop-blur-3xl text-left shadow-3xl ${msg.sender === 'ai' ? 'bg-slate-900/60 text-slate-200 border-white/10 rounded-tl-none' : 'bg-blue-600 text-white border-blue-400/40 rounded-tr-none'}`}>
                                                    <p className="font-medium">{msg.text}</p>
                                                </div>
                                            </div>
                                        ))}
                                        {isThinking && (
                                            <div className="flex items-center gap-6 animate-pulse px-6">
                                                <div className="w-14 h-14 rounded-2xl bg-slate-950 border border-blue-500/30 flex items-center justify-center text-blue-500 animate-spin-slow">
                                                    <CpuChipIcon className="w-8 h-8" />
                                                </div>
                                                <span className="text-[11px] font-black text-blue-500 uppercase tracking-[0.5em]">Neural Link Processing...</span>
                                            </div>
                                        )}
                                    </div>
                                    <div className="p-8 md:p-16 border-t border-white/5 bg-slate-950/80 backdrop-blur-3xl z-10">
                                        <div className="flex gap-4 md:gap-8 bg-black border border-white/10 p-3 rounded-[3rem] items-center focus-within:border-blue-500/50 shadow-[inset_0_2px_20px_rgba(0,0,0,0.8)]">
                                            <input 
                                                onKeyDown={(e) => e.key === 'Enter' && onSendMessage(`agent-${activeAgentId}`, (e.target as any).value, activeAgentId)} 
                                                placeholder={`Transmit instructions to ${activeAgentId.toUpperCase()}...`} 
                                                className="flex-1 bg-transparent border-none px-4 md:px-10 text-sm text-white focus:ring-0 outline-none font-medium placeholder:text-slate-800" 
                                            />
                                            <button className="bg-blue-600 hover:bg-blue-500 text-white p-4 md:p-6 rounded-[2rem] md:rounded-[2.5rem] shadow-2xl transition-all active:scale-90 ring-1 ring-white/20"><PaperAirplaneIcon className="w-6 h-6 md:w-8 md:h-8 -rotate-45" /></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}

                        {activeTab === 'stats' && (
                            <div className="flex-1 p-12 md:p-24 animate-in zoom-in-95 duration-1000 overflow-y-auto custom-scrollbar bg-grid-pattern relative">
                                <div className="absolute top-0 left-0 right-0 h-96 bg-gradient-to-b from-blue-600/5 to-transparent pointer-events-none"></div>
                                <header className="text-left mb-20 relative z-10">
                                    <h2 className="text-4xl md:text-7xl font-black text-white uppercase tracking-tighter leading-none mb-8">Performance <span className="text-blue-500">Forensics</span></h2>
                                    <p className="text-slate-500 text-base md:text-xl font-medium italic max-w-2xl">"Real-time metadata audit of active property clusters. Growth drifts synchronized."</p>
                                </header>
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 relative z-10">
                                    <StatNode label="Revenue Velocity" value="KES 4.2M" subtext="+12.4% Annual Drift" color="text-emerald-500" icon={BanknotesIcon} />
                                    <StatNode label="Conversion Node" value="28.5%" subtext="14 Active Sprints" color="text-blue-500" icon={ArrowTrendingUpIcon} />
                                    <StatNode label="Registry Load" value="412" subtext="99% Verification" color="text-indigo-500" icon={UserGroupIcon} />
                                    <StatNode label="Node Latency" value="0.4ms" subtext="Stable Neural Link" color="text-purple-500" icon={SignalIcon} />
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Right Action Sidebar */}
                    <div className="w-full md:w-[450px] bg-slate-950 border-t md:border-t-0 md:border-l border-white/5 flex flex-col overflow-hidden shrink-0 transition-all duration-500 shadow-[0_0_50px_rgba(0,0,0,0.4)]">
                        {selectedLog ? (
                            <div className="flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-500">
                                <header className="p-10 border-b border-white/5 flex items-center justify-between bg-slate-900/60 backdrop-blur-2xl shrink-0">
                                    <div className="flex items-center gap-6">
                                        <div className="p-3 bg-blue-600/10 rounded-2xl text-blue-500 border border-blue-500/20">
                                            <CpuChipIcon className="w-7 h-7" />
                                        </div>
                                        <div className="text-left">
                                            <h4 className="text-[12px] font-black text-white uppercase tracking-[0.4em]">Command Node</h4>
                                            <p className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Active Relay: {selectedLog.type}</p>
                                        </div>
                                    </div>
                                    <button onClick={() => setSelectedLog(null)} className="p-4 bg-white/5 rounded-2xl text-slate-500 hover:text-white hover:bg-rose-500/20 transition-all active:scale-90">
                                        <XMarkIcon className="w-6 h-6" />
                                    </button>
                                </header>
                                
                                <div className="flex-1 overflow-y-auto custom-scrollbar p-10 space-y-12">
                                    {/* Client Identity Blueprint */}
                                    <div className="bg-slate-900 border border-white/10 p-10 rounded-[3.5rem] shadow-inner text-left relative overflow-hidden group">
                                        <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity"><UserCircleIcon className="w-24 h-24" /></div>
                                        <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.4em] mb-4">Identity Matrix</p>
                                        <p className="text-3xl font-black text-white uppercase tracking-tighter leading-none mb-3">{selectedLog.clientName}</p>
                                        <div className="flex items-center gap-4 py-2 px-4 bg-blue-600/10 rounded-xl w-fit">
                                            <BuildingOfficeIcon className="w-4 h-4 text-blue-500" />
                                            <p className="text-[10px] text-blue-400 font-black uppercase tracking-widest">{selectedLog.propertyName}</p>
                                        </div>
                                        <div className="mt-10 pt-8 border-t border-white/5 space-y-4">
                                            <div className="flex items-center gap-3">
                                                <ClockIcon className="w-4 h-4 text-slate-700" />
                                                <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Latest Neural Handshake</p>
                                            </div>
                                            <p className="text-base text-slate-300 font-medium italic leading-relaxed">"{selectedLog.lastMessage}"</p>
                                        </div>
                                    </div>

                                    {/* Intelligence Templates */}
                                    <div className="space-y-8">
                                        <div className="flex items-center justify-between px-6">
                                            <p className="text-[11px] font-black text-slate-500 uppercase tracking-[0.4em]">Neural Response Node</p>
                                            <SparklesIcon className="w-5 h-5 text-emerald-500 animate-pulse" />
                                        </div>
                                        <div className="space-y-3">
                                            {/* Strategic Audit Action */}
                                            <button 
                                                onClick={handleStrategicROIAnalysis}
                                                disabled={isAuditing}
                                                className={`w-full flex items-center justify-between p-6 bg-indigo-600/10 border border-indigo-500/20 rounded-3xl text-[10px] font-black uppercase tracking-widest text-indigo-400 hover:text-white hover:bg-indigo-600 transition-all group active:scale-[0.98] disabled:opacity-50 text-left shadow-lg ${isAuditing ? 'animate-pulse' : ''}`}
                                            >
                                                <div className="flex flex-col items-start gap-2">
                                                    <span className="text-[8px] font-black text-indigo-500 tracking-[0.4em] opacity-80 uppercase bg-indigo-600/10 px-2 py-0.5 rounded-lg">High Intelligence</span>
                                                    <span className="flex items-center gap-4">
                                                        <PresentationChartLineIcon className="w-4 h-4 text-indigo-500 group-hover:scale-125 transition-transform" />
                                                        Execute Strategic ROI Audit
                                                    </span>
                                                </div>
                                                {isAuditing && <ArrowPathIcon className="w-4 h-4 animate-spin text-indigo-500" />}
                                            </button>

                                            {QUICK_REPLIES.map((reply, i) => (
                                                <button 
                                                    key={i} 
                                                    onClick={() => handleQuickReply(reply.text)}
                                                    disabled={isSendingReply}
                                                    className="w-full flex items-center justify-between p-6 bg-slate-900 border border-white/5 rounded-3xl text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-white hover:border-blue-500/50 hover:bg-blue-600/5 transition-all group active:scale-[0.98] disabled:opacity-50 text-left shadow-lg"
                                                >
                                                    <div className="flex flex-col items-start gap-2">
                                                        <span className="text-[8px] font-black text-blue-500 tracking-[0.4em] opacity-80 uppercase bg-blue-600/10 px-2 py-0.5 rounded-lg">{reply.category}</span>
                                                        <span className="flex items-center gap-4">
                                                            <PaperAirplaneIcon className="w-4 h-4 text-blue-500 -rotate-45 group-hover:scale-125 transition-transform" />
                                                            {reply.text}
                                                        </span>
                                                    </div>
                                                    {isSendingReply && <ArrowPathIcon className="w-4 h-4 animate-spin text-blue-500" />}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                <div className="p-10 border-t border-white/5 bg-slate-950/80 backdrop-blur-3xl shrink-0 rounded-b-[4rem]">
                                    <form onSubmit={handleManualSubmit} className="flex gap-4 bg-black border border-white/10 p-3 rounded-[1.75rem] items-center focus-within:border-blue-500/50 transition-all shadow-[inset_0_2px_15px_rgba(0,0,0,0.8)]">
                                        <input 
                                            value={manualReply}
                                            onChange={e => setManualReply(e.target.value)}
                                            placeholder="Initialize Manual Response..." 
                                            className="flex-1 bg-transparent border-none px-6 text-[11px] text-white focus:ring-0 outline-none font-medium placeholder:text-slate-800" 
                                        />
                                        <button 
                                            type="submit"
                                            disabled={isSendingReply || !manualReply.trim()}
                                            className="bg-blue-600 hover:bg-blue-500 text-white p-4 rounded-2xl shadow-[0_10px_30px_rgba(37,99,235,0.4)] transition-all active:scale-90 disabled:opacity-30 flex items-center justify-center"
                                        >
                                            <PaperAirplaneIcon className="w-5 h-5 -rotate-45" />
                                        </button>
                                    </form>
                                    <div className="flex items-center justify-center gap-4 mt-8">
                                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                                        <span className="text-[9px] font-black text-slate-800 uppercase tracking-[0.3em]">End-to-End Encryption Node Active</span>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center h-full text-center space-y-12 opacity-30 grayscale px-16">
                                <div className="relative">
                                    <div className="absolute inset-0 bg-blue-500/5 blur-[80px] rounded-full"></div>
                                    <div className="w-32 h-32 rounded-[2.5rem] bg-slate-900 border border-white/5 flex items-center justify-center text-slate-800 shadow-inner relative z-10">
                                        <ChatBubbleLeftEllipsisIcon className="w-16 h-16" />
                                    </div>
                                </div>
                                <div className="space-y-4">
                                    <p className="text-sm font-black text-slate-600 uppercase tracking-[0.6em] mb-4">Command Input Pending</p>
                                    <p className="text-[11px] font-bold text-slate-800 uppercase tracking-[0.3em] leading-relaxed max-w-xs mx-auto text-center">"Select a specific inquiry or synchronize the registry to initialize the neural workspace."</p>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

// Internal Helper Components
const FilterChip = ({ active, onClick, label, icon: Icon, count, color }: any) => {
    const colorClasses: Record<string, string> = {
        rose: active ? 'bg-rose-600 text-white border-rose-400 shadow-rose-900/20' : 'bg-white/5 text-slate-500 border-white/5 hover:border-rose-500/30',
        amber: active ? 'bg-amber-600 text-white border-amber-400 shadow-amber-900/20' : 'bg-white/5 text-slate-500 border-white/5 hover:border-amber-500/30',
        emerald: active ? 'bg-emerald-600 text-white border-emerald-400 shadow-emerald-900/20' : 'bg-white/5 text-slate-500 border-white/5 hover:border-emerald-500/30',
        blue: active ? 'bg-blue-600 text-white border-blue-400 shadow-blue-900/20' : 'bg-white/5 text-slate-500 border-white/5 hover:border-blue-500/30',
    };

    return (
        <button 
            onClick={onClick}
            className={`px-5 py-2.5 rounded-xl border text-[9px] font-black uppercase tracking-widest transition-all flex items-center gap-3 active:scale-95 ${colorClasses[color]}`}
        >
            {Icon && <Icon className="w-3.5 h-3.5" />}
            {label}
            {count !== undefined && <span className={`px-1.5 py-0.5 rounded-md ${active ? 'bg-white/20' : 'bg-black/40 text-slate-700'}`}>{count}</span>}
        </button>
    );
};
