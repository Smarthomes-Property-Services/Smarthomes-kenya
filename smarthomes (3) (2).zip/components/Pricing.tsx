
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { CheckIcon, StarIcon, ShieldCheckIcon, RocketLaunchIcon, SparklesIcon, CreditCardIcon } from '@heroicons/react/24/solid';

const plans = [
    {
        name: "Keja Lite",
        price: "Free",
        desc: "Best for casual house hunters.",
        features: [
            "5 AI Searches per day",
            "Verified Listing tags",
            "Market Pulse insights",
            "Basic Mortgage Calculator",
            "Email support"
        ],
        btnText: "Get Started",
        active: false
    },
    {
        name: "Keja Pro",
        price: "KES 1,500",
        period: "/ month",
        desc: "Best for active buyers & investors.",
        features: [
            "Unlimited AI Searches",
            "Truth Lens (Scam Detection)",
            "Off-market Listing alerts",
            "Agent Emmanuel Priority",
            "PDF Market Reports",
            "2K Design Visualizations"
        ],
        btnText: "Upgrade to Pro",
        active: true,
        tag: "Most Popular"
    },
    {
        name: "Keja Partner",
        price: "KES 5,000",
        period: "/ month",
        desc: "Best for Agents & Landlords.",
        features: [
            "Agent Workspace v2.1",
            "Lead Recycling (10% cut)",
            "Automated Rent Collection",
            "Maintenance Dispatch AI",
            "Financial Statement P&L",
            "Verified Partner Badge"
        ],
        btnText: "Join Network",
        active: false
    }
];

export const Pricing = () => {
    return (
        <div className="w-full max-w-7xl mx-auto py-12 md:py-24 px-6 animate-in fade-in slide-in-from-bottom-8 duration-700">
            <div className="text-center mb-20">
                <div className="inline-flex items-center gap-3 px-4 py-2 rounded-2xl bg-blue-600/10 border border-blue-500/20 text-blue-400 text-[10px] font-black uppercase tracking-[0.3em] mb-6 shadow-inner">
                    <SparklesIcon className="w-4 h-4" />
                    Subscription Nodes
                </div>
                <h2 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter mb-6 leading-none">
                    Choose Your <span className="text-blue-500">Tier</span>
                </h2>
                <p className="text-slate-500 max-w-xl mx-auto text-lg font-medium leading-relaxed">
                    Whether you are searching for your first apartment or managing a real estate portfolio, we have a neural plan for you.
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                {plans.map((plan, idx) => (
                    <div 
                        key={idx}
                        className={`relative flex flex-col p-10 rounded-[3rem] border transition-all duration-500 hover:-translate-y-2 group ${
                            plan.active 
                            ? 'bg-slate-900/80 backdrop-blur-xl border-blue-500/50 shadow-[0_30px_100px_rgba(37,99,235,0.2)] ring-1 ring-blue-500/20' 
                            : 'bg-[#09090b] border-white/5 hover:border-blue-500/30 hover:bg-slate-900'
                        }`}
                    >
                        {plan.tag && (
                            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[9px] font-black uppercase tracking-widest px-6 py-2 rounded-full shadow-lg border border-blue-400">
                                {plan.tag}
                            </div>
                        )}

                        <div className="mb-10 text-left">
                            <h3 className="text-xl font-black text-white uppercase tracking-tight mb-4">{plan.name}</h3>
                            <div className="flex items-baseline gap-2 mb-4">
                                <span className="text-4xl font-black text-white font-mono tracking-tighter">{plan.price}</span>
                                {plan.period && <span className="text-slate-500 text-xs font-bold uppercase tracking-widest">{plan.period}</span>}
                            </div>
                            <p className="text-slate-500 text-sm font-medium">{plan.desc}</p>
                        </div>

                        <div className="flex-1 space-y-5 mb-10">
                            {plan.features.map((feature, fIdx) => (
                                <div key={fIdx} className="flex items-start gap-4">
                                    <div className={`mt-0.5 p-1 rounded-full shrink-0 ${plan.active ? 'bg-blue-600 text-white shadow-lg' : 'bg-slate-800 text-slate-400'}`}>
                                        <CheckIcon className="w-3 h-3" />
                                    </div>
                                    <span className={`text-sm font-medium ${plan.active ? 'text-slate-200' : 'text-slate-400'}`}>{feature}</span>
                                </div>
                            ))}
                        </div>

                        <button 
                            className={`w-full py-5 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all transform active:scale-95 shadow-xl ${
                                plan.active 
                                ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-900/30' 
                                : 'bg-slate-800 hover:bg-slate-700 text-white border border-white/5'
                            }`}
                        >
                            {plan.btnText}
                        </button>
                    </div>
                ))}
            </div>

            <div className="mt-20 p-12 rounded-[4rem] bg-[#09090b] border border-white/5 flex flex-col md:flex-row items-center justify-between gap-12 shadow-3xl relative overflow-hidden group">
                <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none"></div>
                <div className="flex items-center gap-8 relative z-10">
                    <div className="bg-indigo-600/10 p-6 rounded-[2rem] border border-indigo-500/20 shadow-inner">
                        <ShieldCheckIcon className="w-12 h-12 text-indigo-500" />
                    </div>
                    <div className="text-left">
                        <h4 className="text-white font-black text-2xl uppercase tracking-tight mb-2">Enterprise Custom Node</h4>
                        <p className="text-slate-500 text-sm font-medium">Need a bespoke forensic solution for a large property agency?</p>
                    </div>
                </div>
                <button className="px-10 py-5 bg-white text-slate-950 font-black uppercase tracking-[0.2em] text-[10px] rounded-2xl hover:bg-indigo-50 transition-colors shadow-2xl relative z-10 active:scale-95">
                    Contact Sales
                </button>
            </div>
        </div>
    );
};
