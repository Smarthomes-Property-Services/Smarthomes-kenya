
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { 
    XMarkIcon, 
    CommandLineIcon, 
    CodeBracketIcon, 
    CircleStackIcon, 
    RocketLaunchIcon, 
    ShieldCheckIcon, 
    LockClosedIcon, 
    BoltIcon, 
    ArrowPathIcon, 
    SignalIcon, 
    CpuChipIcon, 
    WifiIcon, 
    GlobeAltIcon, 
    StopIcon, 
    PlayIcon, 
    WrenchScrewdriverIcon, 
    DevicePhoneMobileIcon, 
    CloudIcon, 
    ArrowsRightLeftIcon, 
    DocumentCheckIcon, 
    CodeBracketSquareIcon, 
    FolderIcon, 
    DocumentTextIcon, 
    PlayCircleIcon, 
    QrCodeIcon, 
    CheckBadgeIcon, 
    CubeIcon, 
    ServerStackIcon, 
    BeakerIcon, 
    MagnifyingGlassIcon, 
    ShieldExclamationIcon, 
    KeyIcon, 
    FireIcon, 
    Square3Stack3DIcon
} from '@heroicons/react/24/solid';

interface SystemInternalsProps {
  isOpen: boolean;
  onClose: () => void;
}

const SidebarBtn = ({ active, onClick, icon: Icon, label }: any) => (
    <button 
        onClick={onClick}
        className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl border transition-all group ${
            active ? 'bg-blue-600/10 border-blue-500/40 text-blue-500 shadow-lg' : 'bg-transparent border-transparent text-slate-500 hover:text-slate-300 hover:bg-white/5'
        }`}
    >
        <Icon className={`w-6 h-6 transition-all ${active ? 'scale-110 text-blue-500' : 'text-slate-600 group-hover:text-slate-400'}`} />
        <span className={`text-[11px] font-black uppercase tracking-widest transition-all ${active ? 'text-blue-400' : 'text-slate-600 group-hover:text-slate-400'}`}>{label}</span>
    </button>
);

export const SystemInternals: React.FC<SystemInternalsProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'security' | 'deployment' | 'migrations' | 'repo' | 'interactions' | 'android' | 'ios' | 'intelligence'>('intelligence');
  const [isExecutingScript, setIsExecutingScript] = useState(false);
  const [cliInstalled, setCliInstalled] = useState(false);
  const [firebaseExtInstalled, setFirebaseExtInstalled] = useState(false);
  const [logs, setLogs] = useState<{msg: string, type: 'info' | 'success' | 'warn' | 'error' | 'cmd'}[]>([]);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleInstallCli = async () => {
    if (isExecutingScript) return;
    setIsExecutingScript(true);
    setLogs([]);

    const steps = [
        { msg: 'npm install -g @google/gemini-cli', type: 'cmd' as const },
        { msg: 'Resolving packages...', type: 'info' as const },
        { msg: 'fetch http://registry.npmjs.org/@google/gemini-cli/-/gemini-cli-1.28.0.tgz', type: 'info' as const },
        { msg: 'Extracting global node assets...', type: 'info' as const },
        { msg: 'Linking /usr/local/bin/gemini -> /usr/local/lib/node_modules/@google/gemini-cli/bin/gemini', type: 'info' as const },
        { msg: '+ @google/gemini-cli@1.28.0', type: 'success' as const },
        { msg: 'added 142 packages in 4.2s', type: 'success' as const },
        { msg: '❯ gemini --version', type: 'cmd' as const },
        { msg: 'v1.28.0-build.goat', type: 'info' as const }
    ];

    for (const step of steps) {
        await new Promise(r => setTimeout(r, 300 + Math.random() * 300));
        setLogs(prev => [...prev, step]);
    }
    setCliInstalled(true);
    setIsExecutingScript(false);
  };

  const handleRunFirebaseSync = async () => {
    if (isExecutingScript) return;
    if (!cliInstalled) {
        setLogs([{ msg: 'Error: gemini command not found. Run "npm install -g @google/gemini-cli" first.', type: 'error' as const }]);
        return;
    }
    setIsExecutingScript(true);
    setLogs([]);

    const steps = [
        { msg: 'gemini extensions install https://github.com/gemini-cli-extensions/firebase', type: 'cmd' as const },
        { msg: 'Cloning into /home/keja/.gemini/extensions/firebase...', type: 'info' as const },
        { msg: 'Installing extension dependencies...', type: 'info' as const },
        { msg: '✔ Extension FIREBASE-BRIDGE successfully registered.', type: 'success' as const },
        { msg: '❯ gemini-firebase-sync --collections properties,users,leads', type: 'cmd' as const },
        { msg: 'Project ID: keja-proptech-v4 detected.', type: 'info' as const },
        { msg: 'Mapping Firestore Collections to Neural Matrix...', type: 'info' as const },
        { msg: 'Syncing Identity Nodes via Firebase-Auth...', type: 'info' as const },
        { msg: 'Cold Start Optimization: Prefetching indices...', type: 'warn' as const },
        { msg: 'Bridge Active: Cloud State parity verified.', type: 'success' as const }
    ];

    for (const step of steps) {
        await new Promise(r => setTimeout(r, 400 + Math.random() * 400));
        setLogs(prev => [...prev, step]);
    }
    setFirebaseExtInstalled(true);
    setIsExecutingScript(false);
  };

  const handleRunEnrichment = async () => {
    if (isExecutingScript) return;
    if (!cliInstalled) {
        setLogs([{ msg: 'Error: gemini command not found.', type: 'error' as const }]);
        return;
    }
    setIsExecutingScript(true);
    setLogs([]);

    const steps = [
        { msg: 'gemini extensions install https://github.com/GoogleCloudPlatform/db-context-enrichment', type: 'cmd' as const },
        { msg: '✔ Extension: DB-Context-Enrichment established', type: 'success' as const },
        { msg: '❯ gemini-db-enrich --target pg_catalog.keja_registry', type: 'cmd' as const },
        { msg: 'Scanning Database Nodes: [Properties, Inquiries, Identity]', type: 'info' as const },
        { msg: 'Neural Handshake: Syncing Schema metadata...', type: 'warn' as const },
        { msg: 'Context successfully enriched. 42 entities mapped to Neural Matrix.', type: 'success' as const }
    ];

    for (const step of steps) {
        await new Promise(r => setTimeout(r, 400 + Math.random() * 400));
        setLogs(prev => [...prev, step]);
    }
    setIsExecutingScript(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 md:p-10 bg-slate-950/95 backdrop-blur-2xl animate-in fade-in duration-500">
      <div className="w-full max-w-7xl bg-[#020617] border border-white/5 rounded-[4rem] shadow-[0_0_150px_rgba(0,0,0,1)] flex flex-col max-h-full overflow-hidden border-white/10 ring-1 ring-white/5">
        
        {/* Forensic Header */}
        <div className="flex items-center justify-between p-8 md:p-12 border-b border-white/5 bg-slate-950/60">
            <div className="flex items-center gap-8 text-left">
                <div className="p-5 bg-blue-600/10 rounded-3xl border border-blue-500/20 text-blue-500 shadow-[inset_0_0_20px_rgba(0,0,0,0.5)]">
                    <CommandLineIcon className="w-10 h-10" />
                </div>
                <div>
                    <h2 className="text-white font-black text-3xl uppercase tracking-tighter leading-none mb-2">Kernel Internals</h2>
                    <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full animate-pulse ${cliInstalled ? 'bg-emerald-500' : 'bg-blue-500'}`}></div>
                        <p className="text-blue-400 text-[10px] font-black uppercase tracking-[0.4em]">
                            Forensic Dev-Stack {cliInstalled ? 'v1.28.0-CLI' : 'v2.8.5.GOAT'}
                        </p>
                    </div>
                </div>
            </div>
            <button onClick={onClose} className="p-4 bg-slate-900 text-slate-500 hover:text-white rounded-2xl border border-white/5 transition-all hover:bg-rose-500/20 active:scale-95">
                <XMarkIcon className="w-8 h-8" />
            </button>
        </div>

        <div className="flex-1 flex overflow-hidden">
            {/* Sidebar Rail */}
            <div className="w-72 bg-slate-950/80 border-r border-white/5 flex flex-col p-8 gap-3 overflow-y-auto no-scrollbar hidden md:flex text-left">
                <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.4em] mb-4">Neural Core Control</p>
                <SidebarBtn active={activeTab === 'intelligence'} onClick={() => setActiveTab('intelligence')} icon={BeakerIcon} label="Intelligence Nodes" />
                <SidebarBtn active={activeTab === 'android'} onClick={() => setActiveTab('android')} icon={DevicePhoneMobileIcon} label="Android Forge" />
                <SidebarBtn active={activeTab === 'ios'} onClick={() => setActiveTab('ios')} icon={DevicePhoneMobileIcon} label="iOS Nexus" />
                <SidebarBtn active={activeTab === 'security'} onClick={() => setActiveTab('security')} icon={ShieldCheckIcon} label="Security Core" />
                <SidebarBtn active={activeTab === 'interactions'} onClick={() => setActiveTab('interactions')} icon={SignalIcon} label="Neural Relay" />
                <SidebarBtn active={activeTab === 'repo'} onClick={() => setActiveTab('repo')} icon={CubeIcon} label="Object Archive" />
                
                <div className="mt-auto pt-8 border-t border-white/5 space-y-6">
                     <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-slate-500">
                        <span>Neural Extension Load</span>
                        <span className="text-blue-500">Active</span>
                     </div>
                     <div className="h-1.5 bg-slate-900 rounded-full overflow-hidden ring-1 ring-white/5">
                        <div className="h-full bg-blue-600 rounded-full shadow-[0_0_10px_rgba(37,99,235,0.8)]" style={{ width: cliInstalled ? '94%' : '60%' }}></div>
                     </div>
                </div>
            </div>

            {/* Work Area */}
            <div className="flex-1 bg-[#010309] overflow-auto no-scrollbar relative bg-grid-pattern">
                <div className="p-12 h-full">
                    {activeTab === 'intelligence' && (
                        <div className="space-y-12 animate-in slide-in-from-right-8 duration-700 text-left h-full flex flex-col">
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 flex-1">
                                <div className="space-y-10">
                                    <div className="flex items-center justify-between">
                                        <h3 className="text-white font-black text-xl uppercase tracking-tighter flex items-center gap-4">
                                            <CircleStackIcon className="w-8 h-8 text-blue-500" />
                                            Data & Governance Nodes
                                        </h3>
                                        <div className={`flex items-center gap-3 px-5 py-2 rounded-2xl border ${cliInstalled ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-blue-500/10 border-blue-500/20 text-blue-400'}`}>
                                            <div className={`w-2 h-2 rounded-full animate-pulse ${cliInstalled ? 'bg-emerald-500' : 'bg-blue-500'}`}></div>
                                            <span className="text-[9px] font-black uppercase tracking-widest">{cliInstalled ? 'CLI: v1.28.0' : 'NODES: SYNCED'}</span>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div className="bg-slate-950 p-8 rounded-3xl border border-white/5 space-y-6 shadow-xl relative overflow-hidden group">
                                            <div className="absolute inset-0 bg-blue-500/[0.02] pointer-events-none group-hover:bg-blue-500/[0.05] transition-colors"></div>
                                            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-3">
                                                <Square3Stack3DIcon className="w-4 h-4 text-blue-500" />
                                                Core Package
                                            </p>
                                            <button 
                                                onClick={handleInstallCli}
                                                disabled={isExecutingScript || cliInstalled}
                                                className={`w-full py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 disabled:opacity-50 ${cliInstalled ? 'bg-emerald-600/20 text-emerald-500 border border-emerald-500/30' : 'bg-blue-600/10 hover:bg-blue-600 text-blue-400 hover:text-white border border-blue-500/20'}`}
                                            >
                                                {cliInstalled ? 'Gemini CLI Ready' : 'Install Global CLI'}
                                            </button>
                                        </div>
                                        <div className="bg-slate-950 p-8 rounded-3xl border border-white/5 space-y-6 shadow-xl relative overflow-hidden group">
                                            <div className="absolute inset-0 bg-amber-500/[0.02] pointer-events-none group-hover:bg-amber-500/[0.05] transition-colors"></div>
                                            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-3">
                                                <FireIcon className="w-4 h-4 text-amber-500" />
                                                Firebase Bridge
                                            </p>
                                            <button 
                                                onClick={handleRunFirebaseSync}
                                                disabled={isExecutingScript || !cliInstalled}
                                                className={`w-full py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 disabled:opacity-50 ${firebaseExtInstalled ? 'bg-amber-600/20 text-amber-500 border border-amber-500/30' : 'bg-amber-600/10 hover:bg-amber-600 text-amber-400 hover:text-white border border-amber-500/20'}`}
                                            >
                                                {firebaseExtInstalled ? 'Cloud Handshake OK' : 'Simulate Ext Install'}
                                            </button>
                                        </div>
                                        <div className="bg-slate-950 p-8 rounded-3xl border border-white/5 space-y-6 shadow-xl col-span-2 relative overflow-hidden group">
                                             <div className="absolute inset-0 bg-purple-500/[0.02] pointer-events-none group-hover:bg-purple-500/[0.05] transition-colors"></div>
                                            <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-3">
                                                <CircleStackIcon className="w-4 h-4 text-purple-500" />
                                                DB Enrichment Node
                                            </p>
                                            <button 
                                                onClick={handleRunEnrichment}
                                                disabled={isExecutingScript || !cliInstalled}
                                                className="w-full py-4 bg-purple-600/10 hover:bg-purple-600 text-purple-400 hover:text-white border border-purple-500/20 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 disabled:opacity-50"
                                            >
                                                Run Data Context Audit
                                            </button>
                                        </div>
                                    </div>

                                    {/* Terminal Area Implementation */}
                                    <div className="flex-1 bg-black border border-white/10 rounded-[2.5rem] p-8 font-mono text-xs overflow-hidden flex flex-col shadow-2xl">
                                        <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/5">
                                            <div className="flex gap-1.5">
                                                <div className="w-2.5 h-2.5 rounded-full bg-rose-500/50"></div>
                                                <div className="w-2.5 h-2.5 rounded-full bg-amber-500/50"></div>
                                                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/50"></div>
                                            </div>
                                            <span className="text-[10px] text-slate-700 font-bold uppercase tracking-widest">Bash Node — gemini-cli</span>
                                        </div>
                                        <div className="flex-1 overflow-y-auto space-y-3 no-scrollbar pb-4">
                                            {logs.length === 0 ? (
                                                <div className="h-full flex flex-col items-center justify-center text-slate-800 italic uppercase tracking-widest">
                                                    <CommandLineIcon className="w-12 h-12 mb-4 opacity-20" />
                                                    Awaiting global CLI initialization...
                                                </div>
                                            ) : (
                                                logs.map((log, i) => (
                                                    <div key={i} className="animate-in slide-in-from-left-2 duration-300">
                                                        {log.type === 'cmd' && <span className="text-emerald-500 mr-3 font-black">❯</span>}
                                                        <span className={`
                                                            ${log.type === 'success' ? 'text-emerald-400 font-bold' : ''}
                                                            ${log.type === 'warn' ? 'text-amber-400' : ''}
                                                            ${log.type === 'info' ? 'text-blue-400' : ''}
                                                            ${log.type === 'error' ? 'text-rose-400 font-black uppercase' : ''}
                                                            ${log.type === 'cmd' ? 'text-white font-bold' : 'text-slate-400'}
                                                        `}>
                                                            {log.msg}
                                                        </span>
                                                    </div>
                                                ))
                                            )}
                                            <div ref={logEndRef} />
                                        </div>
                                    </div>
                                </div>

                                <div className="bg-slate-950 p-12 rounded-[3.5rem] border border-white/5 relative overflow-hidden flex flex-col shadow-2xl">
                                    <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
                                    <div className="relative z-10 space-y-10">
                                        <div className="flex items-center justify-between">
                                            <h3 className="text-white font-black text-xl uppercase tracking-tighter flex items-center gap-4">
                                                <ServerStackIcon className="w-8 h-8 text-purple-500" />
                                                Core Extension Matrix
                                            </h3>
                                        </div>
                                        <div className="space-y-6">
                                            <ExtensionItem label="@google/gemini-cli" status={cliInstalled ? "Active" : "Not Found"} version="v1.28.0" active={cliInstalled} color="text-emerald-500" />
                                            <ExtensionItem label="FIREBASE-BRIDGE" status={firebaseExtInstalled ? "Active" : "Standby"} version="v2.1.0" active={firebaseExtInstalled} color="text-amber-500" />
                                            <ExtensionItem label="DB-CONTEXT-ENRICH" status="Active" version="v1.4.2" active={logs.some(l => l.msg.includes('DB-Context-Enrichment'))} />
                                            <ExtensionItem label="Neural-IO-Relay" status="Standby" version="v2.1.1" active={false} />
                                            <ExtensionItem label="Forensic-Auth-Shield" status="Active" version="v4.0.0" active={true} />
                                        </div>
                                    </div>

                                    {/* Cloud Handshake Visualizer */}
                                    <div className="mt-auto pt-10 border-t border-white/5 flex items-center justify-center gap-12 opacity-40 grayscale group-hover:opacity-100 group-hover:grayscale-0 transition-all">
                                        <div className="flex flex-col items-center gap-2">
                                            <div className="w-10 h-10 bg-slate-900 rounded-full flex items-center justify-center text-blue-500 border border-white/5">
                                                <CircleStackIcon className="w-5 h-5" />
                                            </div>
                                            <span className="text-[7px] font-black uppercase tracking-widest">Local</span>
                                        </div>
                                        <div className="flex-1 h-px bg-gradient-to-r from-blue-500/50 via-amber-500/50 to-purple-500/50 relative">
                                             <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                                        </div>
                                        <div className="flex flex-col items-center gap-2">
                                            <div className="w-10 h-10 bg-slate-900 rounded-full flex items-center justify-center text-amber-500 border border-white/5">
                                                <CloudIcon className="w-5 h-5" />
                                            </div>
                                            <span className="text-[7px] font-black uppercase tracking-widest">Cloud</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'android' && (
                        <div className="space-y-12 animate-in slide-in-from-right-8 duration-700 text-left">
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                                <div className="space-y-10">
                                    <div className="flex items-center justify-between">
                                        <h3 className="text-white font-black text-xl uppercase tracking-tighter flex items-center gap-4">
                                            <DevicePhoneMobileIcon className="w-8 h-8 text-emerald-500" />
                                            Android Forensic Forge
                                        </h3>
                                        <div className="flex items-center gap-3 bg-emerald-500/10 px-5 py-2 rounded-2xl border border-emerald-500/20">
                                            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                                            <span className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">ADB: SYNCHRONIZED</span>
                                        </div>
                                    </div>
                                    <div className="bg-slate-900 border border-white/10 p-10 rounded-[3rem] relative overflow-hidden group shadow-2xl">
                                        <h4 className="text-white font-black text-sm uppercase tracking-widest mb-8">Manifest Signature</h4>
                                        <div className="p-8 bg-slate-950 rounded-3xl border border-white/5 shadow-inner">
                                            <pre className="text-[12px] font-mono text-slate-500 leading-relaxed">
                                                <code>{`<!-- Android Manifest v4.5 -->
<manifest package="com.smarthomes.ke">
  <uses-permission android:name="CAMERA" />
  <uses-permission android:name="BIOMETRIC" />
  <application>
    <activity android:name=".TruthLens" />
  </application>
</manifest>`}</code>
                                            </pre>
                                        </div>
                                        <button className="w-full mt-8 py-6 bg-emerald-600 hover:bg-emerald-500 text-white rounded-3xl font-black uppercase text-xs tracking-widest transition-all flex items-center justify-center gap-4 shadow-2xl opacity-50 cursor-not-allowed">
                                            <RocketLaunchIcon className="w-6 h-6" />
                                            Compile Forensic Node
                                        </button>
                                    </div>
                                </div>
                                <div className="bg-slate-900 border border-white/10 p-10 rounded-[3rem] relative overflow-hidden group shadow-2xl">
                                     <h4 className="text-white font-black text-sm uppercase tracking-widest mb-8 flex items-center gap-3">
                                        <CodeBracketSquareIcon className="w-5 h-5 text-blue-500" />
                                        Gradle Build Matrix
                                     </h4>
                                     <div className="p-8 bg-slate-950 rounded-3xl border border-white/5 shadow-inner">
                                        <pre className="text-[12px] font-mono text-slate-500 leading-relaxed">
                                            <code>{`// Root build.gradle.kts
plugins {
    id("com.android.application") version "8.1.0" apply false
    id("com.google.gms.google-services") version "4.4.4" apply false
}

// app/build.gradle.kts dependencies
dependencies {
    implementation(platform("com.google.firebase:firebase-bom:34.7.0"))
    implementation("com.google.firebase:firebase-analytics")
}`}</code>
                                        </pre>
                                     </div>
                                     <div className="mt-8 flex items-center gap-4">
                                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                                        <span className="text-[10px] font-black uppercase tracking-widest text-emerald-500">Firebase Analytics: LINKED</span>
                                     </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'ios' && (
                        <div className="space-y-12 animate-in slide-in-from-right-8 duration-700 text-left">
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                                <div className="space-y-10">
                                    <div className="flex items-center justify-between">
                                        <h3 className="text-white font-black text-xl uppercase tracking-tighter flex items-center gap-4">
                                            <DevicePhoneMobileIcon className="w-8 h-8 text-indigo-500" />
                                            iOS Nexus Core
                                        </h3>
                                        <div className="flex items-center gap-3 bg-indigo-500/10 px-5 py-2 rounded-2xl border border-indigo-500/20">
                                            <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></div>
                                            <span className="text-[9px] font-black text-indigo-400 uppercase tracking-widest">XCODE: CONNECTED</span>
                                        </div>
                                    </div>
                                    <div className="bg-slate-900 border border-white/10 p-10 rounded-[3rem] relative overflow-hidden group shadow-2xl">
                                        <h4 className="text-white font-black text-sm uppercase tracking-widest mb-8">Info.plist Configuration</h4>
                                        <div className="p-8 bg-slate-950 rounded-3xl border border-white/5 shadow-inner">
                                            <pre className="text-[12px] font-mono text-slate-500 leading-relaxed">
                                                <code>{`<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>NSCameraUsageDescription</key>
    <string>Truth-Lens requires camera access for forensic scanning.</string>
</dict>
</plist>`}</code>
                                            </pre>
                                        </div>
                                    </div>
                                </div>
                                <div className="bg-slate-900 border border-white/10 p-10 rounded-[3rem] relative overflow-hidden group shadow-2xl">
                                        <h4 className="text-white font-black text-sm uppercase tracking-widest mb-8 flex items-center gap-3">
                                        <CodeBracketSquareIcon className="w-5 h-5 text-blue-500" />
                                        Package.swift
                                        </h4>
                                        <div className="p-8 bg-slate-950 rounded-3xl border border-white/5 shadow-inner">
                                        <pre className="text-[12px] font-mono text-slate-500 leading-relaxed">
                                            <code>{`// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "KejaOS",
    dependencies: [
        .package(url: "https://github.com/firebase/firebase-ios-sdk.git", from: "10.0.0"),
        .package(url: "https://github.com/supabase/supabase-swift.git", from: "2.0.0"),
    ],
    targets: [
        .target(
            name: "KejaOS",
            dependencies: [
                .product(name: "FirebaseAnalytics", package: "firebase-ios-sdk"),
                .product(name: "Supabase", package: "supabase-swift"),
            ]),
    ]
)`}</code>
                                        </pre>
                                        </div>
                                        <div className="mt-8 flex items-center gap-4">
                                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                                        <span className="text-[10px] font-black uppercase tracking-widest text-emerald-500">SPM: RESOLVED</span>
                                        </div>
                                </div>
                                <div className="bg-slate-900 border border-white/10 p-10 rounded-[3rem] relative overflow-hidden group shadow-2xl col-span-1 lg:col-span-2">
                                    <div className="absolute top-0 right-0 p-10 opacity-5">
                                        <BoltIcon className="w-32 h-32 text-emerald-500" />
                                    </div>
                                    <h4 className="text-white font-black text-sm uppercase tracking-widest mb-8 flex items-center gap-3">
                                        <BoltIcon className="w-5 h-5 text-emerald-500" />
                                        Supabase Client Init
                                    </h4>
                                    <div className="p-8 bg-slate-950 rounded-3xl border border-white/5 shadow-inner">
                                        <pre className="text-[12px] font-mono text-slate-500 leading-relaxed">
                                            <code>{`import Supabase

enum AppConfig {
    static let supabaseURL = URL(string: "https://mmweeohdpiqxmfxckgxz.supabase.co")!
    static let supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}

let supabase = SupabaseClient(
    supabaseURL: AppConfig.supabaseURL,
    supabaseKey: AppConfig.supabaseKey
)`}</code>
                                        </pre>
                                    </div>
                                    <div className="mt-8 flex items-center gap-4">
                                         <div className="flex -space-x-2">
                                            <div className="w-8 h-8 rounded-full bg-slate-800 border-2 border-slate-950 flex items-center justify-center text-[10px] font-bold text-white">Auth</div>
                                            <div className="w-8 h-8 rounded-full bg-slate-800 border-2 border-slate-950 flex items-center justify-center text-[10px] font-bold text-white">DB</div>
                                            <div className="w-8 h-8 rounded-full bg-slate-800 border-2 border-slate-950 flex items-center justify-center text-[10px] font-bold text-white">Edge</div>
                                         </div>
                                         <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Client Active</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

const ExtensionItem = ({ label, status, version, active, color }: any) => (
    <div className={`p-6 rounded-3xl border transition-all ${active ? 'bg-blue-600/5 border-blue-500/20 shadow-lg' : 'bg-black/40 border-white/5 opacity-50'}`}>
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
                <div className={`w-3 h-3 rounded-full ${active ? (color ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.8)]' : 'bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.8)]') : 'bg-slate-800'}`}></div>
                <div>
                    <p className={`text-white font-black text-sm uppercase tracking-tight ${active && color ? color : ''}`}>{label}</p>
                    <p className="text-[9px] text-slate-600 font-bold uppercase tracking-widest">{version}</p>
                </div>
            </div>
            <span className={`text-[10px] font-black uppercase tracking-widest ${active ? 'text-emerald-500' : 'text-slate-700'}`}>{status}</span>
        </div>
    </div>
);
