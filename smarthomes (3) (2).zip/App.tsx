
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Header, HomePageHero } from './components/Hero.tsx'; 
import { AgentCommand, SearchMode } from './components/InputArea.tsx';
import { ListingsGrid } from './components/LivePreview.tsx';
import { SystemInternals } from './components/SystemInternals.tsx';
import { MortgageCalculator } from './components/MortgageCalculator.tsx';
import { ListingDetailsModal } from './components/ListingDetailsModal.tsx';
import { PostPropertyModal } from './components/PostPropertyModal.tsx';
import { CharityAgent } from './components/CharityAgent.tsx';
import { Pricing } from './components/Pricing.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { NeuralChatWidget } from './components/NeuralChatWidget.tsx';
import { StatsDashboard } from './components/StatsDashboard.tsx';
import { InvestmentAuditModal } from './components/InvestmentAuditModal.tsx';
import { UserProfile } from './components/UserProfile.tsx';
import { BottomNav } from './components/BottomNav.tsx';
import { ComparisonModal } from './components/ComparisonModal.tsx';
import { AiToolbox } from './components/AiToolbox.tsx';
import { LiveConversation } from './components/LiveConversation.tsx';
import { supabase } from './services/supabase.ts';
import { 
    generateListings, 
    getTrendingProperties, 
    askAgent,
    PropertyListing, 
    analyzePropertyImage,
    VisionAnalysis,
    SavedSearch
} from './services/gemini.ts';
import { 
    CpuChipIcon, 
    XMarkIcon,
    BellAlertIcon,
    AdjustmentsHorizontalIcon,
    ArrowsRightLeftIcon,
    SparklesIcon,
    ArrowPathIcon,
    TrashIcon,
    FingerPrintIcon,
    ShieldCheckIcon,
    KeyIcon
} from '@heroicons/react/24/solid';

const BootScreen = ({ onDirectHandshake, onSelectApiKey, hasKey }: { onDirectHandshake: () => void, onSelectApiKey: () => void, hasKey: boolean }) => {
    return (
        <div className="fixed inset-0 z-[5000] bg-[#020203] flex flex-col items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
            <div className="relative mb-12 group">
                <div className={`absolute inset-0 bg-blue-600/30 blur-[100px] rounded-full animate-pulse`}></div>
                <div className="relative w-32 h-32 bg-zinc-950 border border-zinc-800 rounded-[2.5rem] flex items-center justify-center text-blue-500 shadow-2xl">
                    <CpuChipIcon className="w-16 h-16 animate-spin-slow" />
                </div>
            </div>

            <div className="flex flex-col items-center gap-8 relative z-10 max-w-md text-center px-8">
                <h1 className="text-white font-black text-2xl uppercase tracking-[0.5em] animate-pulse">Initializing Keja OS</h1>
                
                {!hasKey ? (
                    <div className="space-y-6">
                        <p className="text-zinc-500 text-sm leading-relaxed">Mandatory: Select a paid API key to activate high-end forensic visualization nodes (Veo & Nano Banana Pro).</p>
                        <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-[10px] text-blue-400 underline uppercase tracking-widest block">View Billing Documentation</a>
                        <button 
                            onClick={onSelectApiKey}
                            className="px-10 py-5 bg-blue-600 hover:bg-blue-500 text-white rounded-[1.5rem] font-black uppercase tracking-widest text-[11px] shadow-2xl transition-all flex items-center gap-4"
                        >
                            <KeyIcon className="w-5 h-5" /> Select API Key
                        </button>
                    </div>
                ) : (
                    <div className="space-y-6">
                         <div className="w-64 h-1 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                            <div className="h-full bg-blue-600 w-full animate-progress-indeterminate"></div>
                        </div>
                        <button 
                            onClick={onDirectHandshake}
                            className="group relative flex items-center gap-4 px-8 py-4 bg-emerald-600/10 border border-emerald-500/20 rounded-[2rem] hover:bg-emerald-600 hover:text-white transition-all duration-500 shadow-[0_0_30px_rgba(16,185,129,0.1)] active:scale-95"
                        >
                            <FingerPrintIcon className="w-5 h-5 text-emerald-500 group-hover:text-white" />
                            <div className="text-left">
                                <p className="text-[8px] font-black text-emerald-500 group-hover:text-emerald-200 uppercase tracking-widest">Handshake Verified</p>
                                <p className="text-[11px] font-black text-white uppercase tracking-tight">Access Registry</p>
                            </div>
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

const SystemToast = ({ message, onClose }: { message: string, onClose: () => void }) => (
    <div className="fixed top-24 right-8 z-[1100] animate-in slide-in-from-right-10 fade-in duration-500">
        <div className="bg-zinc-950/90 backdrop-blur-2xl border border-blue-500/30 p-6 rounded-[2rem] shadow-2xl flex items-center gap-6 min-w-[320px]">
            <BellAlertIcon className="w-6 h-6 text-blue-500 animate-pulse" />
            <div className="text-left flex-1">
                <p className="text-[9px] font-black text-blue-400 uppercase tracking-[0.4em] mb-1">Emmanuel Dispatch Node</p>
                <p className="text-sm font-black text-white tracking-tight">{message}</p>
            </div>
            <button onClick={onClose} className="p-2 text-zinc-600 hover:text-white transition-colors">
                <XMarkIcon className="w-5 h-5" />
            </button>
        </div>
    </div>
);

const App: React.FC = () => {
  const [user, setUser] = useState<any>(null);
  const [isBooting, setIsBooting] = useState(true);
  const [hasApiKey, setHasApiKey] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [listings, setListings] = useState<PropertyListing[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState('Buy');
  const [selectedListing, setSelectedListing] = useState<PropertyListing | null>(null);
  const [showPostModal, setShowPostModal] = useState(false);
  const [showToolbox, setShowToolbox] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [showDevMode, setShowDevMode] = useState(false);
  const [headerSearchQuery, setHeaderSearchQuery] = useState('');
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [isComparisonModalOpen, setIsComparisonModalOpen] = useState(false);
  const [selectedForComparison, setSelectedForComparison] = useState<string[]>([]);
  const [savedSearches, setSavedSearches] = useState<SavedSearch[]>([]);
  const [analysis, setAnalysis] = useState<VisionAnalysis | null>(null);
  const [systemToast, setSystemToast] = useState<string | null>(null);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  const [allMessages, setAllMessages] = useState<Record<string, any[]>>({
    'ai-emmanuel': [{ id: '1', sender: 'ai', text: "Handshake verified. Awaiting instructions. Sawa?", time: 'Now' }]
  });

  const [filterBedrooms, setFilterBedrooms] = useState<number | null>(null);
  const [filterPropertyType, setFilterPropertyType] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [filterPriceRange, setFilterPriceRange] = useState<[number, number]>([0, 250000000]);

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio?.hasSelectedApiKey) {
        const selected = await window.aistudio.hasSelectedApiKey();
        setHasApiKey(selected);
      }
    };
    checkKey();
    const interval = setInterval(checkKey, 3000);
    return () => clearInterval(interval);
  }, []);

  const loadInitialData = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    setUser(session?.user || null);
    const trending = await getTrendingProperties();
    setListings(trending);
    const cachedFavorites = localStorage.getItem('keja-favorites');
    if (cachedFavorites) setFavorites(JSON.parse(cachedFavorites));
    const saved = localStorage.getItem('keja-saved-searches');
    if (saved) setSavedSearches(JSON.parse(saved));
    setIsBooting(false);
  }, []);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  const handleSelectApiKey = async () => {
    if (window.aistudio?.openSelectKey) {
      await window.aistudio.openSelectKey();
      setHasApiKey(true);
    }
  };

  const handleSearch = async (query: string, mode: SearchMode, file?: File | null) => {
    setIsProcessing(true);
    setHeaderSearchQuery(query); 
    setAnalysis(null); 
    try {
      if (file) {
        const base64 = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
        });
        const visionResult = await analyzePropertyImage(base64, query || "Visual Scan");
        setAnalysis(visionResult);
        if (mode === 'forensic') {
            setIsProcessing(false);
            return;
        }
      }
      if (mode === 'search') {
        const results = await generateListings(query, 1);
        setListings(results);
      } else if (mode === 'invest') {
        setIsAuditModalOpen(true);
      }
    } catch (e) {
      setSystemToast("Parity Error: Registry Link Timeout.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleToggleFavorite = (id: string) => {
    setFavorites(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleSendMessage = async (threadId: string, text: string, agent: string = 'emmanuel') => {
    const userMsg = { id: Date.now().toString(), sender: 'me', text, time: 'Now' };
    setAllMessages(prev => ({ ...prev, [threadId]: [...(prev[threadId] || []), userMsg] }));
    setIsProcessing(true);
    try {
      const history = (allMessages[threadId] || []).map(m => ({ role: m.sender === 'me' ? 'user' : 'model', text: m.text }));
      const response = await askAgent(agent, history, text);
      const aiMsg = { id: 'ai-' + Date.now(), sender: 'ai', text: response.text, time: 'Now', suggestions: response.suggestions };
      setAllMessages(prev => ({ ...prev, [threadId]: [...(prev[threadId] || []), aiMsg] }));
    } catch (e) { console.error(e); } finally { setIsProcessing(false); }
  };

  if (isBooting) return <BootScreen hasKey={hasApiKey} onSelectApiKey={handleSelectApiKey} onDirectHandshake={() => setIsBooting(false)} />;

  return (
    <div className={`min-h-screen transition-colors duration-700 ${theme === 'dark' ? 'bg-[#020203] text-white' : 'bg-zinc-50 text-zinc-900'}`}>
      <Header 
        onOpenDev={() => setShowDevMode(true)}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onPostProperty={() => setShowPostModal(true)}
        user={user}
        onAuthClick={() => setShowAuthModal(true)}
        onSignOut={() => { setUser(null); supabase.auth.signOut(); }}
        searchQuery={headerSearchQuery}
        onSearchChange={setHeaderSearchQuery}
        theme={theme}
        onToggleTheme={() => setTheme(prev => prev === 'dark' ? 'light' : 'dark')}
      />

      {systemToast && <SystemToast message={systemToast} onClose={() => setSystemToast(null)} />}

      <main className="pb-40 text-left">
        {activeTab === 'Buy' && (
          <>
            <HomePageHero firstListing={listings[0]} />
            <AgentCommand 
              onSearch={handleSearch} 
              isProcessing={isProcessing}
              filterPropertyType={filterPropertyType}
              onPropertyTypeChange={setFilterPropertyType}
              filterStatus={filterStatus}
              onStatusChange={setFilterStatus}
              filterPriceRange={filterPriceRange}
              onPriceRangeChange={setFilterPriceRange}
              savedSearches={savedSearches}
              onSaveSearch={() => {}}
            />
            <div className="max-w-[1600px] mx-auto px-6 md:px-16 py-24">
              <div className="flex items-center justify-between mb-12">
                  <h2 className="text-5xl font-black uppercase tracking-tighter">Global <span className="text-blue-500">Registry</span></h2>
                  <button onClick={() => setShowToolbox(true)} className="p-4 bg-blue-600/10 border border-blue-500/20 text-blue-500 rounded-2xl flex items-center gap-3 hover:bg-blue-600 hover:text-white transition-all">
                      <SparklesIcon className="w-6 h-6" />
                      <span className="text-[10px] font-black uppercase tracking-widest">Neural Toolbox</span>
                  </button>
              </div>
              <ListingsGrid 
                listings={listings}
                onViewDetails={setSelectedListing}
                favorites={favorites}
                onToggleFavorite={handleToggleFavorite}
                filterStatus={filterStatus}
                onStatusChange={setFilterStatus}
                filterType={filterPropertyType}
                onTypeChange={setFilterPropertyType}
                filterBedrooms={filterBedrooms}
                onBedroomsChange={setFilterBedrooms}
                filterPriceRange={filterPriceRange}
                onPriceRangeChange={setFilterPriceRange}
                analysis={analysis}
                onCloseAnalysis={() => setAnalysis(null)}
                isProcessing={isProcessing}
                selectedForComparison={selectedForComparison}
                onToggleComparison={(id) => setSelectedForComparison(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id])}
                onRateProperty={() => {}}
              />
            </div>
          </>
        )}

        {activeTab === 'Calculator' && <MortgageCalculator />}
        {activeTab === 'Stats' && <StatsDashboard />}
        {activeTab === 'Pricing' && <Pricing />}
        {activeTab === 'Agent' && <CharityAgent />}
        {activeTab === 'Profile' && (
          <UserProfile 
            user={user} 
            onAuthClick={() => setShowAuthModal(true)} 
            favorites={favorites} 
            allListings={listings} 
            onViewDetails={setSelectedListing} 
            onToggleFavorite={handleToggleFavorite}
          />
        )}
      </main>

      {selectedListing && (
        <ListingDetailsModal 
          listing={selectedListing} 
          onClose={() => setSelectedListing(null)}
          favorites={favorites}
          onToggleFavorite={handleToggleFavorite}
          allMessages={allMessages}
          onSendMessage={handleSendMessage}
          onLinkProperty={() => {}}
          onRateProperty={() => {}}
        />
      )}

      {showToolbox && <AiToolbox onClose={() => setShowToolbox(false)} />}
      {showAuthModal && <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />}
      {showPostModal && <PostPropertyModal isOpen={showPostModal} onClose={() => setShowPostModal(false)} user={user} onAuthRequest={() => setShowAuthModal(true)} />}
      {showDevMode && <SystemInternals isOpen={showDevMode} onClose={() => setShowDevMode(false)} />}
      
      {selectedForComparison.length > 1 && (
          <div className="fixed bottom-32 left-1/2 -translate-x-1/2 z-[200] w-full max-w-lg px-6 pointer-events-none">
              <div className="bg-slate-950/80 backdrop-blur-3xl border border-blue-500/30 rounded-[2rem] p-6 shadow-2xl flex items-center justify-between pointer-events-auto">
                  <div className="text-left">
                      <p className="text-white font-black text-sm uppercase tracking-tight">{selectedForComparison.length} Nodes Selected</p>
                      <p className="text-[8px] text-blue-400 uppercase tracking-widest">Parity Audit Ready</p>
                  </div>
                  <button 
                    onClick={() => setIsComparisonModalOpen(true)}
                    className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                  >
                      Execute Audit
                  </button>
              </div>
          </div>
      )}

      {isComparisonModalOpen && (
        <ComparisonModal 
            isOpen={isComparisonModalOpen}
            onClose={() => setIsComparisonModalOpen(false)}
            properties={listings.filter(l => selectedForComparison.includes(l.id))}
            onViewDetails={(item) => { setSelectedListing(item); setIsComparisonModalOpen(false); }}
        />
      )}

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} onPostClick={() => setShowPostModal(true)} />
      <LiveConversation />
      <NeuralChatWidget allMessages={allMessages} onSendMessage={handleSendMessage} />
    </div>
  );
};

export default App;
