
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { GoogleGenAI, Type, Modality, FunctionDeclaration, GenerateContentResponse, Chat } from "@google/genai";

// --- MODELS ---
const FAST_MODEL = 'gemini-3-flash-preview'; 
const PRO_MODEL = 'gemini-3-pro-preview';
const FLASH_LITE_MODEL = 'gemini-2.5-flash-lite-latest';
const MAPS_MODEL = 'gemini-2.5-flash';
const IMAGE_PRO_MODEL = 'gemini-3-pro-image-preview';
const IMAGE_FLASH_MODEL = 'gemini-2.5-flash-image';
const IMAGEN_MODEL = 'imagen-4.0-generate-001'; 
const VIDEO_GEN_MODEL = 'veo-3.1-fast-generate-preview';
const TTS_MODEL = 'gemini-2.5-flash-preview-tts';

// --- INTERFACES ---
export interface PropertyListing {
  id: string;
  title: string;
  location: string;
  price: number;
  currency: string;
  type: string;
  listing_type: 'Sale' | 'Rent' | 'Lease';
  bedrooms: number;
  bathrooms: number;
  vibe_score: number;
  match_reason: string;
  tags: string[];
  is_verified: boolean;
  status: "Available" | "Rented" | "Under Offer" | "Sold";
  image_url: string; 
  video_url?: string; 
  images?: string[];
  has_3d_tour?: boolean;
  description?: string;
  enhanced_data?: EnhancedDescription;
  tenure: string;
  water_source: string;
  power_backup: string;
  floor_area: string;
  year_built: number;
  coordinates: { lat: number; lng: number };
  user_rating?: number; 
}

export interface MarketPulse {
  location: string;
  average_price: string;
  price_trend: 'Rising' | 'Stable' | 'Falling';
  demand_level: 'High' | 'Medium' | 'Low';
  drift_percentage: string;
  market_sentiment: string;
  liquidity_score: number;
  supply_index: 'Saturated' | 'Balanced' | 'Undersupplied';
  investment_horizon: string;
  historical_drift: { month: string, value: number }[];
  comparative_metrics: { name: string, score: number }[];
  dynamics_data: { label: string, value: number, category: string }[];
  sources?: any[];
}

export interface EnhancedDescription {
  description: string;
  seo_keywords: string[];
  target_audience: string;
  unique_selling_points: string[];
  market_context: string;
  whatsapp_formatted: string;
  optimization_score: number;
}

export interface EmmanuelResponse {
  text: string;
  suggestions: string[];
}

export interface VisionAnalysis {
  scam_risk: 'High' | 'Medium' | 'Low';
  is_stock_photo: boolean;
  vibe_check: string;
  estimated_rent: string;
  features_detected: string[];
  maintenance_flags: string[];
}

export interface SavedSearch {
    id: string;
    query: string;
    filters: {
        type: string;
        status: string;
        bedrooms: number | null;
        priceRange: [number, number];
    };
    timestamp: number;
}

export interface InvestmentAuditReport {
    summary: string;
    rental_yield: string;
    capital_appreciation: string;
    risk_assessment: 'Low' | 'Medium' | 'High';
    strategic_recommendation: string;
    market_drifts: string[];
    optimization_score: number;
    roi_potential: string;
    sources?: any[];
}

export interface AIAgent {
  id: string;
  name: string;
  role: string;
  specialty: string;
  status: string;
  color: string;
}

export interface CommunicationLog {
  id: string;
  clientId: string;
  clientName: string;
  propertyId: string;
  propertyName: string;
  lastMessage: string;
  timestamp: string;
  type: 'WhatsApp' | 'Email' | 'Portal';
  status: 'High Priority' | 'Pending' | 'Synced';
}

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

async function withRetry<T>(fn: () => Promise<T>, retries = 3, delay = 2000): Promise<T> {
    try {
        return await fn();
    } catch (error: any) {
        const message = error?.message || "";
        const isRetriable = 
            error?.status === 429 || 
            error?.status === 500 ||
            error?.status === 503 ||
            message.includes('429') || 
            message.includes('RESOURCE_EXHAUSTED') ||
            message.includes('xhr error') || 
            message.includes('Rpc failed');
        
        if (retries > 0 && isRetriable) {
            await new Promise(resolve => setTimeout(resolve, delay));
            return withRetry(fn, retries - 1, delay * 2);
        }
        throw error;
    }
}

/**
 * Enhanced listing generation that supports natural language and ROI queries.
 * Uses thinking mode and google search grounding for complex requests.
 */
export async function generateListings(query: string, batch: number): Promise<PropertyListing[]> {
  const isComplex = /ROI|yield|profit|investment|>|<|%|percent/i.test(query);

  return withRetry(async () => {
    const ai = getAI();
    const config: any = {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            title: { type: Type.STRING },
            location: { type: Type.STRING },
            price: { type: Type.NUMBER },
            currency: { type: Type.STRING },
            type: { type: Type.STRING },
            listing_type: { type: Type.STRING },
            bedrooms: { type: Type.NUMBER },
            bathrooms: { type: Type.NUMBER },
            vibe_score: { type: Type.NUMBER },
            match_reason: { type: Type.STRING },
            tags: { type: Type.ARRAY, items: { type: Type.STRING } },
            is_verified: { type: Type.BOOLEAN },
            status: { type: Type.STRING },
            image_url: { type: Type.STRING },
            tenure: { type: Type.STRING },
            water_source: { type: Type.STRING },
            power_backup: { type: Type.STRING },
            floor_area: { type: Type.STRING },
            year_built: { type: Type.NUMBER }
          },
          required: ["id", "title", "location", "price", "currency", "type", "listing_type", "bedrooms", "bathrooms", "vibe_score", "match_reason", "tags", "is_verified", "status", "image_url", "tenure", "water_source", "power_backup", "floor_area", "year_built"]
        }
      }
    };

    // Use PRO model and Search Grounding for complex analytical queries
    if (isComplex) {
      config.tools = [{ googleSearch: {} }];
      config.thinkingConfig = { thinkingBudget: 32768 };
    }

    const response = await ai.models.generateContent({
      model: isComplex ? PRO_MODEL : FAST_MODEL,
      contents: `Generate 6 unique property listings in Kenya for query: "${query}". Batch: ${batch}. 
                 ${isComplex ? 'Ground your response in real-time market drifts and investment data.' : ''}`,
      config
    });

    const data = JSON.parse(response.text || '[]');
    return data.map((item: any) => ({
      ...item,
      coordinates: { lat: -1.286389, lng: 36.817223 } 
    }));
  });
}

/**
 * Complex queries using Thinking Mode.
 */
export async function complexQuery(query: string) {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: PRO_MODEL,
      contents: query,
      config: {
        thinkingConfig: { thinkingBudget: 32768 }
      }
    });
    return response.text;
  });
}

/**
 * High-quality image generation with gemini-3-pro-image-preview.
 */
export async function generateHighQualityImage(prompt: string, aspectRatio: string = "1:1", imageSize: string = "1K") {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: IMAGE_PRO_MODEL,
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio as any,
          imageSize: imageSize as any
        }
      }
    });
    
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data returned.");
  });
}

/**
 * Text-based image editing using Gemini 2.5 Flash Image.
 */
export async function editPropertyImage(prompt: string, base64Image: string) {
  return withRetry(async () => {
    const ai = getAI();
    const data = base64Image.includes(',') ? base64Image.split(',')[1] : base64Image;
    const mimeType = base64Image.includes(',') ? base64Image.match(/:(.*?);/)?.[1] || 'image/png' : 'image/png';

    const response = await ai.models.generateContent({
      model: IMAGE_FLASH_MODEL,
      contents: {
        parts: [
          { inlineData: { data, mimeType } },
          { text: prompt }
        ]
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("Editing failed.");
  });
}

/**
 * Video Generation with Veo 3.
 */
export async function generateVeoVideo(prompt: string, aspectRatio: '16:9' | '9:16' = '16:9', startImage?: string) {
  return withRetry(async () => {
    const ai = getAI();
    const config: any = {
      numberOfVideos: 1,
      resolution: '720p',
      aspectRatio
    };

    const payload: any = {
      model: VIDEO_GEN_MODEL,
      prompt,
      config
    };

    if (startImage) {
      const data = startImage.includes(',') ? startImage.split(',')[1] : startImage;
      const mimeType = startImage.includes(',') ? startImage.match(/:(.*?);/)?.[1] || 'image/png' : 'image/png';
      payload.image = { imageBytes: data, mimeType };
    }

    let operation = await ai.models.generateVideos(payload);
    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      operation = await ai.operations.getVideosOperation({ operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    const blob = await response.blob();
    return URL.createObjectURL(blob);
  });
}

export const generateAssetVideo = generateVeoVideo;

/**
 * Video analysis using Gemini 3 Pro Preview.
 */
export async function analyzeVideo(base64Video: string, prompt: string) {
  return withRetry(async () => {
    const ai = getAI();
    const data = base64Video.includes(',') ? base64Video.split(',')[1] : base64Video;
    const mimeType = base64Video.includes(',') ? base64Video.match(/:(.*?);/)?.[1] || 'video/mp4' : 'video/mp4';

    const response = await ai.models.generateContent({
      model: PRO_MODEL,
      contents: {
        parts: [
          { inlineData: { data, mimeType } },
          { text: prompt }
        ]
      }
    });

    return response.text;
  });
}

/**
 * TTS using Gemini 2.5 Flash Preview TTS.
 */
export async function speakDescription(text: string) {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: TTS_MODEL,
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' }
          }
        }
      }
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    return base64Audio || null;
  });
}

/**
 * Maps Grounding Search using Gemini 2.5 Flash.
 */
export async function searchNearbyAmenities(location: string, amenity: string) {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: MAPS_MODEL,
      contents: `Find ${amenity} near ${location}`,
      config: {
        tools: [{ googleMaps: {} }]
      }
    });
    return {
      text: response.text,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  });
}

/**
 * Search Grounding using Gemini 3 Flash Preview.
 */
export async function getRecentMarketNews(query: string) {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: FAST_MODEL,
      contents: `What is the latest real estate news for ${query}?`,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });
    return {
      text: response.text,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  });
}

/**
 * Analyze Property Image using Gemini 3 Pro Preview.
 */
export async function analyzePropertyImage(base64: string, prompt: string): Promise<VisionAnalysis> {
  return withRetry(async () => {
    const ai = getAI();
    const data = base64.includes(',') ? base64.split(',')[1] : base64;
    const mimeType = base64.includes(',') ? base64.match(/:(.*?);/)?.[1] || 'image/jpeg' : 'image/jpeg';
    
    const response = await ai.models.generateContent({
        model: PRO_MODEL,
        contents: {
            parts: [
                { inlineData: { data, mimeType } },
                { text: prompt }
            ]
        },
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    scam_risk: { type: Type.STRING },
                    is_stock_photo: { type: Type.BOOLEAN },
                    vibe_check: { type: Type.STRING },
                    estimated_rent: { type: Type.STRING },
                    features_detected: { type: Type.ARRAY, items: { type: Type.STRING } },
                    maintenance_flags: { type: Type.ARRAY, items: { type: Type.STRING } }
                },
                required: ["scam_risk", "is_stock_photo", "vibe_check", "estimated_rent", "features_detected", "maintenance_flags"]
            }
        }
    });

    return JSON.parse(response.text || '{}');
  });
}

/**
 * Low-latency responses with Gemini 2.5 Flash Lite.
 */
export async function fastResponse(query: string) {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: FLASH_LITE_MODEL,
      contents: query
    });
    return response.text;
  });
}

/**
 * Chat bot functionality using Gemini 3 Pro Preview.
 */
export async function askAgent(agent: string, history: any[], msg: string): Promise<EmmanuelResponse> {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: PRO_MODEL,
      contents: [...history.map(h => ({ role: h.role === 'model' ? 'model' : 'user', parts: [{ text: h.text }] })), { role: 'user', parts: [{ text: msg }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            text: { type: Type.STRING },
            suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["text", "suggestions"]
        }
      }
    });
    return JSON.parse(response.text || '{"text":"", "suggestions":[]}');
  });
}

export async function getMarketPulse(location: string): Promise<MarketPulse> {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
        model: FAST_MODEL,
        contents: `Analyze the real estate market pulse for ${location} (Kenya).`,
        config: {
            tools: [{ googleSearch: {} }],
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    location: { type: Type.STRING },
                    average_price: { type: Type.STRING },
                    price_trend: { type: Type.STRING },
                    demand_level: { type: Type.STRING },
                    drift_percentage: { type: Type.STRING },
                    market_sentiment: { type: Type.STRING },
                    liquidity_score: { type: Type.NUMBER },
                    supply_index: { type: Type.STRING },
                    investment_horizon: { type: Type.STRING },
                    historical_drift: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                month: { type: Type.STRING },
                                value: { type: Type.NUMBER }
                            }
                        }
                    },
                    comparative_metrics: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                name: { type: Type.STRING },
                                score: { type: Type.NUMBER }
                            }
                        }
                    },
                    dynamics_data: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          label: { type: Type.STRING },
                          value: { type: Type.NUMBER },
                          category: { type: Type.STRING }
                        }
                      }
                    }
                },
                required: ["location", "average_price", "price_trend", "demand_level", "drift_percentage", "market_sentiment", "liquidity_score", "supply_index", "investment_horizon", "historical_drift", "comparative_metrics", "dynamics_data"]
            }
        }
    });

    const data = JSON.parse(response.text || '{}');
    return {
        ...data,
        sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  });
}

export async function getTrendingProperties(): Promise<PropertyListing[]> {
    return generateListings("trending luxury properties in Nairobi", 1);
}

export async function enhancePropertyDescription(property: any, pulse?: any): Promise<EnhancedDescription> {
  return withRetry(async () => {
    const ai = getAI();
    const prompt = `
      Act as a senior real estate copywriter. Transform the provided property data into a high-converting listing.
      Input Property Data: ${JSON.stringify(property)}
      ${pulse ? `Market Context: ${JSON.stringify(pulse)}` : ''}
    `;

    const response = await ai.models.generateContent({
        model: PRO_MODEL,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    description: { type: Type.STRING },
                    seo_keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
                    target_audience: { type: Type.STRING },
                    unique_selling_points: { type: Type.ARRAY, items: { type: Type.STRING } },
                    market_context: { type: Type.STRING },
                    whatsapp_formatted: { type: Type.STRING },
                    optimization_score: { type: Type.NUMBER }
                },
                required: ["description", "seo_keywords", "target_audience", "unique_selling_points", "market_context", "whatsapp_formatted", "optimization_score"]
            }
        }
    });
    return JSON.parse(response.text || '{}');
  });
}

export async function generatePropertyImage(prompt: string): Promise<string> {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
        model: IMAGE_FLASH_MODEL,
        contents: { parts: [{ text: prompt }] },
        config: { imageConfig: { aspectRatio: "1:1" } }
    });
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
    }
    throw new Error("Generation failed.");
  });
}

export async function performInvestmentAudit(location: string, goal: string): Promise<InvestmentAuditReport> {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: PRO_MODEL,
      contents: `Perform deep real estate investment audit for ${location} with goal ${goal}`,
      config: {
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingBudget: 32768 },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            rental_yield: { type: Type.STRING },
            capital_appreciation: { type: Type.STRING },
            risk_assessment: { type: Type.STRING },
            strategic_recommendation: { type: Type.STRING },
            market_drifts: { type: Type.ARRAY, items: { type: Type.STRING } },
            optimization_score: { type: Type.NUMBER },
            roi_potential: { type: Type.STRING }
          },
          required: ["summary", "rental_yield", "capital_appreciation", "risk_assessment", "strategic_recommendation", "market_drifts", "optimization_score", "roi_potential"]
        }
      }
    });
    
    const data = JSON.parse(response.text || '{}');
    return {
      ...data,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  });
}

export async function transcribeAudio(base64Audio: string, mimeType: string = 'audio/wav') {
  return withRetry(async () => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: FAST_MODEL,
      contents: {
        parts: [
          { inlineData: { data: base64Audio, mimeType } },
          { text: "Transcribe this audio accurately. Return only text." }
        ]
      }
    });
    return response.text;
  });
}

export async function askEmmanuel(listing: any, history: any[], msg: string): Promise<EmmanuelResponse> {
    return askAgent('emmanuel', history, msg + (listing ? ` Context: ${listing.title}` : ""));
}

export async function askCharity(history: any[], msg: string): Promise<string> {
    const res = await askAgent('charity', history, msg);
    return res.text;
}

/**
 * Updated getAvailableAgents with proper return type.
 */
export async function getAvailableAgents(): Promise<AIAgent[]> {
    return [
        { id: 'emmanuel', name: 'Emmanuel', role: 'Market Forensics', specialty: 'ROI Drifts', status: 'Online', color: 'emerald' },
        { id: 'prashanth', name: 'Prashanth', role: 'Tenant Screening', specialty: 'Vetting', status: 'Online', color: 'blue' }
    ];
}
