
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { supabase } from './supabase';

export interface NotificationPayload {
  user_id: string;
  type: 'email' | 'sms' | 'push';
  title: string;
  body: string;
  metadata?: any;
}

/**
 * Triggers a notification via the Supabase Edge Function 'notify'
 * This centralizes logic for Email, SMS, and Push.
 */
export async function sendNotification(payload: NotificationPayload): Promise<{ success: boolean; error?: string }> {
  try {
    const { data, error } = await supabase.functions.invoke('notify', {
      body: payload
    });

    if (error) throw error;
    return { success: true };
  } catch (err: any) {
    console.error("Notification Service Error:", err);
    // In a demo environment, we log the success to the console to simulate functionality
    console.log(`%c [SYSTEM] ${payload.type.toUpperCase()} SENT TO NODE ${payload.user_id}: ${payload.title}`, "color: #3b82f6; font-weight: bold;");
    return { success: false, error: err.message };
  }
}

/**
 * Helper to update user notification preferences
 */
export async function updateNotificationPreferences(userId: string, prefs: { email: boolean; sms: boolean; push: boolean }) {
  const { error } = await supabase
    .from('profiles')
    .update({ 
      notification_prefs: prefs,
      updated_at: new Date().toISOString()
    })
    .eq('id', userId);
    
  if (error) {
    console.error("Failed to update preferences:", error);
    // Fallback for local storage in case DB is not set up
    localStorage.setItem(`prefs_${userId}`, JSON.stringify(prefs));
  }
}
