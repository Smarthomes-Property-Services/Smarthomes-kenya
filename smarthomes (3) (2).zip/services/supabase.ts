
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { createClient } from '@supabase/supabase-js';

// Specific project URL provided by the user
const supabaseUrl = 'https://mmweeohdpiqxmfxckgxz.supabase.co';
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;

/**
 * We create a dummy client if credentials are missing to avoid 'Failed to fetch' 
 * errors during the automatic session restoration process.
 */
export const supabase = (supabaseUrl && supabaseAnonKey && !supabaseAnonKey.includes('placeholder')) 
    ? createClient(supabaseUrl, supabaseAnonKey)
    : {
        auth: {
            getSession: async () => ({ data: { session: null }, error: null }),
            getUser: async () => ({ data: { user: null }, error: null }),
            onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
            signInWithPassword: async () => ({ data: {}, error: new Error("Supabase is not configured. Please set SUPABASE_ANON_KEY.") }),
            signUp: async () => ({ data: {}, error: new Error("Supabase is not configured. Please set SUPABASE_ANON_KEY.") }),
            signOut: async () => ({ error: null }),
            signInWithOAuth: async () => ({ data: {}, error: new Error("Supabase is not configured.") }),
        },
        from: () => ({
            select: () => ({
                eq: () => ({ execute: async () => ({ data: [], error: null }) }),
                limit: () => ({ execute: async () => ({ data: [], error: null }) }),
            }),
            insert: () => ({ execute: async () => ({ data: null, error: null }) }),
            update: () => ({ eq: () => ({ execute: async () => ({ data: null, error: null }) }) }),
        })
    } as any;
