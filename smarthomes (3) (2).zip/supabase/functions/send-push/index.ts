import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
// Import JWT creation library to sign Google credentials manually (No external dependencies needed)
import { create } from "https://deno.land/x/djwt@v2.9.1/mod.ts";

declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

console.log("Push Notification Function Initialized");

// Load Service Account from Supabase Secrets
const serviceAccount = JSON.parse(Deno.env.get("FIREBASE_SERVICE_ACCOUNT")!);

async function getAccessToken() {
  const jwt = await create(
    { alg: "RS256", typ: "JWT" },
    {
      iss: serviceAccount.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging",
      aud: "https://oauth2.googleapis.com/token",
      exp: Math.floor(Date.now() / 1000) + 3600,
      iat: Math.floor(Date.now() / 1000),
    },
    { key: serviceAccount.private_key }
  );

  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });

  const data = await res.json();
  return data.access_token;
}

serve(async (req) => {
  try {
    const { user_id, title, body, screen } = await req.json();

    // 1. Get the User's FCM Token from Supabase
    // (Assumes you store this when the user logs into the app)
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    
    // Simple fetch to get the token
    const userRes = await fetch(`${supabaseUrl}/rest/v1/profiles?id=eq.${user_id}&select=fcm_token`, {
        headers: { "apikey": supabaseKey, "Authorization": `Bearer ${supabaseKey}` }
    });
    
    const userData = await userRes.json();
    const fcmToken = userData[0]?.fcm_token;

    if (!fcmToken) {
      return new Response("No FCM Token found for user", { status: 404 });
    }

    // 2. Get Firebase Access Token
    const accessToken = await getAccessToken();

    // 3. Send to FCM
    const fcmRes = await fetch(
      `https://fcm.googleapis.com/v1/projects/${serviceAccount.project_id}/messages:send`,
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: {
            token: fcmToken,
            notification: {
              title: title,
              body: body,
            },
            data: {
              click_action: "FLUTTER_NOTIFICATION_CLICK",
              screen: screen, // "agent_dashboard"
            },
          },
        }),
      }
    );

    const fcmData = await fcmRes.json();
    return new Response(JSON.stringify(fcmData), { headers: { "Content-Type": "application/json" } });

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  }
});