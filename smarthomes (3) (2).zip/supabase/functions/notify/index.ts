
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

// Fix: Add declaration for the Deno global object to satisfy the TypeScript compiler
declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

serve(async (req) => {
  try {
    const { user_id, type, title, body, metadata } = await req.json();

    // 1. Initialize Supabase Client
    // Fix: Deno.env is used here to access Supabase secrets
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    
    // 2. Fetch User Profile to check preferences
    const profileRes = await fetch(`${supabaseUrl}/rest/v1/profiles?id=eq.${user_id}&select=notification_prefs,email,phone`, {
        headers: { "apikey": supabaseKey, "Authorization": `Bearer ${supabaseKey}` }
    });
    
    const profileData = await profileRes.json();
    const user = profileData[0];

    if (!user) {
      return new Response("User node not found", { status: 404 });
    }

    const prefs = user.notification_prefs || { email: true, sms: true, push: true };

    // 3. Conditional Dispatch Logic
    if (type === 'email' && !prefs.email) {
      return new Response("Email disabled by user preference matrix", { status: 200 });
    }
    if (type === 'sms' && !prefs.sms) {
      return new Response("SMS disabled by user preference matrix", { status: 200 });
    }

    // 4. Dispatch Protocol (Mocking external provider calls for Twilio/SendGrid/Postmark)
    console.log(`Dispatched ${type.toUpperCase()} to ${user_id}: [${title}]`);

    // Simulate calling an external API for SMS/Email
    // Example: await fetch('https://api.sendgrid.com/v3/mail/send', ...)
    
    return new Response(JSON.stringify({ 
      status: "DISPATCHED", 
      node: user_id, 
      protocol: type,
      timestamp: new Date().toISOString()
    }), { 
      headers: { "Content-Type": "application/json" } 
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  }
});
